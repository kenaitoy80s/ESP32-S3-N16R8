// ============================================================================
// status_hub —— V1.20 统一系统状态中心
// ----------------------------------------------------------------------------
// 目标: 数据采集一次 -> 存成统一状态 -> TFT 屏和 Web 后台读【同一份】, 不各读各的:
//   · RSSI / 芯片温度 / CPU / 运行时间: 来自 sys_monitor 的 sysSnapshot()(TFT 也读它);
//   · 天气: 来自 gState.wx(TFT 也读它), 本模块只额外记录"请求结果/错误码/时间";
//   · 时间/农历/星期: 与 TFT 同样来自 timeLocal() / lunarFromSolar();
//   · 播放状态: 只读现有播放器状态(gState + 播放器已有的只读访问器), 不新增任何音频检测任务。
// 输出: 主循环里按 STATUS_JSON_MS 预先构建好一份 JSON 文本; /api/status 只做"锁内拷贝 + 放锁后发送"
//       (与 /api/state 完全相同的零风险写法), 异步任务里不碰 gState、不碰任何驱动。
// 错误记录: RAM 环形缓冲(最近 16 条) + 4 个累计计数; 不写 Flash, 重启清空。
// 全部可用 STATUS_HUB_ENABLE 一键关闭(关闭后下面的函数都是空实现, 工程其余部分照常编译)。
// ============================================================================
#pragma once
#include <Arduino.h>

#ifndef STATUS_HUB_ENABLE
#define STATUS_HUB_ENABLE  1       // 0 = 整个状态中心不编译、/api/status 不提供内容
#endif
#ifndef STATUS_JSON_MS
#define STATUS_JSON_MS     2500    // 状态 JSON 重建间隔(毫秒); 页面约 5 秒拉一次
#endif
#ifndef STATUS_SERIAL_DIAG_MS
#define STATUS_SERIAL_DIAG_MS 15000  // V1.22: 串口"音频/缓冲/内存"诊断行间隔(毫秒); 0=不打印。
                                      //   复用已有的 statusRebuildIfDue() 调用节奏(主循环里本来就在调), 不新增定时器。
#endif

// 事件类型(同时也是累计计数的下标: 前 4 个各有一个累计数)
enum StatusEvType : uint8_t {
  EV_WIFI    = 0,    // Wi-Fi 断线/重连
  EV_WEATHER = 1,    // 天气请求失败
  EV_AUDIO   = 2,    // 网台播放: 重连/读取失败/解码错误
  EV_SD      = 3,    // SD 卡: 未挂载/读卡失败等
  EV_TIME    = 4,    // 时间: NTP 校时
  EV_SYS     = 5     // 其它系统事件
};

// 播放器的只读数据(由 web_server 在主循环里从现有访问器取出传进来, 本模块不依赖播放器头文件)
struct StatusPlayerInfo {
  uint32_t bufFilled;    // 输入缓冲已填充字节
  uint32_t bufCap;       // 输入缓冲容量字节
  // V1.22 修正: 这其实是"最近一次解码错误码"(库的 getDecodeError(), 如 0/-3/-6), 不是累计次数。
  //   V1.20 曾把它当累计次数处理, 用 uint32_t 存负数会整数回绕成一个巨大的数(后台显示过 -6 变成
  //   4294967290 就是这个原因)。改成 int 存原始值, 0 = 当前无错误。
  int      decodeErr;
  bool     running;      // 音频库是否在运行
  uint32_t sampleRate;   // V1.23: 解码器实际输出采样率(Hz), 只读透传, 用来判断 SBR 是否真的在跑
};

#if STATUS_HUB_ENABLE
void statusEvent(StatusEvType t, int code, const char* msg);    // 任意任务可调(内部有自旋锁, 只写 RAM)
void statusWifiDisconnected(int reason);                        // sys_monitor 的 Wi-Fi 事件回调里调
void statusWifiGotIp();
void statusNtpSynced();                                         // SNTP 成功回调里调(记录最近一次校时)
// 天气请求结果(主循环里调): ok=是否成功; code=HTTP 状态码(>0)或错误码(<0); stage="定位"/"天气"; nextGapMs=下次重试间隔
void statusWxResult(bool ok, int code, const char* stage, uint32_t nextGapMs);
void statusRebuildIfDue(const StatusPlayerInfo& pi);            // 主循环调: 播放状态边沿检测 + 到点重建 JSON
void statusJsonCopy(String& out);                               // 任意任务可调: 锁内拷贝最新 JSON
#else
inline void statusEvent(StatusEvType, int, const char*) {}
inline void statusWifiDisconnected(int) {}
inline void statusWifiGotIp() {}
inline void statusNtpSynced() {}
inline void statusWxResult(bool, int, const char*, uint32_t) {}
inline void statusRebuildIfDue(const StatusPlayerInfo&) {}
inline void statusJsonCopy(String& out) { out = "{}"; }
#endif
