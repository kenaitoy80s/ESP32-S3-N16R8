#pragma once
#include <Audio.h>
#include <WiFi.h>
#include "../config.h"
#include "../player_state.h"

class StationStore;   // 前向声明, 由 attachStore 注入

/*
 * 音频播放封装 (ESP32-audioI2S 2.0.6 "Helix" 版 — 支持无 PSRAM 板):
 *   - 该库为【单线程】: audio.loop() 一次调用内完成"拉流 + 解码 + 写 I2S"。
 *     ★库里【没有】任何内部解码任务, 也【没有】任何内部互斥锁 —— 所以"调用间隔"决定音频
 *     连续性(间隔 > I2S DMA 深度就断音), 且库绝不能被两个任务并发调用。
 *   - 2026-09-16 由 3.0.13(faad2 AAC) 切回 2.0.6(Helix AAC): 前者的 AAC 解一帧需约 70KB
 *     连续堆且每帧 malloc/free, 无 PSRAM 板给不出来; Helix 一次性 28.8KB 后零分配。
 *
 * ---- 线程模型(方案B, 2026-09-19) ----
 *   音频泵任务 (core1, prio AUDIO_TASK_PRIO)  : 只调 audio.loop() —— 独占喂流, 抢占式保证节奏
 *   主循环 loopTask (core1, prio 1)          : 取命令(processCmd) + ICY 元数据 + 健康监测 + 静音恢复
 *   异步任务 AsyncTCP/Web (core0, prio 10)   : WS/HTTP 回调 —— 只投递命令, 绝不碰 audio 对象
 *   三者的边界:
 *     · audio 对象: 泵任务 audio.loop() 与主循环的 stopSong/connecttohost/beep 由 audioMutex 互斥;
 *     · gState:     ★只由主循环写(String 跨任务写会堆损坏)。库回调 audio_showstreamtitle 跑在
 *                   泵任务里, 故它只写无堆分配的暂存缓冲 + 代次号, 由主循环取走落地;
 *     · 命令:       play/next/volume… 全是投递, 由主循环 processCmd 统一执行(见下)。
 * 独立 ICY 元数据读取器: 另开轻量连接解析 StreamTitle, 与音频库解耦(全程在主循环, 非泵任务)。
 */
// ---- SD 播放循环方式(gState.sdLoop, 2026-10-07) ----
// 顺序=放完最后一首就停; 循环全部=绕回第一首一直放; 单曲=一直重播当前这首; 随机=每次随机挑。
enum : uint8_t { SD_LOOP_ORDER = 0, SD_LOOP_ALL = 1, SD_LOOP_ONE = 2, SD_LOOP_RANDOM = 3 };

class AudioPlayer {
public:
  void begin();
  void attachStore(StationStore* s) { store = s; }

  // ---- 以下全部为线程安全的命令投递(可从任意任务上下文调用) ----
  void play(const String& url);     // 播放指定流地址(命令投递)
  void reconnect();                 // 原地重连当前台(不重置 failCount, 供看门狗重试)
  void playCurrent();               // 播放 store 中 lastIndex 指向的电台
  void stop();
  void togglePlay();
  void next();
  void prev();
  void requestPlayIdx(int i);       // 按电台表序号播放(Web 后台用)
  void setVolume(int v);            // v: 0..99(VOLUME_MAX); 内部经 volToLib() 映射到库的 0..21 档
                                    // 任意任务可调: 库实现只做一次 `m_vol = volumetable[v]`(单次 32bit 写, 原子)
  void loop();                      // 主循环侧(loopTask): 取换台命令 + 元数据推进 + 健康监测 + 静音恢复
  // ---- 音频泵任务(方案B): 独占 audio.loop(), 由 begin() 末尾自动创建 ----
  void startPumpTask();             // 创建并启动泵任务(钉 AUDIO_TASK_CORE / AUDIO_TASK_PRIO)
  void suspendPumpTask();           // 挂起泵任务。★关机/深睡前必调: 之后要断 WiFi, 不能有任务在读 socket
  volatile uint32_t pumpTick = 0;   // 泵任务心跳(每圈自增; 供失速看门狗判断"喂流是否还在转")
  uint32_t pumpHz = 0;              // 泵任务实测频率(Hz): 喂流节奏的真实指标
  bool     pumpRunning() const { return pumpTaskHandle != nullptr; }
  uint32_t pumpStackFree();         // 泵任务栈余(字节; 0 = 任务未创建/已挂起)。喂流任务的栈水位必须盯住
  // ★喂流模式开关(防呆, 见 config.h 的「防呆设计」): true=泵任务喂流; false=主循环喂流(方案A 回退)。
  // 用 volatile: 泵任务(读)与主循环/串口命令(写)分处两个任务, 不能让它被优化进寄存器。
  volatile bool pumpEnabled = AUDIO_PUMP_ENABLED;
  void setPumpEnabled(bool on);     // 串口 P 调用: 切换喂流模式并打印当前状态
  void togglePrebuf();              // 串口 B 调用: 切换起播预缓冲(开/关), 下一台起生效
  // 当前是否"真的由泵任务在喂流": 开关打开【且】任务确实创建成功。主循环据此决定要不要自己喂。
  bool pumpFeeding() const { return pumpEnabled && pumpTaskHandle != nullptr; }
  void beepTest();                  // 诊断: 绕过网络/解码, 直接向 I2S 写 1kHz 方波(定位"无声"层级)
  uint32_t prebufBytes() const;     // 诊断/Web: 当前预缓冲水位(字节, 0=关)

  // ---- 独立 ICY 元数据读取(节目信息) ----
  void startMeta(const String& streamUrl);  // 开始跟踪某条流的元数据
  void stopMeta();                          // 停止(切台/停止时调用)
  void updateMeta();                        // 在 loop() 中周期调用(非阻塞)

  // ---- 节目信息连接开关(流畅度 vs 功能 的取舍) ----
  // 该连接会再拉一路"完整音频流": 带宽翻倍 + 持续占用全局共享的 LWIP pbuf 池。
  // pbuf 被占满时音频连接分不到缓冲 -> 直接卡顿(4M 无 PSRAM 板上这是卡顿主因; S3 有 PSRAM 影响小)。
  // ★注意: 节目信息其实【不需要】这条连接也能有 —— 音频连接内的 ICY 回调
  //   (audio_showstreamtitle)是零带宽的, 已默认启用; 本开关是"另开一条流"的老方案, 默认关。
  // 运行时可切(串口发 M / Web 后台); 缓冲持续欠载时也会自动降级, 优先保声音。
  void setMetaEnabled(bool on);
  bool metaEnabled = META_ENABLED_DEFAULT;

  // ---- SBR 开关(2026-10-07; 后台"音效设置"与串口【B】共用) ----
  // SBR 是 HE-AAC 的高频重建技术, 会把输出采样率从核心采样率【翻倍】(48k -> 96k)。
  // ★为什么本机默认关: I2S 的 DMA 深度固定 16384 帧, 96kHz 下只够【170ms】, 而实测有些
  //   电台服务器(ICecast 转推)是突发式推包(约 200ms 一个包) -> 200ms > 170ms 必然排空
  //   DMA -> 听感规律性"发颤"。关掉后 48kHz 有【372ms】余量, 实测同一台由发颤变流畅。
  // ★对普通电台零影响: 实测大猫系列与 AsiaFM 都是 audio/aac 或 audio/mpeg, 根本不触发 SBR。
  // ★必须在换台【前】设置: 它影响的是解码器输出采样率, 已建流的台要换台才生效。
  //   运行时可改(不必重编译), 这是本工程给第三方库加的补丁(aac_decoder.cpp 的 AACSetSbrEnabled)。
  void setSbrEnabled(bool on);
  bool sbrEnabled() const { return mSbrEnabled; }

  // ---- 播放链诊断访问器(供 Web /api/diag 暴露; 只读库内部单变量, 任意线程调用安全) ----
  // 存在意义: 本机调试时"复制串口日志"门槛高, 把这几项直接送到网页, 打开浏览器即可判读。
  bool        audioRunning()   { return audio.isRunning(); }
  const char* audioCodec()     { return audio.getCodecname(); }
  uint32_t    audioBitrate()   { return audio.getBitRate(); }
  // V1.23: 解码器实际输出采样率(只读, 不改任何播放参数)。HE-AAC+SBR 实际解码时输出采样率会
  // 翻倍(如 24000Hz -> 48000Hz), 诊断行用它来判断 SBR 是否真的在跑, 不用额外改配置去猜。
  uint32_t    audioSampleRate() { return audio.getSampleRate(); }
  int         audioDecodeErr() { return (int)audio.getDecodeError(); }

  // ---- 流畅度诊断 ----
  uint32_t inBufferFilled();   // 音频输入缓冲已填充字节数(持续接近0 = 网络喂不饱)
  // 输入缓冲的真实总容量(字节)。库把缓冲放在 PSRAM 或 DRAM, 并各自扣掉一个保留区:
  //   PSRAM 分支 m_buffSize = AUDIO_PSRAM_BUFSIZE - m_resBuffSizePSRAM(16384)
  //   DRAM  分支 m_buffSize = AUDIO_RAM_BUFSIZE   - m_resBuffSizeRAM(1600)
  // ★2026-09-18: 之前填充率一律除以 AUDIO_RAM_BUFSIZE, 缓冲搬进 PSRAM 后算出 473%/726%
  // 这种荒谬值, 连带把 META_LOW_WATER 欠载检测永久绕过 —— 两个症状由此一并修掉。
  uint32_t bufferCapacity();
  void printDiag();            // 打印 缓冲填充率/WiFi信号/堆内存/主循环频率
  // 诊断(串口发 W): 完全绕过 ESP32-audioI2S, 用本机自己的 TCP 直连抓流并统计 3 秒内收到的
  // 音频字节数与折算码率。用来把"服务器/网络根本没推音频"与"库侧失败"彻底分开 ——
  // 这是本机唯一可信的网络判据(开发机上的 curl 结果会被代理截断, 不可用)。
  void rawStreamTest(const String& url);
  uint32_t loopHz = 0;         // 主循环(loopTask)实测频率(Hz)

  // ---- 睡眠定时器(阶段①: 纯软件倒计时, 不进深睡) ----
  // 投递命令: min=分钟(0=取消)。实际倒计时在主循环 loop() 内递减, 归零时停播 + 置 sleepJustFired。
  void setSleepTimer(int min);
  // ★定时关机(红外 IR_TIMER): 与 setSleepTimer 共用倒计时, 但到点【真正进深睡关机】。
  //   单独一个接口而不是给 setSleepTimer 加参数, 是为了让面板/后台那些既有调用点
  //   语义保持"熄屏待机"不变 —— 免得改了一处就悄悄改变了老功能的含义。
  void setSleepTimerAt(int min, bool toPowerOff);
  bool sleepActive() const { return gState.sleepRemainSec > 0; }
  int  sleepRemainSec() const { return gState.sleepRemainSec; }
  int  sleepMin() const { return gState.sleepMin; }
  bool sleepToPowerOff() const { return gState.sleepToPowerOff; }

  // ---- 本地 SD 卡播放(阶段②) ----
  // 全部为命令投递(与上面同构), 真正碰 SD 卡/音频对象的动作在主循环 processCmd 里执行。
  // ★与网络电台互斥: 播 SD 期间 next/prev 在 SD 文件序列里走, 网络电台的 lastIndex 保持不变,
  //   退出 SD 模式后仍能接着播原来的电台(见 execSdStop / exitSdMode)。
  void playSdFile(int idx);        // 播放 SD 列表第 idx 个文件
  void playSdNext();               // 下一个文件(放完自动续播也走这里)
  void exitSdMode();               // 退出 SD 模式 -> 回到网络电台(恢复进入 SD 前的那台)
  // 切换 SD 循环方式(2026-10-07): dir=-1 反向一档 / +1 正向一档。
  // 【公开】是因为列表界面里的左/右双击要调它; 只改 gState 不碰 SD 卡与音频对象, 任意上下文安全。
  void cycleSdLoop(int dir);
  bool sdActive() const { return gState.sdActive; }

private:
  Audio audio;
  StationStore* store = nullptr;
  String resolveStreamUrl(const String& url);

  // 音频泵任务句柄(nullptr = 尚未创建; suspendPumpTask() 后仍保留, 用于幂等判断)
  TaskHandle_t      pumpTaskHandle = nullptr;

  // ---- 换台命令邮箱(写者: 主循环/按键/WS异步任务; 读者: 主循环 processCmd) ----
  // 邮箱语义 = "最后一条指令生效": 快速连点只会执行最终那一条, 天然抗积压。所有写者都持 cmdMutex。
  enum : uint8_t { CMD_NONE = 0, CMD_PLAYURL, CMD_PLAYIDX, CMD_NEXT, CMD_PREV,
                   CMD_STOP, CMD_TOGGLE, CMD_RECONNECT, CMD_SLEEP,
                   CMD_SD_PLAY, CMD_SD_NEXT, CMD_SD_EXIT,
                   CMD_SLEEP_PWROFF };   // 定时关机(到点进深睡); 分钟数走 pendingIdx
  SemaphoreHandle_t cmdMutex = nullptr;
  volatile uint8_t  pendingCmd = CMD_NONE;
  volatile int      pendingIdx = -1;   // CMD_PLAYIDX/CMD_SD_PLAY: 目标序号(-1 = 用 store 的 lastIndex)
  String            pendingUrl;        // CMD_PLAYURL: 目标地址(仅持锁期间读写)
  void issueCmd(uint8_t c, int idx = -1);
  void processCmd();                   // 主循环 loop() 开头调用: 取出并执行命令
  void stopSongSafe();                 // 持 audioMutex 调 stopSong —— 与【音频泵任务】的 audio.loop() 互斥
  void beginSwitchMute();             // 切台静音: 立即压音量到0, 进入待恢复(灭间隙嘶声/起播爆破音)
  void rampSwitchVolume();            // 主循环 loop() 内每圈: 等新流出声后平滑恢复音量

  // ★方案B 并发安全的基石: 音频泵任务的 audio.loop() 与主循环侧一切碰 audio 对象的操作
  // (stopSong / connecttohost / beep)共用本锁, 保证库【永不被并发调用】。
  // 递归锁允许嵌套(如 stopSongSafe 嵌在已持锁的调用里)。
  // ★库本身没有任何锁 —— 不要以为它自带保护(旧注释提到的 mutex_audioTask / audioTask 是
  //   3.0.13 时代的东西, 本版 2.0.6 fork 里根本不存在, 留着会误导并发改造)。
  // 注意: inBufferFilled()/getBitRate()/getCodecname() 等只读访问器不持此锁 —— 它们只读单个
  //       标量, 任意任务调用都安全(Web 诊断页/主循环都靠这个)。
  SemaphoreHandle_t audioMutex = nullptr;
  void lockAudio();
  void unlockAudio();

  // 泵任务本体与入口(入口是 static: FreeRTOS 只接受 C 函数指针)
  static void pumpEntry(void* arg);
  void pumpBody();
  void applyPendingTitle();          // 把泵任务暂存的曲名落到 gState(★仅主循环调用)

  // ---- 命令执行器(只在主循环 loopTask 运行: gState String 写 / metaClient / connecttohost) ----
  void execPlayUrl(const String& url);
  void execPlayIdx(int idx);

  // ---- 播放前编码探测(本板可播性闸门) ----
  // 返回: 1 = 可播(MP3/WAV/AAC 系)  2 = 本板不支持(连流前跳过并自动下一台)  0 = 未知(交给库尝试)
  int  probeCodec(const String& url);
  int  unsupportedStreak = 0;          // 连续跳过的不支持电台数(防死循环, 满一圈即停)
  // 待执行的"跳过下一台"。★必须做成跨主循环迭代, 不能直接 execStep():
  //   跳过是 execPlayUrl -> execStep -> execPlayUrl 的互相调用。若整表都是本板不支持的编码,
  //   递归深度会等于电台数 —— ① loopTask 栈只有 8KB, 几十层就爆(表现为崩溃重启);
  //   ② 递归期间 gLoopTick 不推进, 单次超过失速看门狗的 15s 就被判"主循环已停"而重启
  //      -> 变成"一开机就重启"的死循环(还看不出真因)。改成置标志、由 loop() 下一圈接着跳,
  //   栈深恒为 1, 且每圈都喂看门狗, 期间 UI/Web 也照常响应。
  int8_t  skipNext = 0;                // 0=无; +1/-1 = 下一圈跳向 下一台/上一台
  void execStop();
  void execReconnect();
  void execToggle();
  void execStep(int dir);              // dir=+1 下一台 / -1 上一台(支持连发合并成 ±N)
  void execSleep(int min);             // 睡眠定时器执行器: 仅主循环调用(与 processCmd 同线程)
  void execSleepPowerOff(int min);    // 定时关机执行器: 同上, 额外把 sleepToPowerOff 置真

  // ---- SD 本地播放执行器(阶段②; 全部仅主循环调用) ----
  void execSdPlay(int idx);            // 播放 SD 列表第 idx 个文件
  void execSdNext();                   // 按当前循环方式取下一首(顺序/随机; 见 execSdNext 实现)
  void execSdExit();                   // 退出 SD 模式, 回到进入 SD 前的那台网络电台
  int  mSdLastIdx = -1;                // 上次播的 SD 序号(重播同一首时用)
  uint32_t mSdRand = 0x2545F491UL;     // 随机播放用的 LCG 种子(固定初值 => 结果可复现, 便于排查)
  bool mSdReturnArmed = false;         // 进 SD 前是否记下了"该回哪台电台"(无电台可回时为 false)
  // SBR 开关的本地镜像(真实开关在第三方库的 AACSetSbrEnabled; 这里只便于回显/查询)
  bool mSbrEnabled = false;

  // 欠载(underrun)监测与自适应降级
  void updateAudioHealth();
  uint32_t healthMs   = 0;
  int      lowWaterCnt = 0;
  bool     metaAutoOff = false;   // 是否已被自动降级(避免重复打印)
  uint32_t loopCnt     = 0;
  uint32_t loopHzMs    = 0;
  uint32_t prevInFill  = 0;       // 上一圈音频输入缓冲填充量(用于"真有数据流入"判定)

  // 睡眠定时器倒计时(阶段①): 上次"秒"递减的时刻; 每过 1s 把 sleepRemainSec 减 1。
  uint32_t mSleepMs = 0;

  // ---- 切台静音/防爆音 ----
  // 根因(2026-09-17): 2.0.6 库的 stopSong() 只 memset(m_outBuff,0)+i2s_zero_dma_buffer(),
  // 不调 i2s_stop() —— I2S 外设在切台间隙一直跑、只是 DMA 被清零。新流起播瞬间是 0→首样本硬跳变,
  // 不同采样率还会触发 i2s_set_clk 重时钟, 表现为"嗤嗤/爆破音"。3.0.13(NEW I2S 驱动)stop 时会真正
  // 停通道(干净静音), 所以之前没这问题。
  // 修复: 切台前把音量压到 0(库 Gain() 在 m_vol=0 时强制 DOUT=0 -> 功放放大 0V=真静音),
  // 等新流真正出声(运行+码率>0+缓冲有数据)后再分 ~8 档平滑 ramp 回原值, 既灭间隙嘶声也灭起播爆破音。
  // 注意: 这里用的是库 audio.setVolume(0), 不写 store, 不改动用户保存的音量(gState.volume)。
  uint8_t  m_muteRampStep = 0;    // 0=空闲/完成 1=等待新流出声 2=正在 ramp 恢复
  uint32_t m_muteRampMs   = 0;    // 上次 ramp 步进时间戳
  int8_t   m_muteTarget   = 0;    // 要恢复到的音量(gState.volume)
  int8_t   m_muteCur      = 0;    // 当前已设置的音量(0..VOLUME_MAX)

  // 元数据读取状态机
  WiFiClient metaClient;
  String  metaHost; int metaPort = 80; String metaPath = "/";
  int metaState = 0;   // 0空闲 1读响应头 2丢弃音频字节 3读长度字节 4读元数据块
  int metaMetaint = 0; // 音频字节间隔(来自 icy-metaint)
  int metaCount  = 0;  // 当前阶段剩余字节
  int metaPos    = 0;
  char metaBuf[512];
  uint8_t metaDrop[128];   // 批量丢弃音频字节的暂存(避免逐字节 read 的高调用开销)
  String metaHdr;      // 响应头累积缓冲(状态1)
  uint32_t metaRetryMs = 0;  // 元数据断线后自愈的重试冷却(避免每帧狂连)
};

// ★统一编码转换入口(2026-10-07 公开): 把来自外部数据源的字符串(ICY 曲名、
//   stations.json 里的台名/分类、SD 卡文件名、天气城市名)统一转成 UTF-8。
//   判别顺序: 合法 UTF-8(先试双重编码还原) → 像 GB2312 则查表转 → 其余按 Latin-1 升位。
//   为什么必须有: 屏上 drawUTF8 遇到非法 UTF-8 会【整字跳过】(表现为空方块),
//   而后台 JSON 按 UTF-8 声明, 坏字节会让浏览器显示乱码 —— 两边都得先转成 UTF-8。
String icyToUtf8(const char* s);
