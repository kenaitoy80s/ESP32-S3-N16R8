// serial_toggle.cpp —— V1.21: 串口调试开关的实体变量(说明见 serial_toggle.h)
#include "serial_toggle.h"
volatile bool gSerialOn = true;
