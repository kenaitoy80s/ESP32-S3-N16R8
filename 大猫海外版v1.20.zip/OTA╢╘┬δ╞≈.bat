
@echo off
setlocal
cd /d "%~dp0"
title OTA Firmware Verifier

echo ============================================================
echo   OTA Firmware Verifier
echo   Checks version, file size, SHA256 and manifest consistency
echo ============================================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python was not found.
    pause
    exit /b 1
)

python "%~dp0tools\ota_package.py" verify %*
set "VERIFY_RC=%ERRORLEVEL%"

echo.
if "%VERIFY_RC%"=="0" (
    echo [SUCCESS] OTA firmware verification passed.
) else (
    echo [FAILED] Verification failed. Do NOT upload this firmware.
)
pause
exit /b %VERIFY_RC%
