@echo off
setlocal
cd /d "%~dp0"
title OTA Firmware Generator

echo ============================================================
echo          Da Mao Overseas OTA Firmware Generator
echo          Uses original compile.cmd - No flashing
echo ============================================================
echo.

if not exist "%~dp0src\config.h" (
    echo [ERROR] src\config.h was not found.
    pause
    exit /b 1
)

if not exist "%~dp0compile.cmd" (
    echo [ERROR] compile.cmd was not found.
    pause
    exit /b 1
)

if not exist "%~dp0tools\ota_package.py" (
    echo [ERROR] tools\ota_package.py was not found.
    pause
    exit /b 1
)

rem Read FW_VERSION only. Never modify config.h.
rem Read FW_VERSION from config.h (read only)
set "CURRENT_VERSION="

for /f tokens^=2^ delims^=^" %%V in ('findstr /C:"#define FW_VERSION" "%~dp0src\config.h"') do (
    set "CURRENT_VERSION=%%V"
)

if not defined CURRENT_VERSION (
    echo [ERROR] Cannot read FW_VERSION from src\config.h.
    pause
    exit /b 1
)

echo.
echo.
echo Current source version: %CURRENT_VERSION%
echo.
echo ============================================================
echo.
echo This tool will generate OTA firmware: %CURRENT_VERSION%
echo.
echo src\config.h is READ ONLY.
echo No source version will be changed.
echo ============================================================
echo.

choice /C YN /N /M "Continue to compile and package? [Y/N] "

if errorlevel 2 (
    echo.
    echo [CANCELLED] No firmware was generated.
    pause
    exit /b 0
)

echo.
where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python was not found.
    pause
    exit /b 1
)

python "%~dp0tools\ota_package.py" prepare
if errorlevel 1 (
    echo [ERROR] Pre-build check failed.
    pause
    exit /b 1
)

echo.
echo [1/2] Running original compile.cmd...
call "%~dp0compile.cmd"
set "BUILD_RC=%ERRORLEVEL%"

if not "%BUILD_RC%"=="0" (
    echo.
    echo [FAILED] Compilation returned error code %BUILD_RC%.
    echo Previous successful OTA package will not be replaced.
    pause
    exit /b %BUILD_RC%
)

echo.
echo [2/2] Checking and packaging OTA firmware...
python "%~dp0tools\ota_package.py" package
if errorlevel 1 (
    echo.
    echo [FAILED] OTA packaging failed.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo [SUCCESS] OTA firmware package created.
echo Version: %CURRENT_VERSION%
echo.
echo Please run OTA Verifier.bat to verify the package.
echo ============================================================
pause
exit /b 0