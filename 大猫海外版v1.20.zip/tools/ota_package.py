# -*- coding: utf-8 -*-
"""大猫海外版 OTA 包装与核验工具；只包装原工程 compile.cmd 生成的 BIN。"""
import os, sys, re, json, time, hashlib, shutil
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).resolve().parent.parent
CONFIG = ROOT / "src" / "config.h"
BUILD_NAME = "wrb_s3p"
BIN_NAME = "webradio-s3p.ino.bin"
OTA_LIMIT = 3 * 1024 * 1024
STATE = Path(os.environ.get("TEMP") or os.environ.get("TMP") or r"C:\Windows\Temp") / "wrb_s3p_ota_build_start.json"
OUT = ROOT / "firmware"
MANIFEST_NAME = "ota_manifest.json"

def say(s):
    print(s, flush=True)

def read_version():
    if not CONFIG.is_file():
        raise RuntimeError(f"找不到版本配置：{CONFIG}")
    raw = CONFIG.read_text(encoding="utf-8-sig", errors="replace")
    m = re.search(r'^\s*#\s*define\s+FW_VERSION\s+"([^"]+)"', raw, re.M)
    if not m:
        raise RuntimeError('在 src/config.h 找不到 #define FW_VERSION "..."')
    return m.group(1).strip()

def build_dir():
    tmp = os.environ.get("TEMP") or os.environ.get("TMP") or r"C:\Windows\Temp"
    try:
        tmp.encode("ascii")
        base = Path(tmp)
    except UnicodeEncodeError:
        base = Path(r"C:\wrb_s3p_env")
    return base / BUILD_NAME

def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def prepare():
    if not CONFIG.is_file():
        raise RuntimeError(f"工程目录不正确：缺少 {CONFIG}")
    STATE.parent.mkdir(parents=True, exist_ok=True)
    STATE.write_text(json.dumps({"start": time.time(), "root": str(ROOT)}, indent=2), encoding="utf-8")
    say(f"工程目录：{ROOT}")
    say(f"当前源码版本：{read_version()}")
    say(f"编译产物预期目录：{build_dir()}")
    say("已记录本次编译开始时间。")

def package():
    if not STATE.is_file():
        raise RuntimeError("没有编译前记录。请从“OTA生成器.bat”启动，不要单独运行 package。")
    st = json.loads(STATE.read_text(encoding="utf-8"))
    if Path(st.get("root", "")).resolve() != ROOT.resolve():
        raise RuntimeError("编译开始记录属于另一个工程目录。")
    started = float(st["start"])
    src = build_dir() / BIN_NAME
    if not src.is_file():
        raise RuntimeError(f"找不到编译产物：{src}")
    if src.stat().st_mtime < started - 5:
        raise RuntimeError("BIN 修改时间早于本次编译开始，疑似旧固件；拒绝打包。")
    size = src.stat().st_size
    if size <= 0:
        raise RuntimeError("BIN 文件大小为 0。")
    if size > OTA_LIMIT:
        raise RuntimeError(f"BIN 大小 {size:,} 超过 OTA 分区上限 {OTA_LIMIT:,} bytes。")

    version = read_version()
    safe = re.sub(r"[^A-Za-z0-9._-]+", "_", version)
    OUT.mkdir(parents=True, exist_ok=True)
    dest = OUT / f"webradio-s3p-{safe}-OTA.bin"
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    if dest.exists():
        archive = OUT / "archive"
        archive.mkdir(exist_ok=True)
        old = archive / f"{dest.stem}-{stamp}{dest.suffix}"
        shutil.move(str(dest), str(old))
        say(f"旧同版本固件已归档：{old}")

    shutil.copy2(src, dest)
    digest = sha256(dest)
    built_at = datetime.now().astimezone().isoformat(timespec="seconds")
    manifest = {
        "project": "大猫海外版", "version": version, "firmware_file": dest.name,
        "size_bytes": dest.stat().st_size, "ota_partition_limit_bytes": OTA_LIMIT,
        "sha256": digest, "built_at_local": built_at, "source_bin": str(src),
        "note": "仅为 OTA app BIN；不是整片 flash/merged/full BIN。"
    }
    (OUT / MANIFEST_NAME).write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "SHA256.txt").write_text(
        f"{digest}  {dest.name}\n版本：{version}\n大小：{size:,} bytes\n", encoding="utf-8")

    # 每个版本独立保存；同版本再次打包时，先归档旧记录，不覆盖丢失。
    record = OUT / f"打包记录{safe}-OTA.txt"
    if record.exists():
        archive = OUT / "archive"
        archive.mkdir(exist_ok=True)
        old_record = archive / f"{record.stem}-{stamp}{record.suffix}"
        shutil.move(str(record), str(old_record))
        say(f"旧打包记录已归档：{old_record}")
    record.write_text(
        f"项目：大猫海外版\n版本：{version}\n固件：{dest.name}\n"
        f"大小：{size:,} bytes\nOTA 分区上限：{OTA_LIMIT:,} bytes\n"
        f"SHA256：{digest}\n生成时间：{built_at}\n\n"
        f"本版新增/修改：待填写\n已修复 BUG：待填写\n已知问题：待填写\n\n"
        f"实机测试状态：尚未测试\n实机测试结果：待实机测试后填写\n\n"
        f"说明：本文件为网页 OTA 使用的 app BIN，不是整片线刷包。\n",
        encoding="utf-8")

    STATE.unlink(missing_ok=True)
    say("OTA 包生成成功：")
    say(f"  固件：{dest}")
    say(f"  版本：{version}")
    say(f"  大小：{size:,} / {OTA_LIMIT:,} bytes")
    say(f"  SHA256：{digest}")
    say(f"  清单：{OUT / MANIFEST_NAME}")
    say(f"  版本打包记录：{record}")

def verify(bin_arg=None):
    manifest_path = OUT / MANIFEST_NAME
    if not manifest_path.is_file():
        raise RuntimeError(f"找不到清单：{manifest_path}。请先运行 OTA 生成器。")
    m = json.loads(manifest_path.read_text(encoding="utf-8"))
    path = Path(bin_arg).expanduser() if bin_arg else OUT / m["firmware_file"]
    if not path.is_file():
        raise RuntimeError(f"找不到待核验 BIN：{path}")
    actual_size, actual_hash = path.stat().st_size, sha256(path)
    expected_hash = m["sha256"]
    checks = [
        ("文件大小非零", actual_size > 0),
        ("未超过 OTA 分区", actual_size <= int(m.get("ota_partition_limit_bytes", OTA_LIMIT))),
        ("文件大小与清单一致", actual_size == int(m["size_bytes"])),
        ("SHA256 与清单一致", actual_hash.lower() == expected_hash.lower()),
    ]
    checks.append(("文件名与清单一致" if bin_arg is None else "外部文件内容与清单一致",
                   path.name == m["firmware_file"] if bin_arg is None else actual_hash.lower() == expected_hash.lower()))
    say(f"待核验文件：{path}\n清单版本：{m.get('version', '未知')}")
    say(f"实际大小：{actual_size:,} bytes\n实际 SHA256：{actual_hash}\n")
    failed = False
    for label, ok in checks:
        say(f"[{'通过' if ok else '失败'}] {label}")
        failed |= not ok
    if failed:
        raise RuntimeError("至少一项核验失败。请勿上传此文件。")
    say(f"\n核验通过：{m.get('version')} / {path.name}")

def main():
    if len(sys.argv) < 2:
        raise RuntimeError("用法：prepare | package | verify [BIN路径]")
    cmd = sys.argv[1].lower()
    if cmd == "prepare":
        prepare()
    elif cmd == "package":
        package()
    elif cmd == "verify":
        verify(sys.argv[2] if len(sys.argv) > 2 else None)
    else:
        raise RuntimeError(f"未知命令：{cmd}")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        say(f"\n[错误] {e}")
        sys.exit(1)
