// status_hub.cpp —— V1.20 统一系统状态中心(说明见 status_hub.h)
#include "status_hub.h"

#if STATUS_HUB_ENABLE

#include <WiFi.h>
#include <time.h>
#include "freertos/FreeRTOS.h"        // 显式包含: 互斥量 / 临界区所需(不依赖 Arduino.h 的间接包含)
#include "freertos/semphr.h"
#include "esp_timer.h"
#include "esp_system.h"
#include "../config.h"
#include "../player_state.h"
#include "sys_monitor.h"              // SysSnapshot / sysSnapshot() / sysFormatUptime()
#include "status_common.h"            // sysRssiBars() / sysRssiLevelText() / sysPeriodCN()

// ============================================================================
// 一、事件环(RAM, 最近 16 条) + 累计计数
// ============================================================================
#define EV_RING 16
struct EvRec {
  uint32_t up;        // 发生时的开机秒数
  uint32_t epoch;     // 发生时的 UTC 时间戳(未校时 = 0)
  int16_t  code;
  uint8_t  type;
  char     msg[60];            // 一条消息最多约 19 个汉字(够放"断线: 信标超时(信号弱/路由失联)")
};
static EvRec         s_ev[EV_RING];
static uint8_t       s_evHead  = 0;      // 下一个写入位置
static uint8_t       s_evCount = 0;
static uint32_t      s_cnt[4]  = {0, 0, 0, 0};   // 累计: wifi / weather / audio / sd
static portMUX_TYPE  s_mux     = portMUX_INITIALIZER_UNLOCKED;

static uint32_t upSec() { return (uint32_t)(esp_timer_get_time() / 1000000ULL); }

// 截断可能被劈开的 UTF-8 尾字节(strncpy 截在汉字中间会产生非法 UTF-8, 放进 JSON 页面会乱码)
static void utf8Trim(char* s) {
  int n = (int)strlen(s);
  int i = n - 1;
  while (i >= 0 && (((unsigned char)s[i]) & 0xC0) == 0x80) i--;      // 回退到起始字节
  if (i < 0) return;
  const unsigned char c = (unsigned char)s[i];
  const int need = (c >= 0xF0) ? 4 : (c >= 0xE0) ? 3 : (c >= 0xC0) ? 2 : 1;
  if (n - i < need) s[i] = 0;                                         // 这个字符不完整 -> 去掉
}

void statusEvent(StatusEvType t, int code, const char* msg) {
  EvRec r;
  r.up    = upSec();
  r.epoch = timeSynced() ? (uint32_t)time(nullptr) : 0;
  r.code  = (int16_t)code;
  r.type  = (uint8_t)t;
  strncpy(r.msg, msg ? msg : "", sizeof(r.msg) - 1);
  r.msg[sizeof(r.msg) - 1] = 0;
  utf8Trim(r.msg);
  portENTER_CRITICAL(&s_mux);                    // 只拷贝固定大小的结构体, 不分配内存
  s_ev[s_evHead] = r;
  s_evHead = (uint8_t)((s_evHead + 1) % EV_RING);
  if (s_evCount < EV_RING) s_evCount++;
  if ((uint8_t)t < 4) s_cnt[t]++;
  portEXIT_CRITICAL(&s_mux);
}

// ============================================================================
// 二、Wi-Fi: 断线原因 / 最近 10 分钟断线次数
// ============================================================================
static uint32_t s_discUp[8] = {0};     // 最近 8 次断线的开机秒数(环形)
static uint8_t  s_discIdx   = 0;
static uint32_t s_discTotal = 0;
static uint32_t s_gotIp     = 0;

static const char* wifiReasonText(int r) {
  switch (r) {
    case 2:   return "认证过期";
    case 8:   return "主动断开";
    case 15:  return "四次握手超时";
    case 200: return "信标超时(信号弱/路由失联)";
    case 201: return "找不到热点";
    case 202: return "认证失败(密码?)";
    case 203: return "关联失败";
    case 204: return "握手超时";
    case 205: return "连接失败";
    default:  return nullptr;
  }
}

void statusWifiDisconnected(int reason) {
  const uint32_t up = upSec();
  portENTER_CRITICAL(&s_mux);
  s_discUp[s_discIdx] = up;
  s_discIdx = (uint8_t)((s_discIdx + 1) % 8);
  s_discTotal++;
  portEXIT_CRITICAL(&s_mux);
  char m[60];
  const char* t = wifiReasonText(reason);
  if (t) snprintf(m, sizeof(m), "断线: %s", t);
  else   snprintf(m, sizeof(m), "断线: 原因码 %d", reason);
  statusEvent(EV_WIFI, reason, m);
}

void statusWifiGotIp() {
  s_gotIp++;
  if (s_gotIp > 1) statusEvent(EV_SYS, 0, "Wi-Fi 重新连上(已获取 IP)");   // 第一次(开机连网)不记, 只记"后来的重连"
}

// ============================================================================
// 三、NTP: 最近一次校时
// ============================================================================
static volatile uint32_t s_ntpEpoch = 0;     // 最近一次成功校时的 UTC 时间戳
static volatile uint32_t s_ntpUp    = 0;
static volatile uint32_t s_ntpCount = 0;

void statusNtpSynced() {                      // 在 lwIP 任务里被调到: 只记几个数, 不做耗时操作
  s_ntpEpoch = (uint32_t)time(nullptr);
  s_ntpUp    = upSec();
  const uint32_t c = s_ntpCount + 1;
  s_ntpCount = c;
  if (c == 1) statusEvent(EV_TIME, 0, "NTP 首次校时成功");   // 之后每小时的例行校时不再记, 免得把环刷满
}

// ============================================================================
// 四、天气: 请求结果 / 错误码 / 重试时间(主循环里调用)
// ============================================================================
struct WxDiag {
  uint8_t  state;          // 0=等待更新 1=正常 2=请求失败 3=数据无效
  int      code;
  char     stage[10];
  char     err[56];
  uint16_t fails;          // 连续失败次数
  uint32_t totalFails;
  uint32_t lastOkUp;
  uint32_t lastOkEpoch;
  uint32_t nextUp;         // 下次尝试的开机秒数
};
static WxDiag s_wx = {};

static void wxErrText(int code, const char* stage, char* o, size_t n) {
  const char* st = (stage && *stage) ? stage : "天气";
  const char* d = nullptr;
  switch (code) {
    case -1:   d = "连接失败"; break;
    case -2:   d = "发送请求失败"; break;
    case -3:   d = "发送数据失败"; break;
    case -4:   d = "未连接"; break;
    case -5:   d = "连接中断"; break;
    case -7:   d = "对方不是 HTTP 服务"; break;
    case -8:   d = "内存不足"; break;
    case -11:  d = "读取超时"; break;
    case -100: d = "begin 失败"; break;
    case -101: d = "返回空内容"; break;
    case -102: d = "JSON 解析失败"; break;
    case -103: d = "返回缺少 current 字段"; break;
    default:   break;
  }
  if (d)            snprintf(o, n, "%s: %s(%d)", st, d, code);
  else if (code > 0) snprintf(o, n, "%s: HTTP %d", st, code);
  else               snprintf(o, n, "%s: 错误码 %d", st, code);
}

void statusWxResult(bool ok, int code, const char* stage, uint32_t nextGapMs) {
  const uint32_t up = upSec();
  s_wx.code   = code;
  s_wx.nextUp = up + nextGapMs / 1000UL;
  strncpy(s_wx.stage, stage ? stage : "", sizeof(s_wx.stage) - 1);
  s_wx.stage[sizeof(s_wx.stage) - 1] = 0;
  utf8Trim(s_wx.stage);
  if (ok) {
    s_wx.state       = 1;
    s_wx.fails       = 0;
    s_wx.err[0]      = 0;
    s_wx.lastOkUp    = up;
    s_wx.lastOkEpoch = timeSynced() ? (uint32_t)time(nullptr) : 0;
  } else {
    s_wx.state = (code == -102 || code == -103) ? 3 : 2;
    if (s_wx.fails < 65535) s_wx.fails++;
    s_wx.totalFails++;
    wxErrText(code, s_wx.stage, s_wx.err, sizeof(s_wx.err));
    utf8Trim(s_wx.err);
    statusEvent(EV_WEATHER, code, s_wx.err);
  }
}

// ============================================================================
// 五、播放状态: 只读现有 gState + 边沿检测(进入"重连/错误"时记一次, 不新增任何音频检测)
// ============================================================================
// 0=正常/其它 1=网台重连中 2=网台读取失败 3=SD 错误
static uint8_t classifyStatus(const String& st) {
  if (st.indexOf("重连") >= 0) return 1;
  if (st.startsWith("SD") &&
      (st.indexOf("失败") >= 0 || st.indexOf("未挂载") >= 0 || st.indexOf("无音频") >= 0 || st.indexOf("不存在") >= 0)) return 3;
  if (st.indexOf("失败") >= 0) return 2;
  return 0;
}

static uint8_t  s_prevCls  = 0;
static uint32_t s_prevDec  = 0;
static bool     s_prevInit = false;

static void playerEdge(const StatusPlayerInfo& pi) {
  const uint8_t c = classifyStatus(gState.status);
  if (c != s_prevCls) {
    if (c == 1)      statusEvent(EV_AUDIO, 1, "网台重连中");
    else if (c == 2) statusEvent(EV_AUDIO, 2, "网台读取失败");
    else if (c == 3) {
      char m[60];
      snprintf(m, sizeof(m), "%s", gState.status.c_str());
      statusEvent(EV_SD, 3, m);
    }
    s_prevCls = c;
  }
  if (s_prevInit && pi.decodeErr > s_prevDec) {
    char m[60];
    snprintf(m, sizeof(m), "解码错误 +%u", (unsigned)(pi.decodeErr - s_prevDec));
    statusEvent(EV_AUDIO, 4, m);
  }
  s_prevDec  = pi.decodeErr;
  s_prevInit = true;
}

// 统一的播放状态文字: 正在连接 / 正在缓冲 / 正在播放 / 重连中 / 播放错误(另: 已停止 / 未连网)
static const char* playerStateText() {
  const String& st = gState.status;
  if (!gState.sdActive && !gState.wifiConnected) return "未连网";
  const uint8_t c = classifyStatus(st);
  if (c == 1) return "重连中";
  if (c >= 2) return "播放错误";
  if (st.indexOf("连接中") >= 0) return "正在连接";
  if (gState.playing && gState.buffering) return "正在缓冲";
  if (gState.playing) return "正在播放";
  return "已停止";
}

// ============================================================================
// 六、JSON 构建(手写, 无外部依赖): 只在主循环里调用
// ============================================================================
static void jSep(String& o) {                       // 需要时补逗号: 上一个字符是 { [ : 则不补
  if (o.length() == 0) return;
  const char c = o[o.length() - 1];
  if (c != '{' && c != '[' && c != ':') o += ',';
}
static void jKey(String& o, const char* k) { jSep(o); if (k) { o += '"'; o += k; o += "\":"; } }
static void jEscape(String& o, const char* s) {
  o += '"';
  for (; *s; ++s) {
    const unsigned char c = (unsigned char)*s;
    if (c == '"' || c == '\\') { o += '\\'; o += (char)c; }
    else if (c < 0x20)         { char b[8]; snprintf(b, sizeof(b), "\\u%04x", c); o += b; }
    else                       { o += (char)c; }
  }
  o += '"';
}
static void jOpenObj(String& o, const char* k) { jKey(o, k); o += '{'; }
static void jCloseObj(String& o)               { o += '}'; }
static void jOpenArr(String& o, const char* k) { jKey(o, k); o += '['; }
static void jCloseArr(String& o)               { o += ']'; }
static void jStr(String& o, const char* k, const char* v)  { jKey(o, k); jEscape(o, v ? v : ""); }
static void jStrS(String& o, const char* k, const String& v) { jStr(o, k, v.c_str()); }
static void jInt(String& o, const char* k, long v)         { jKey(o, k); o += String(v); }
static void jBool(String& o, const char* k, bool v)        { jKey(o, k); o += v ? "true" : "false"; }
static void jNull(String& o, const char* k)                { jKey(o, k); o += "null"; }
static void jFlt(String& o, const char* k, float v, int d) { jKey(o, k); o += String(v, d); }

static void fmtUp(char* b, size_t n, uint32_t sec) {
  const uint32_t m = sec / 60;
  snprintf(b, n, "%u:%02u", (unsigned)(m / 60), (unsigned)(m % 60));
}
static void fmtLocal(char* b, size_t n, uint32_t epoch) {           // "11-01 14:20:05"
  time_t t = (time_t)epoch;
  struct tm lt;
  localtime_r(&t, &lt);
  snprintf(b, n, "%02d-%02d %02d:%02d:%02d", lt.tm_mon + 1, lt.tm_mday, lt.tm_hour, lt.tm_min, lt.tm_sec);
}
static const char* resetText() {
  switch (esp_reset_reason()) {
    case ESP_RST_POWERON:   return "上电启动";
    case ESP_RST_SW:        return "软件重启";
    case ESP_RST_PANIC:     return "程序崩溃重启";
    case ESP_RST_INT_WDT:   return "中断看门狗";
    case ESP_RST_TASK_WDT:  return "任务看门狗";
    case ESP_RST_WDT:       return "看门狗";
    case ESP_RST_BROWNOUT:  return "欠压(供电不足)";
    case ESP_RST_DEEPSLEEP: return "深度休眠唤醒";
    default:                return "其它";
  }
}

static void buildJson(String& o, const StatusPlayerInfo& pi) {
  const SysSnapshot& sy = sysSnapshot();
  const uint32_t now = upSec();
  char b[40];

  o = "";
  o += '{';
  jStr(o, "fw", FW_VERSION);
  jInt(o, "genUp", (long)now);                            // 生成时的开机秒数(页面据此判断数据是否过期)

  // ---- 时间与日历 ----
  jOpenObj(o, "time");
  {
    const bool synced = timeSynced();
    jBool(o, "synced", synced);
    if (synced) {
      struct tm t; timeLocal(&t);
      snprintf(b, sizeof(b), "%02d:%02d:%02d", t.tm_hour, t.tm_min, t.tm_sec);   jStr(o, "local24", b);
      const int h12 = (t.tm_hour % 12 == 0) ? 12 : (t.tm_hour % 12);
      snprintf(b, sizeof(b), "%02d:%02d", h12, t.tm_min);                        jStr(o, "clock12", b);
      jStr(o, "period", sysPeriodCN(t.tm_hour));
      snprintf(b, sizeof(b), "%04d-%02d-%02d", t.tm_year + 1900, t.tm_mon + 1, t.tm_mday);   jStr(o, "date", b);
      jStr(o, "weekday", WEEKDAY_CN[t.tm_wday]);
      const LunarInfo lun = lunarFromSolar(t.tm_year + 1900, t.tm_mon + 1, t.tm_mday);
      jStrS(o, "lunar", lun.ok ? (String(lun.ganZhiYear) + lun.zodiac + "年" + lun.monthDay) : String(""));
    } else {
      jStr(o, "local24", "时间未同步");                     // 未校时明确提示, 绝不显示假时间
      jNull(o, "clock12"); jNull(o, "period"); jNull(o, "date"); jNull(o, "weekday"); jNull(o, "lunar");
    }
    jStr(o, "tz", TZ_STR);
    jStr(o, "tzNote", "旧金山(太平洋时间, 夏令时自动)");
    jOpenObj(o, "ntp");
    {
      const uint32_t ne = s_ntpEpoch;
      jStr(o, "state", ne ? "已同步" : "未同步");
      if (ne) {
        fmtLocal(b, sizeof(b), ne);                        jStr(o, "lastSync", b);
        jInt(o, "lastSyncAgoMin", (long)((now - s_ntpUp) / 60));
      } else {
        jNull(o, "lastSync"); jNull(o, "lastSyncAgoMin");
      }
      jInt(o, "count", (long)s_ntpCount);
    }
    jCloseObj(o);
  }
  jCloseObj(o);

  // ---- 天气 ----
  jOpenObj(o, "weather");
  {
    static const char* const kSt[4] = { "等待更新", "正常", "请求失败", "数据无效" };
    const bool ok = gState.wx.valid;
    jStr(o, "state", kSt[s_wx.state & 3]);
    jBool(o, "ok", ok);
    jStrS(o, "city", gState.wx.city);
    jStrS(o, "text", gState.wx.text);
    jInt(o, "tempC", ok ? gState.wx.tempC : 0);
    jInt(o, "feelsC", ok ? gState.wx.feelsC : 0);
    jInt(o, "humidity", ok ? gState.wx.humidity : 0);
    jStrS(o, "windDir", gState.wx.windDir);
    jStrS(o, "windScale", gState.wx.windScale);            // 风力级数(蒲福风级), 页面补"级"
    jInt(o, "tminC", ok ? gState.wx.tminC : 0);
    jInt(o, "tmaxC", ok ? gState.wx.tmaxC : 0);
    jInt(o, "ageMin", ok ? (long)((millis() - gState.wx.updMs) / 60000UL) : 0);
    if (s_wx.lastOkEpoch) { fmtLocal(b, sizeof(b), s_wx.lastOkEpoch); jStr(o, "lastOk", b); } else jNull(o, "lastOk");
    jInt(o, "fails", s_wx.fails);
    jInt(o, "totalFails", (long)s_wx.totalFails);
    jStr(o, "err", s_wx.err);
    jInt(o, "code", s_wx.code);
    jInt(o, "nextRetrySec", (s_wx.nextUp > now) ? (long)(s_wx.nextUp - now) : 0);
    jStr(o, "source", "open-meteo");
  }
  jCloseObj(o);

  // ---- Wi-Fi 与网络(RSSI 与 TFT 同一个平滑后的数据源) ----
  jOpenObj(o, "wifi");
  {
    const bool con = gState.wifiConnected;
    const int rssi = (con && sy.wifiOk) ? sy.rssiShown : 0;
    const int bars = sysRssiBars(rssi);
    jBool(o, "connected", con);
    jStr(o, "ssid", con ? WiFi.SSID().c_str() : "");
    jStrS(o, "ip", gState.ip);
    jInt(o, "rssi", rssi);
    jFlt(o, "rssiAvg", sy.rssiAvg, 1);
    jInt(o, "bars", bars);
    jStr(o, "level", sysRssiLevelText(bars, con && rssi != 0));
    jInt(o, "disc", (long)s_discTotal);
    jInt(o, "gotIp", (long)s_gotIp);
    long recent = 0;
    for (int i = 0; i < 8; i++) if (s_discUp[i] && (now - s_discUp[i]) <= 600) recent++;
    jInt(o, "disc10min", recent);
  }
  jCloseObj(o);

  // ---- S3 系统状态 ----
  jOpenObj(o, "sys");
  {
    jBool(o, "tempOk", sy.tempOk);
    if (sy.tempOk) { jFlt(o, "chipTempC", sy.tempC, 1); jFlt(o, "tempMax", sy.tempMax, 1); }
    else           { jNull(o, "chipTempC"); jNull(o, "tempMax"); }
    jStr(o, "tempNote", "ESP32-S3 芯片内部温度(非室温)");
    jInt(o, "cpuMhz", sy.cpuMhz);
    jInt(o, "upSec", (long)now);
    fmtUp(b, sizeof(b), now);                              jStr(o, "upText", b);
    jInt(o, "heapFreeKB", (long)(ESP.getFreeHeap() / 1024));
    jInt(o, "heapMinKB", (long)(ESP.getMinFreeHeap() / 1024));
    jInt(o, "psramTotalKB", (long)(ESP.getPsramSize() / 1024));
    jInt(o, "psramFreeKB", (long)(ESP.getFreePsram() / 1024));
    jStr(o, "reset", resetText());
  }
  jCloseObj(o);

  // ---- 收音机播放 ----
  jOpenObj(o, "audio");
  {
    jStr(o, "state", playerStateText());
    jStr(o, "mode", gState.sdActive ? "SD 本地播放" : "网络电台");
    jStrS(o, "station", gState.sdActive ? gState.sdName : gState.stationName);
    jStrS(o, "title", gState.title);
    jInt(o, "volume", gState.volume);
    jInt(o, "volumeMax", VOLUME_MAX);
    jStrS(o, "codec", String(gState.codec));
    jStrS(o, "bitrate", String(gState.bitrate));
    jStrS(o, "status", gState.status);
    jBool(o, "running", pi.running);
    jBool(o, "buffering", gState.buffering);
    jOpenObj(o, "buf");
    jInt(o, "bytes", (long)pi.bufFilled);
    jInt(o, "cap", (long)pi.bufCap);
    jInt(o, "pct", pi.bufCap ? (long)((uint64_t)pi.bufFilled * 100ULL / pi.bufCap) : 0);
    jCloseObj(o);
    jInt(o, "dataAgeMs", gState.playing ? (long)(millis() - gState.lastDataMs) : 0);
    jInt(o, "decodeErr", (long)pi.decodeErr);
    jBool(o, "sdActive", gState.sdActive);                 // 当前音源是否为 SD 卡(SD 挂载详情见 /api/state 的 sdMounted)
  }
  jCloseObj(o);

  // ---- 简要错误记录(RAM 环, 最近 16 条; 重启清空) ----
  jOpenObj(o, "errors");
  {
    EvRec snap[EV_RING];
    uint8_t cnt, head;
    uint32_t c4[4];
    portENTER_CRITICAL(&s_mux);
    cnt = s_evCount; head = s_evHead;
    memcpy(snap, s_ev, sizeof(snap));
    memcpy(c4, s_cnt, sizeof(c4));
    portEXIT_CRITICAL(&s_mux);
    jInt(o, "wifi",    (long)c4[EV_WIFI]);
    jInt(o, "weather", (long)c4[EV_WEATHER]);
    jInt(o, "audio",   (long)c4[EV_AUDIO]);
    jInt(o, "sd",      (long)c4[EV_SD]);
    jOpenArr(o, "events");
    static const char* const kTy[6] = { "wifi", "weather", "audio", "sd", "time", "sys" };
    for (uint8_t i = 0; i < cnt; i++) {                     // 最新的在前
      const EvRec& e = snap[(head + EV_RING - 1 - i) % EV_RING];
      jOpenObj(o, nullptr);
      fmtUp(b, sizeof(b), e.up);                            jStr(o, "up", b);
      if (e.epoch) { fmtLocal(b, sizeof(b), e.epoch); jStr(o, "at", b); } else jNull(o, "at");
      jStr(o, "type", kTy[e.type < 6 ? e.type : 5]);
      jInt(o, "code", e.code);
      jStr(o, "msg", e.msg);
      jCloseObj(o);
    }
    jCloseArr(o);
  }
  jCloseObj(o);

  o += '}';
}

// ============================================================================
// 七、对外: 主循环重建 / 任意任务拷贝
// ============================================================================
static SemaphoreHandle_t s_jsonMtx = nullptr;
static String            s_json;                 // 最新 JSON(主循环写, 异步任务锁内拷贝)
static uint32_t          s_lastBuild = 0;
static bool              s_built = false;

void statusRebuildIfDue(const StatusPlayerInfo& pi) {
  if (!s_jsonMtx) {
    s_jsonMtx = xSemaphoreCreateMutex();
    s_json.reserve(6144);                        // 一次预留, 之后赋值复用同一块内存(避免反复分配造成碎片)
  }
  playerEdge(pi);                                // 每次调用都做边沿检测(很轻: 只比较一个状态字符串)
  const uint32_t nowMs = millis();
  if (s_built && (uint32_t)(nowMs - s_lastBuild) < (uint32_t)STATUS_JSON_MS) return;
  s_lastBuild = nowMs;
  s_built = true;

  static String tmp;
  if (tmp.length() == 0) tmp.reserve(6144);
  buildJson(tmp, pi);
  if (s_jsonMtx && xSemaphoreTake(s_jsonMtx, pdMS_TO_TICKS(50)) == pdTRUE) {
    s_json = tmp;
    xSemaphoreGive(s_jsonMtx);
  }
}

void statusJsonCopy(String& out) {
  out = "";
  if (!s_jsonMtx) return;                        // 还没生成过(开机头几秒)
  if (xSemaphoreTake(s_jsonMtx, pdMS_TO_TICKS(100)) == pdTRUE) {
    out = s_json;
    xSemaphoreGive(s_jsonMtx);
  }
}

#endif  // STATUS_HUB_ENABLE
