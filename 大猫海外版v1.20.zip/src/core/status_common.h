// ============================================================================
// status_common.h —— V1.20: TFT 与 Web 后台共用的小函数(保证两边口径一致)
// ----------------------------------------------------------------------------
// 为什么单独放一个新文件名: 之前这三个函数放在 sys_monitor.h 里, 如果你的工程里还留着旧版
// sys_monitor.h(没有这三个函数), status_hub.cpp 就会报"未声明"。新文件名不会和任何旧文件混淆;
// 而且它【不依赖】别的头文件, 只要它在 src/core/ 里, 谁 #include 都能用。
// ============================================================================
#pragma once

// 信号格数: >=-55dBm 4 格 / >=-65 3 格 / >=-75 2 格 / >=-85 1 格 / 其余或未连 0 格(rssi==0 表示未连)
inline int sysRssiBars(int rssi) {
  if (rssi == 0) return 0;
  return (rssi >= -55) ? 4 : (rssi >= -65) ? 3 : (rssi >= -75) ? 2 : (rssi >= -85) ? 1 : 0;
}

// 信号等级文字(后台页面用; 与上面的格数一一对应)
inline const char* sysRssiLevelText(int bars, bool connected) {
  if (!connected) return "未连接";
  return (bars >= 4) ? "极好" : (bars == 3) ? "良好" : (bars == 2) ? "一般" : (bars == 1) ? "较弱" : "很弱";
}

// 时段名: 凌晨 0~5 点 / 上午 6~11 点 / 下午 12~17 点 / 晚上 18~23 点(TFT 顶栏与后台共用)
inline const char* sysPeriodCN(int hour24) {
  return (hour24 < 6) ? "凌晨" : (hour24 < 12) ? "上午" : (hour24 < 18) ? "下午" : "晚上";
}
