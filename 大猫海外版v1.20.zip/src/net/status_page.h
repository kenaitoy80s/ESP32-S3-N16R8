// status_page.h —— V1.20 手机状态页(/status)。单文件 HTML, 无外部资源, 约 5 秒拉一次 /api/status。
// 手机浏览器打开 http://<设备IP>/status 即可(可加到主屏幕)。纯静态字符串, 与 /api/state 一样只读。
#pragma once
#include <Arduino.h>

static const char STATUS_PAGE_HTML[] PROGMEM = R"HTML(<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>大猫收音机 · 状态</title>
<style>
:root{--bg:#f3f4f6;--card:#fff;--tx:#1f2937;--sub:#6b7280;--ok:#16a34a;--warn:#d97706;--bad:#dc2626;--line:#e5e7eb;--acc:#2563eb}
@media(prefers-color-scheme:dark){:root{--bg:#0f172a;--card:#1e293b;--tx:#e5e7eb;--sub:#94a3b8;--line:#334155;--acc:#60a5fa}}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--tx);font:15px/1.5 -apple-system,"PingFang SC","Microsoft YaHei",sans-serif;padding:env(safe-area-inset-top) 10px 24px}
h1{font-size:18px;margin:12px 2px 2px}
#bar{font-size:12px;color:var(--sub);margin:0 2px 8px}
#off{display:none;background:var(--bad);color:#fff;padding:8px 10px;border-radius:8px;margin-bottom:8px;font-size:13px}
.card{background:var(--card);border-radius:12px;padding:10px 12px;margin-bottom:10px;box-shadow:0 1px 2px rgba(0,0,0,.06)}
.card h2{font-size:13px;color:var(--sub);margin:0 0 6px;font-weight:600;letter-spacing:.5px}
.big{font-size:30px;font-weight:600;line-height:1.1}
.row{display:flex;justify-content:space-between;gap:10px;padding:3px 0;border-top:1px solid var(--line)}
.row:first-of-type{border-top:0}
.k{color:var(--sub);white-space:nowrap}.v{text-align:right;word-break:break-all}
.ok{color:var(--ok)}.warn{color:var(--warn)}.bad{color:var(--bad)}
.bars{display:inline-block;vertical-align:-2px;margin-right:6px}
.bars i{display:inline-block;width:4px;margin-right:2px;background:var(--line);border-radius:1px}
.bars i.on{background:var(--ok)}
.ev{font-size:13px;padding:4px 0;border-top:1px solid var(--line)}
.ev b{font-weight:600}.ev small{color:var(--sub)}
.pb{height:8px;background:var(--line);border-radius:4px;overflow:hidden;margin-top:4px}
.pb div{height:100%;background:var(--acc)}
</style></head><body>
<h1>大猫收音机 · 状态</h1>
<div id="bar">正在读取…</div>
<div id="off">连不上设备(可能断电/断网), 稍后自动重试…</div>
<div id="app"></div>
<script>
var $=function(i){return document.getElementById(i)};
function E(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function R(k,v,c){return '<div class="row"><span class="k">'+k+'</span><span class="v '+(c||'')+'">'+v+'</span></div>'}
function bars(n){var h=[5,8,11,14],s='<span class="bars">';for(var i=0;i<4;i++)s+='<i class="'+(i<n?'on':'')+'" style="height:'+h[i]+'px"></i>';return s+'</span>'}
function C(t,b){return '<div class="card"><h2>'+t+'</h2>'+b+'</div>'}
function dash(v,u){return (v==null)?'--':v+(u||'')}
function render(d){
  var t=d.time||{},w=d.weather||{},f=d.wifi||{},s=d.sys||{},a=d.audio||{},e=d.errors||{},h='';
  // 时间与日历
  var tb=t.synced?('<div class="big">'+E(t.clock12)+' <span style="font-size:15px">'+E(t.period)+'</span></div>'
    +R('24 小时制',E(t.local24))+R('日期',E(t.date)+' '+E(t.weekday))+R('农历',E(t.lunar))):
    ('<div class="big warn">时间未同步</div>');
  tb+=R('时区',E(t.tzNote||t.tz));
  var n=t.ntp||{};
  tb+=R('NTP',n.state==='已同步'?('<span class="ok">已同步</span> · '+E(n.lastSync)+'('+n.lastSyncAgoMin+' 分钟前)'):'<span class="warn">未同步</span>');
  h+=C('时间与日历',tb);
  // 天气
  var wc=w.state==='正常'?'ok':(w.state==='等待更新'?'warn':'bad');
  var wb='<div class="big">'+(w.ok?(dash(w.tempC,'°C')+' <span style="font-size:15px">'+E(w.text)+'</span>'):'<span class="'+wc+'">'+E(w.state)+'</span>')+'</div>';
  wb+=R('城市',E(w.city||'--'))+R('湿度',w.ok?w.humidity+'%':'--')+R('风',w.ok?E(w.windDir)+' '+E(w.windScale)+'级':'--')
    +R('今日',w.ok?w.tminC+' ~ '+w.tmaxC+'°C':'--')+R('状态','<span class="'+wc+'">'+E(w.state)+'</span>');
  wb+=R('最近成功',w.lastOk?E(w.lastOk)+'('+w.ageMin+' 分钟前)':'尚未成功');
  if(w.state!=='正常'&&w.state!=='等待更新'||w.fails>0){wb+=R('失败原因','<span class="bad">'+E(w.err||'--')+'</span>')+R('连续失败/累计',w.fails+' / '+w.totalFails)+R('下次重试',w.nextRetrySec+' 秒后')}
  else if(w.state==='等待更新'){wb+=R('下次尝试',w.nextRetrySec>0?w.nextRetrySec+' 秒后':'即将尝试')}
  h+=C('天气',wb);
  // Wi-Fi
  var fb='<div class="big">'+(f.connected?bars(f.bars)+dash(f.rssi,' dBm'):'<span class="bad">未连接</span>')+'</div>';
  fb+=R('信号等级',E(f.level))+R('热点',E(f.ssid||'--'))+R('IP',E(f.ip||'--'))
    +R('断线累计',f.disc+' 次')+R('最近 10 分钟断线',f.disc10min+' 次',f.disc10min>0?'warn':'');
  h+=C('Wi-Fi 与网络',fb);
  // 系统
  var sb='<div class="big">'+(s.tempOk?s.chipTempC+'°C':'--')+' <span style="font-size:13px;color:var(--sub)">S3 芯片内部温度</span></div>';
  sb+=R('本次开机最高',s.tempOk?s.tempMax+'°C':'--')+R('运行时间',E(s.upText)+' (时:分)')+R('CPU 频率',s.cpuMhz+' MHz')
    +R('内存(堆)',s.heapFreeKB+' KB 可用 / 最低 '+s.heapMinKB+' KB')
    +R('PSRAM',s.psramTotalKB?s.psramFreeKB+' / '+s.psramTotalKB+' KB':'无')+R('上次重启原因',E(s.reset));
  h+=C('S3 系统状态',sb);
  // 播放
  var ac=a.state==='正在播放'?'ok':(a.state==='播放错误'||a.state==='重连中'?'bad':'warn');
  var ab='<div class="big '+ac+'">'+E(a.state)+'</div>';
  ab+=R('模式',E(a.mode))+R('电台/文件',E(a.station||'--'))+R('节目',E(a.title||'--'))
    +R('音量',a.volume+' / '+a.volumeMax)+R('编码/码率',E((a.codec||'--')+' '+(a.bitrate||'')));
  var bp=a.buf?a.buf.pct:0;
  ab+=R('音频缓冲',bp+'%('+Math.round((a.buf?a.buf.bytes:0)/1024)+' / '+Math.round((a.buf?a.buf.cap:0)/1024)+' KB)')
    +'<div class="pb"><div style="width:'+Math.min(100,bp)+'%"></div></div>'
    +R('数据间隔',a.dataAgeMs+' ms')+R('解码错误累计',a.decodeErr+'');
  h+=C('收音机',ab);
  // 错误
  var eb=R('Wi-Fi / 天气 / 音频 / SD','<b>'+e.wifi+' / '+e.weather+' / '+e.audio+' / '+e.sd+'</b>');
  var ev=e.events||[];
  if(!ev.length)eb+='<div class="ev" style="color:var(--sub)">暂无记录(重启后清空, 最多保留最近 16 条)</div>';
  for(var i=0;i<ev.length;i++){var x=ev[i];eb+='<div class="ev"><b>'+E(x.type)+'</b> '+E(x.msg)+' <small>('+E(x.at||('开机 '+x.up))+')</small></div>'}
  h+=C('简要错误记录',eb);
  $('app').innerHTML=h;
  $('bar').textContent='固件 '+d.fw+' · 更新于 '+new Date().toLocaleTimeString()+' · 每 5 秒刷新';
}
var busy=false;
function tick(){
  if(busy||document.hidden)return; busy=true;
  var c=new AbortController(),to=setTimeout(function(){c.abort()},4000);
  fetch('/api/status',{cache:'no-store',signal:c.signal}).then(function(r){return r.json()}).then(function(d){
    clearTimeout(to);busy=false;
    if(!d||!d.time){$('bar').textContent='设备刚启动, 状态生成中…';return}
    $('off').style.display='none';render(d);
  }).catch(function(){clearTimeout(to);busy=false;$('off').style.display='block'});
}
tick();setInterval(tick,5000);
document.addEventListener('visibilitychange',function(){if(!document.hidden)tick()});
</script></body></html>)HTML";
