#include "web_server.h"
#include <ESPAsyncWebServer.h>
#include <ArduinoJson.h>
#include "../config.h"
#include "../player_state.h"
#include "../core/station_store.h"
#include "../core/audio_player.h"
#include "../core/sd_card.h"     // 阶段②: 本地 SD 卡(声明 extern 桥接函数; 本 TU 绝不直接碰 SD 卡驱动)
#include "../core/alarm.h"       // 定时开机(闹钟): 配置读/写 + 状态回显
#include <SD_MMC.h>     // 只为 fileSize()(纯查询, 不碰驱动状态)
#include "wifi_portal.h"
#include "../ui/display_ui.h"
#include "../ui/ir_learn.h"   // 红外遥控学习: irlearn=/irclr= 指令 + 状态快照
#include "radio_browser.h"    // 在线电台搜索(radio-browser.info, 2026-10-20 新增)
#include "../core/sys_monitor.h"   // V1.20: TFT 与后台共用的 RSSI/温度等监测数据
#include "../core/status_hub.h"    // V1.20: 统一系统状态中心(/api/status)
#include "status_page.h"           // V1.20: 手机状态页 /status
// (联网数据 时间/农历/天气 的声明已并入 player_state.h)
#include <WiFi.h>       // 多网络凭据页要读 RSSI / 连接状态
#if OTA_ENABLED
#include <Update.h>     // 在线升级: 把收到的固件写进空闲的 ota_1 分区(库内部管分区切换与镜像校验)
#include <ArduinoOTA.h> // 兜底通路: IDE/arduino-cli 走 WiFi(3232)上传, 网页刷挂了还能救
#endif

// ---- 阶段② SD 卡的桥接(定义在 webradio-s3p.ino, 主循环上下文)----
// ★本 TU 运行在 async_tcp 任务里, 【绝不能直接调用 gSd.begin()/scan()】(SD 卡驱动非线程安全,
//   且目录扫描会长时间占总线, 表现为播放卡顿)。这里只调"置标志/读快照"的安全接口。
extern void sdReqScan();       // 异步任务可调: 请求主循环挂载+扫描+重建 JSON
extern void sdReqExit();       // 异步任务可调: 请求主循环退出 SD 音源
extern void sdReqEnter();      // 异步任务可调: 请求主循环进入 SD 文件列表界面
extern bool sdGetJson(String& out);  // 读取主循环已构建好的文件列表 JSON

// ★2026-09-23: 后台"关机"按钮已移除(深度休眠后 Web 服务停止, 无法从后台开机 ⇒ 点了回不来),
//   随之删掉本文件里 enterDeepSleep / gShutdownPending 的 extern 声明 —— 本 TU 已不再引用它们。
//   关机功能本身仍在, 只是入口收敛为硬件: 电源键(GPIO3)长按 / 已学 "power" 遥控键 / 串口 Z,
//   实现仍在 webradio-s3p.ino(见 gShutdownPending 主循环消费处)。
static AsyncWebServer server(80);
static AsyncWebSocket  gWs("/ws");         // yoradio 风格: 所有控制/增删改走 WebSocket 文本指令
static StationStore* pStore = nullptr;
static AudioPlayer* pPlayer = nullptr;
static WiFiPortal*  pPortal = nullptr;
static DisplayUI*   pDisp  = nullptr;
static String gBuild;   // 编译时构建时间, 用于前端检测"页面是否为旧缓存"
// (网页资源已改为 3 个 gzip 数组存于 flash, 见 page_assets.h —— 不再在 RAM 留整页副本)

// 状态快照: 主循环每隔 SNAPSHOT_MS 序列化进 gSnap(持锁), 异步回调只读发送, 避免与主循环写 String 竞争。
static SemaphoreHandle_t gSnapMutex = nullptr;
static String       gSnap;                 // 状态快照(JSON 文本)
static JsonDocument gSnapDoc;              // 复用的 JSON 文档(避免每次重新开大块内存)
static uint32_t     gSnapMs = 0;
static const uint32_t SNAPSHOT_MS = 1200;  // 快照重建间隔(页面每 3s 轮询, 1.2s 足够及时)
// 播放链诊断快照(纯文本)。存在意义: 本机排障时"复制串口日志"门槛高,
// 把关键项直接送到网页 —— 浏览器打开 http://<设备IP>/api/diag 即可判读/截图。
// 与 gSnap 同样只在主循环重建(读 gState 的 String 才安全)。
static String       gDiag;
static volatile bool gStoreChanged = false; // 异步任务改过电台列表 -> 主循环修正 gState
// HTTP 请求计数(异步任务自增, 主循环只读)。排查"后台打不开"的分水岭:
//   浏览器访问时计数在涨 = 请求到达了设备(故障在响应侧); 一直不涨 = 没到设备(网络侧)。
static volatile uint32_t gHttpReq = 0;

// 网页资源: 由 tools/gen_page_gz.py 生成, 四份 gzip 数组存 flash(page_assets.h)。
// 改页面: 编辑 tools/web_page/{index.html,app.css,app.js,bg.js} 后执行 python tools/gen_page_gz.py。
#include "page_assets.h"

// ============================================================================
// 屏幕背景图上传(2026-10-06) —— ★全彩色 RGB565
// ----------------------------------------------------------------------------
// 前端(浏览器)把图片缩放/裁剪/调好色, 转成 RGB565(大端) 的裸字节流,
// 用 fetch POST 直接扔上来 —— 不走 multipart: 省掉前端拼表单的字节(前端 gzip 预算抠得很紧),
// 也省掉边界解析。单张 BG_RGB_BYTES(153600 = 150KB), 两个方向分开传。
// ★为什么能在 1bpp 的 U8g2 上出彩色: 底色由推屏回调 DRAW_TILE 从这张图取,
//   而界面(文字/卡片)仍是 1bpp 模板 —— 详见 display_ui.cpp 里那一大段说明。
//
// 线程分工(严格遵守本工程的异步任务约定):
//   · onBody 回调 = 【Web 异步任务】: 只按 index 把数据写进 PSRAM 缓冲, 不碰文件系统;
//   · bgTick()  = 【主循环】: 校验长度 -> bgSave() 落盘 LittleFS -> invalidate() 强制重画。
//   ★为什么落盘不能就地做: LittleFS 写入会短暂禁用 flash cache 冻核, 在异步任务上下文
//     做会拖累同核的其它任务(与 station_store.cpp 的取舍完全一致)。
// ============================================================================
static uint8_t*        sBgUpBuf  = nullptr;  // PSRAM 上传缓冲(懒分配; 150KB, 不占 DRAM)
static volatile size_t sBgUpGot  = 0;        // 本批已收字节数
static volatile bool   sBgUpFull = false;    // 已收满, 等主循环落盘
static volatile bool   sBgUpBusy = false;    // ★主循环正在读 sBgUpBuf 落盘(2026-10-11): 此间新批次作废
static volatile bool   sBgUpPort = false;    // 本批属于竖屏(true)还是横屏(false)
static volatile bool   sBgUpBad  = false;    // 分配失败/超长 -> 整批作废
static volatile int8_t sBgClear  = -1;       // 删除请求: -1=无; 0=删横屏; 1=删竖屏
static volatile int8_t sBgAlpha  = -1;       // 界面不透明度待应用值: -1=无; 0~100=待写 NVS
static volatile int8_t sBgBright = -1;       // 背景图亮度待应用值: -1=无; 0~100=待写 NVS

// 新一批上传开始: 准备缓冲(bgUpBuf 只分配一次, 之后复用)
static void bgUpReset(bool portrait) {
  // ★2026-10-11: 主循环此刻可能正读 sBgUpBuf 写文件, 若这里并发 memcpy 会写出"半新半旧"的坏图。
  //   直接作废本批(用户重传即可), 绝不并发读写同一块缓冲。
  if (sBgUpBusy) { sBgUpBad = true; return; }
  if (!sBgUpBuf) sBgUpBuf = (uint8_t*)ps_malloc(BG_RGB_BYTES);
  sBgUpBad  = (sBgUpBuf == nullptr);
  sBgUpGot  = 0;
  sBgUpFull = false;
  sBgUpPort = portrait;
  if (sBgUpBad) Serial.printf("[BG  ] 上传缓冲分配失败(需要 %d B PSRAM)\n", (int)BG_RGB_BYTES);
}

// 收到一块数据: 按 index 落位。超长一律拒绝并作废整批, 绝不越界写。
static void bgUpChunk(uint8_t* data, size_t len, size_t index) {
  if (sBgUpBad || !sBgUpBuf) { sBgUpBad = true; return; }
  if (index + len > (size_t)BG_RGB_BYTES) { sBgUpBad = true; return; }
  memcpy(sBgUpBuf + index, data, len);
  sBgUpGot = index + len;
}

#if OTA_ENABLED
// ============================================================================
// 固件在线升级(2026-10-07)
// ----------------------------------------------------------------------------
// 走法与上面的背景图上传【完全同构】: 裸二进制 body(刻意不走 multipart), 由三参数的
// onBody 分块回调接住; 唯一区别是"落到哪儿" —— 背景图落 PSRAM 缓冲, 固件【就地写 flash
// 的 ota_1 分区】。
// ★为什么不需要 2MB 缓冲: Update.write() 是流式的 —— 收一块就写一块, RAM 增量 ≈ 0。
//   这点很关键: 本机内部 RAM 只剩 ~240KB, 整包进内存根本不可能。
// ★为什么不会变砖: 新固件写在【另一块空闲分区】, 旧固件全程完好; Update.end() 会做镜像
//   校验, 失败立即 abort, bootloader 仍从旧分区启动。这是 OTA 比插线刷安全的根本原因。
// ★已知代价(可接受): Update.write() 要同步等 flash 擦写完成, 而本回调跑在 async_tcp
//   任务里, 所以这十几秒内 Web 服务是"一顿一顿"的(上传进度会跳、其它请求变慢) —— 功能正常。
//   另一个后果是必须【先停播】: 否则 I2S 喂流与 flash 擦写互相抢, 而且升级中还出声很怪。
// ★线程约定: 本段只碰 flash 与几个 volatile 标志, 【不写 gState 的任何 String】。
//   停播走 pPlayer->stop()(命令投递), 真正停播由主循环执行 —— 与全工程约定一致。
// ============================================================================
enum : int8_t { OTA_E_NONE = 0, OTA_E_LEN = 2, OTA_E_BEGIN = 3, OTA_E_WRITE = 4, OTA_E_END = 5, OTA_E_FULL = 6 };
static volatile uint32_t sOtaDone  = 0;      // 已写入字节(进度)
static volatile uint32_t sOtaTotal = 0;      // 本次固件总字节(取自 Content-Length)
static volatile int8_t   sOtaErr   = OTA_E_NONE;
static volatile bool     sOtaOk    = false;  // 写完且校验通过 -> 交主循环延迟重启
static uint32_t          sOtaRebootMs = 0;   // 重启倒计时起点(0 = 未开始计时)
static const uint32_t    OTA_REBOOT_DELAY_MS = 1500;   // 留点时间把"成功"响应发回浏览器
// 单次可升级镜像上限 = ota 分区大小(partitions.csv 里 ota_0/ota_1 各 0x300000)。
// 只用来提前拦掉明显离谱的包(例如误把 16MB 的 merged.bin 当升级包传上来);
// 真实可用空间由 Update.begin() 自己判断。
static const size_t      OTA_MAX_IMAGE = 0x300000;

// ★防呆: 识别"整片包"(webradio-s3p-<版本>-full.bin, 含 bootloader + 分区表 + boot_app0 + app)。
//   为什么要拦: 网页升级走 Update, 只能写【应用】镜像。整片包长度约 2.1MB, 通不过"太长"那道
//   上限检查, 会被当成合法大小写进 app 分区 —— 而它开头是 bootloader, 启动必然失败。
//   判据: 整片包在文件偏移 0x8000 处是分区表, 首条固定是 `nvs, data, nvs` ->
//     0x8000: AA 50 | 01(data) 02(nvs) | offset | size | 'n','v','s'
//   正常应用镜像的同一位置是中段代码, 撞上这串(魔数+类型+标签)的概率可忽略。
//   只捕获这 16 字节, 不额外占内存, 也不影响分块上传(边收边丢)。
static uint8_t  sOtaPt[16];                  // 0x8000 起的 16 字节
static uint8_t  sOtaPtGot  = 0;              // 已捕获字节数
static bool     sOtaPtDone = false;           // 判过了就不再判

static const char* otaErrText(int8_t e) {
  switch (e) {
    case OTA_E_LEN:   return "固件长度非法(空包, 或超过分区大小 —— 别误传 16MB 的整个镜像包)";
    case OTA_E_FULL:  return "这是【整片包】(含 bootloader/分区表), 网页升级只收应用固件 webradio-s3p.ino.bin";
    case OTA_E_BEGIN: return "无法开始写入(分区表里没有 ota 分区? 或没有可用空间)";
    case OTA_E_WRITE: return "写入 flash 失败(数据可能被截断)";
    case OTA_E_END:   return "镜像校验失败(文件不完整, 或不是本机固件)";
    default:          return "无";
  }
}
#endif  // OTA_ENABLED

// ---- Captive Portal 兼容: 把"经检测域名访问"的请求重定向到网关 IP ----
// 手机连上 AP 后, iOS/安卓用真实检测域名(captive.apple.com / connectivitycheck.gstatic.com…)
// 访问本机, DNS 虽劫持到 192.168.4.1, 但浏览器 location.host 仍是检测域名。
// iOS 的 Captive Network Assistant(CNA) 会拦截页面里向"检测域名"发起的 fetch/WS(防钓鱼安全模型),
// 导致"页面能显示、但配网保存(fetch /api/wifi)无效"。
// 解法: 检测到 host 不是网关 IP 时, 返回极小非 gzip 页面, 用 JS/meta 把浏览器重定向到
// http://192.168.4.1/ —— 之后 location.host 变成网关, 所有请求同源放行。
// 电脑直连 192.168.4.1 时 host 已是网关, 不跳, 行为不变。
static const char* kApGwIp = "192.168.4.1";
static bool apNeedRedirect(AsyncWebServerRequest* r) {
  if (!gState.apMode) return false;   // 仅 AP(配网)模式下做检测域名重定向; 已连家网时绝不劫持, 否则家网后台打不开
  String h = r->host();
  int p = h.indexOf(':'); if (p >= 0) h = h.substring(0, p);   // 去掉可能存在的端口
  return h.length() > 0 && h != kApGwIp;
}
static void apSendRedirect(AsyncWebServerRequest* r) {
  // 必须用非 gzip 极小页(且不要外链资源), 确保 CNA/安卓 captive 浏览器能解析并跳转
  static const char* kRedirHtml =
    "<!doctype html><html><head><meta http-equiv=\"refresh\" content=\"0;url=http://192.168.4.1/\"></head>"
    "<body><script>location.replace('http://192.168.4.1/');</script>"
    "正在打开配置页…</body></html>";
  r->send(200, "text/html; charset=utf-8", kRedirHtml);
}


// ===================== WebSocket 指令解析(yoradio 风格 cmd=val, 仅超短指令) =====================
// 指令: play=<id> next=1 prev=1 toggle=1 volume=<v> wifi=<ssid>||<pwd> reset=1
//       disp=<contrast>||<rot>[||<blTimeoutMs>]   (rot=0/90/180/270)
// 电台增删改走 HTTP POST(/api/station/add|edit|del); 批量导入走 POST /api/station/import
// (2026-09-18 恢复: 前端把 CSV 读成文本后以 urlencoded list= 提交, 不走 multipart)。

static void wsAck(const String& cmd, bool ok, int count, const String& msg);
void handleWsCommand(const String& cmd, const String& val) {
  if (cmd == "play") {
    int i = val.toInt();
    // 只投递命令, 不在此写 gState(此回调在异步任务上下文, 直接写 String 字段
    // 会与主循环 show() 竞争导致堆损坏); index/台名/播放由主循环 processCmd 统一执行
    if (i >= 0 && i < pStore->count()) pPlayer->requestPlayIdx(i);
  }
  else if (cmd == "next")        pPlayer->next();
  else if (cmd == "prev")        pPlayer->prev();
  else if (cmd == "toggle")      pPlayer->togglePlay();
  else if (cmd == "volume")      pPlayer->setVolume(val.toInt());
  else if (cmd == "wifi") {
    int sep = val.indexOf("||");
    String ssid = (sep >= 0) ? val.substring(0, sep) : val;
    String pwd  = (sep >= 0) ? val.substring(sep + 2) : "";
    Serial.println("[WS] WiFi保存 ssid=[" + ssid + "]");
    pPortal->saveAndRestart(ssid, pwd);     // 置标志, loop() 里重启
  }
  // ---- 多网络凭据(2026-10-06): 后台"网络"页用 ----
  // 分工与其它设置一致: 这里只写 NVS【不重启】, 用户把几个槽都改完, 再发 wifiapply=1 统一重启。
  // (重启一次要等 WiFi 重新连 + 音频重新起播, 所以不想每改一个槽就重启一次。)
  else if (cmd == "wifiset") {          // wifiset=<槽位>||<ssid>||<密码>   (密码留空 = 不改)
    const int a = val.indexOf("||");
    if (a < 0) { wsAck(cmd, false, pStore->count(), "参数应为 槽位||ssid||密码"); return; }
    const int    b    = val.indexOf("||", a + 2);
    const int    slot = val.substring(0, a).toInt();
    const String ssid = (b >= 0) ? val.substring(a + 2, b) : val.substring(a + 2);
    const String pwd  = (b >= 0) ? val.substring(b + 2)    : "";
    if (slot < 0 || slot >= WIFI_SLOT_COUNT) { wsAck(cmd, false, pStore->count(), "槽位越界"); return; }
    Serial.printf("[WS] WiFi 槽%d <- [%s] pwd_len=%u\n", slot, ssid.c_str(), (unsigned)pwd.length());
    pPortal->setSlot(slot, ssid, pwd);
    wsAck(cmd, true, pStore->count(), String("已写入槽 ") + (slot + 1));
  }
  else if (cmd == "wifidel") {          // wifidel=<槽位>
    const int slot = val.toInt();
    if (slot < 0 || slot >= WIFI_SLOT_COUNT) { wsAck(cmd, false, pStore->count(), "槽位越界"); return; }
    Serial.printf("[WS] WiFi 清空槽%d\n", slot);
    pPortal->delSlot(slot);
    wsAck(cmd, true, pStore->count(), String("已清空槽 ") + (slot + 1));
  }
  else if (cmd == "wifiapply") {        // 落盘 + 重启, 让新凭据生效
    Serial.println("[WS] WiFi 配置已保存, 准备重启");
    pPortal->saveAllAndRestart();
    wsAck(cmd, true, pStore->count(), "已保存, 设备重启中");
  }
  else if (cmd == "reset") {
    Serial.println("[WS] 重置配网");
    pPortal->resetConfig();                 // 置标志, loop() 里重启
  }
  else if (cmd == "sleep") {                 // sleep=<分钟>; 0 = 取消
    int m = val.toInt();
    pPlayer->setSleepTimer(m);
    wsAck(cmd, true, pStore->count(), m > 0 ? (String("睡眠定时器 ") + m + " 分钟") : "已取消");
  }
  // ---- 本地 SD 卡(阶段②) ----
  // sd=scan              请求重新挂载并扫描卡(实际动作在主循环执行)
  // sd=play=<序号>       播放该文件(只是投递命令, 主循环 processCmd 才真正 connecttoFS)
  // sd=exit              退出 SD 音源, 回到进 SD 前的那台网络电台
  else if (cmd == "sd") {
    if (val == "scan") {
      sdReqScan();
      wsAck(cmd, true, pStore->count(), "正在扫描 SD 卡…");
    }
    else if (val == "exit") {
      sdReqExit();
      wsAck(cmd, true, pStore->count(), "已退出 SD 音源, 回到网络电台");
    }
    else if (val.startsWith("play=")) {
      const int idx = val.substring(5).toInt();
      // ★这里【不】校验 idx < gSd.count(): 本 TU 在 async_tcp 任务, 而 count() 读的是
      //   主循环 scan() 正在重建的 vector(可能正在重分配) -> 读它就是数据竞争。
      //   越界由主循环的 execSdPlay() 自己钳制(见 audio_player.cpp), 那里才是正确的位置。
      if (idx >= 0) {
        pPlayer->playSdFile(idx);          // 投递命令(线程安全)
        wsAck(cmd, true, pStore->count(), String("播放 #") + (idx + 1));
      } else {
        wsAck(cmd, false, pStore->count(), "序号不能为负");
      }
    }
    else wsAck(cmd, false, pStore->count(), "参数应为 scan / play=<序号> / exit / toggle");
  }
  else if (cmd == "sbr") {          // sbr=1 开启 / sbr=0 关闭(默认关, 推荐)
    const int on = val.toInt() ? 1 : 0;
    pPlayer->setSbrEnabled(on != 0);
    wsAck(cmd, true, pStore->count(), on ? "SBR 已开(输出 96kHz)" : "SBR 已关(输出 48kHz, 推荐)");
  }
  // ---- 音源切换: 网络电台 <-> 本地 SD 卡(与遥控 IR_SD 键、后台"音源切换"同一后端) ----
  // 方向自动判断(与 .ino 的 sdToggleSource 同一语义): 在 SD 就回电台, 否则进 SD。
  else if (cmd == "source") {
    if (gState.sdActive) {
      sdReqExit();
      wsAck(cmd, true, pStore->count(), "已切回网络电台");
    } else {
      // 进 SD 要挂载+扫描, 必须主循环做 -> 置标志(本 TU 不碰 SD 卡驱动)
      sdReqEnter();
      wsAck(cmd, true, pStore->count(), "正在挂载 SD 卡, 将续播上次那首…");
    }
  }
  else if (cmd == "disp") {
    // 显示设置: 按 "||" 分段, 段数决定语义(向后兼容旧前端)
    //   6 段: type||contrast||rot||blTimeout||bright||inv← 当前前端(2026-10-07 起)
    //   5 段: type||contrast||rot||blTimeout||bright← 旧前端(无反显)
    //   4 段: type||contrast||rot||blTimeout           ← 更旧(无亮度)
    //   3 段: contrast||rot||blTimeout
    //   2 段: contrast||rot
    //   rot = 旋转角度(0/90/180/270), 后端非法值回落 0°。
    //   ★bright = 背光亮度 0~100% —— ST7789/ST7567 的"亮度"唯一入口(PWM 占空比);
    //     注意"亮度"与 ST7567/SSD1306 的"对比度寄存器"是两回事, 两个参数可以叠加。
    //   ★inv = 彩屏反显(1=0x21 / 0=0x20), 对 ST7789 / ILI9341 都生效, 缺段=-1 表示不改。
    // ★注意: 屏幕类型是【可以运行时切换】的 —— 下面 t>0 且与当前不同就调 setScreenType(),
    //   由主循环 tick() 重建 u8g2 对象(不能在 WS 异步上下文里重建)。
    //   8 段: 上面 7 段 + 卡通背景色下标 ← 2026-10-16 新增(由 FULL/FM 主线移植)
    //   7 段: 上面 6 段 + 元素配色表("0,1,2,…" 逗号分隔的色板下标) ← 2026-10-10 新增
    String sv[8]; int n = 0;
    for (int i = 0, s = 0; i <= (int)val.length() && n < 8; i++) {
      const bool atEnd = (i == (int)val.length());
      const bool isSep = (!atEnd && val[i] == '|' && i + 1 < (int)val.length() && val[i + 1] == '|');
      if (!atEnd && !isSep) continue;
      sv[n++] = val.substring(s, i);            // ★先留字符串: 第 7 段是逗号分隔的配色表, 不能 toInt
      s = i + 2;
      if (isSep) i++;                           // 跳过 "||" 的第二个 '|'
    }
    int seg[8];
    for (int i = 0; i < 8; i++) seg[i] = (i < n) ? sv[i].toInt() : 0;   // 空段 -> 0, 由下面的 -1 兜底语义处理
    // ★★v1.14 修(关键 bug): 本数组原为 int seg[7], 但下面第 8 段读 seg[o+6](=seg[7]) —— 越界读栈垃圾,
    //   导致"后台改背景色怎么点都没反应/随机色"。扩到 seg[8] + 循环 8 次即可。
    if (n < 2) { wsAck(cmd, false, pStore->count(), "参数格式错误"); return; }
    const bool hasType = (n >= 4);              // 只有 4+ 段才带屏幕类型(前 2~3 段是老格式)
    const int  o  = hasType ? 1 : 0;            // 屏幕类型之后的偏移量
    const int  t  = hasType ? seg[0] : -1;
    const int  c  = seg[o];
    const int  r  = (n > o + 1) ? seg[o + 1] : -1;
    const int  b  = (n > o + 2) ? seg[o + 2] : -1;
    const int  br = (n > o + 3) ? seg[o + 3] : -1;
    // ★第6 段 inv = ST7789 反显(2026-10-07 新增): 1=0x21(INVON) / 0=0x20(INVOFF)。
    //   不同厂家/批次的模组要的极性不一样 —— 整片发白像底片、或颜色整体反相, 就是这项反了。
    //   ★缺段用 -1 表示"不改动": 旧前端只发 5 段时不会把用户设的反显清掉。
    //     (不能用 seg==0 判"要关", 因为 0 与"缺段"经 toInt() 后无法区分。)
    const int  iv = (n > o + 4) ? seg[o + 4] : -1;
    if (pDisp) {
      if (t > 0 && t != pDisp->screenType()) pDisp->setScreenType(t);  // 屏型变更才重建(避免无谓重建)
      pDisp->setContrastVal(c);
      if (r  >= 0) pDisp->setRotation(r);      // 缺段则不动(旧前端 2 段时不至于被置 0°)
      if (b  >= 0) pDisp->setBLTimeout(b);
      if (br >= 0) pDisp->setBrightVal(br);
      // 反显只对彩屏(ST7789/ILI9341)有意义; 它不重建 u8g2(只发一条 SPI 命令), 所以这里安全。
      if (iv >= 0 && IS_TFT_SCREEN(pDisp->screenType()))
        st7789SetInvert(iv != 0);
      // ★第 7 段: 元素配色(2026-10-10 由 tyio 分支移植)—— 逗号分隔的色板下标表, 一个元素一项。
      //   ★与反显/亮度同属"一次保存全部生效": 用户可以在页面上连着改屏型 + 勾反色 + 调亮度 +
      //     挑好几个元素的颜色, 最后只点一次"应用" —— 这里一次性收下。
      //   数量可以少于 ELEM_COUNT(只改前 m 个); 越界值由 setElemColors() 钳回 0(白)。
      if (n > o + 5) {
        int ec[ELEM_COUNT]; int m = 0;
        const String& cs = sv[o + 5];
        for (int i = 0, s2 = 0; i <= (int)cs.length() && m < ELEM_COUNT; i++) {
          if (i != (int)cs.length() && cs[i] != ',') continue;
          ec[m++] = cs.substring(s2, i).toInt();
          s2 = i + 1;
        }
        if (m > 0) pDisp->setElemColors(ec, m);
      }
      // ★第 8 段(2026-10-16 卡通配色): 背景色下标(kBgPalette[], 0~7; 越界由 setBgColor 钳回 0)。
      //   缺段(n 不够)时不改 —— 旧前端只发 7 段, 不会把用户设的背景色清掉。
      if (n > o + 6) {
        const int bg = seg[o + 6];
        if (bg >= 0) pDisp->setBgColor(bg);
      }
      // ★v1.13 修: 显示设置里"只改颜色/底色"不会改变界面内容 -> 内容指纹不变 -> 整帧被跳过,
      //   屏上毫无变化(用户点"应用"看着像没反应)。这里显式作废当前帧, 强制下一帧整屏重画。
      pDisp->invalidate();
    }
    wsAck(cmd, true, pStore->count(), "显示设置已应用");
  }
  else if (cmd == "irlearn") {
    IRAction a = ir_name_to_action(val);
    if (a < IR_COUNT) {
      // ★ir_begin_learn 内部已先清除该动作的原有码(重学语义), 详见 ir_learn.cpp。
      ir_begin_learn(a);
      Serial.println("[WS] 红外重学 " + String(ir_action_name(a)));
      wsAck(cmd, true, pStore->count(), "原有码已清除, 请按新键(不按则保持清除)");
    } else {
      wsAck(cmd, false, pStore->count(), "未知动作");
    }
  }
  else if (cmd == "irclr") {
    if (val == "all")      { ir_clear_all(); Serial.println("[WS] 红外清除全部"); }
    else {
      IRAction a = ir_name_to_action(val);
      if (a < IR_COUNT) { ir_clear(a); Serial.println("[WS] 红外清除 " + String(ir_action_name(a))); }
    }
    wsAck(cmd, true, pStore->count(), "已清除");
  }
  // ---- 网页后台"控制按钮"(2026-10-16 新增): 复用遥控动作派发, 网页按钮 = 遥控器等价 ----
  // val = 动作名("prev"/"next"/"toggle"/"volup"/"voldown"/"power"/"rotate"/"screen"/"sd"/"timer")。
  // 非法名由 ir_web_trigger() 内部忽略; 执行被投递到主循环(与遥控命中同一执行线)。
  else if (cmd == "act") {
    ir_web_trigger(val);
    wsAck(cmd, true, pStore->count(), "已发送控制指令");
  }
  else {
    Serial.println("[WS] 未知指令: " + cmd);
    wsAck(cmd, false, pStore->count(), "未知指令");
  }
}

// 向所有 WS 客户端回送确认(前端据此弹"已保存"提示)
void wsAck(const String& cmd, bool ok, int count, const String& msg) {
  String s = "{\"type\":\"ack\",\"cmd\":\"" + cmd + "\",\"ok\":" + (ok ? "true" : "false") +
             ",\"count\":" + String(count) + ",\"msg\":\"" + msg + "\"}";
  gWs.textAll(s);
}

void onWsEvent(AsyncWebSocket* s, AsyncWebSocketClient* c, AwsEventType type,
               void* arg, uint8_t* data, size_t len) {
  if (type == WS_EVT_DATA) {
    AwsFrameInfo* info = (AwsFrameInfo*)arg;
    // 仅处理完整文本帧; 用显式长度构造 String, 不写越界终止符
    if (info->final && info->index == 0 && info->len == len && info->opcode == WS_TEXT) {
      String msg((const char*)data, len);
      int eq = msg.indexOf('=');
      String cmd = (eq >= 0) ? msg.substring(0, eq) : msg;
      String val = (eq >= 0) ? msg.substring(eq + 1) : "";
      handleWsCommand(cmd, val);
    }
  }
}

// ===================== 状态 JSON =====================
// 只能在【主循环线程】调用(会读 gState 的 String 字段)。
// 输出写进调用方给的 String(保留其已分配容量, 减少堆碎片)。
// 注意: 电台列表【不】在此序列化(见 buildStationsJson / /api/stations)——大列表
// 每 1.2s 反复序列化会在无 PSRAM 板上吃 heap 导致播放卡顿。
// ---- 定时开机(闹钟)的两个小工具 ----
// JSON 字符串转义: 电台名/地址来自表单或 CSV 导入, 可能含 " 或 \ —— 直接拼进 JSON 会把它拼坏。
static String jsonEsc(const String& s) {
  String o;
  o.reserve(s.length() + 8);
  for (size_t i = 0; i < s.length(); i++) {
    const char ch = s[i];
    if (ch == '"' || ch == '\\') { o += '\\'; o += ch; }
    else if ((uint8_t)ch < 0x20) o += ' ';     // 控制字符不该出现在 JSON 串里
    else o += ch;
  }
  return o;
}

// 解析 "HH:MM"(浏览器 <input type="time"> 的原生格式)。越界即判失败, 由调用方保持原值。
static bool parseHHMM(const String& s, int& h, int& m) {
  const int c = s.indexOf(':');
  if (c <= 0) return false;
  h = s.substring(0, c).toInt();
  m = s.substring(c + 1).toInt();
  return (h >= 0 && h <= 23 && m >= 0 && m <= 59);
}

static void buildStateInto(String& out) {
  JsonDocument& doc = gSnapDoc;
  doc.clear();                                 // 复用同一份文档对象(容量保留)
  doc["build"]       = gBuild;                 // 供页面自检版本一致性(与版本号无关, 是编译时刻)
  doc["ver"]         = FW_VERSION;            // 对外显示的固件版本号(如 v1.0)
  doc["wifi"]        = gState.wifiConnected;
  doc["ip"]          = gState.ip;
  // ---- 多网络凭据(2026-10-06): 供后台"网络"页显示与编辑 ----
  // ★只回 SSID 和"是否已配置", 【绝不回传密码】—— 页面提交新密码时留空即表示"不改这个槽的密码"。
  {
    JsonObject wn = doc["wnet"].to<JsonObject>();
    JsonArray  sl = wn["slots"].to<JsonArray>();
    for (int i = 0; i < WIFI_SLOT_COUNT; i++) {
      JsonObject s = sl.add<JsonObject>();
      s["ssid"] = pPortal->slotSsid(i);
      s["set"]  = pPortal->slotSet(i);
    }
    wn["cur"]  = pPortal->curSlot();    // 当前生效的槽; -1 = 未连 / AP 配网中
#if SYS_MONITOR_ENABLE
    // V1.20: 与 TFT、/api/status 同一个"平滑 + 滞回"后的统一数据源(原来这里直接读 WiFi.RSSI(), 与屏上数值会长期对不上)
    wn["rssi"] = (WiFi.status() == WL_CONNECTED && sysSnapshot().wifiOk) ? sysSnapshot().rssiShown : 0;
#else
    wn["rssi"] = (WiFi.status() == WL_CONNECTED) ? WiFi.RSSI() : 0;
#endif
    wn["ap"]   = pPortal->isAP();
    wn["n"]    = WIFI_SLOT_COUNT;
  }
  doc["playing"]     = gState.playing;
  doc["deepSleep"]   = true;   // 本机支持深度休眠关机(仅 电源键/遥控/串口 触发); 仅作能力旗标供 API/调试查
  // ---- 睡眠定时器(2026-10-06 阶段①) ----
  doc["sleepMin"]    = gState.sleepMin;          // 用户设定值(分钟); 0=未设定
  doc["sleepRemain"] = gState.sleepRemainSec;    // 实时剩余秒数; 0=未运行
  // ---- 定时开机(闹钟, 2026-10-08) ----
  // 配置由主循环维护(NVS), 这里只是加锁拷一份出来序列化, 与 gState 的 String 无关。
  // ★前提已写在 alarm.h: 只有设备【通电】时才会响(熄屏待机可以, 深度休眠不行)。
  {
    const AlarmCfg ac = alarmGet();
    JsonObject a = doc["alarm"].to<JsonObject>();
    a["en"]    = ac.en;
    a["onH"]   = ac.onH;
    a["onM"]   = ac.onM;
    a["offEn"] = ac.offEn;
    a["offH"]  = ac.offH;
    a["offM"]  = ac.offM;
    a["url"]   = ac.url;
    a["name"]  = ac.name;
  }
  // ---- 本地 SD 卡(阶段②) ----
  // 只回显"是否在播 SD + 正在播哪个", 文件清单不进周期快照(与电台列表同理:
  // 大列表每 1.2s 反复序列化会吃 heap。清单由 /api/sd/list 按需返回)。
  doc["sdActive"] = gState.sdActive;
  doc["sdName"]   = gState.sdName;
  doc["sdIndex"]  = gState.sdIndex;
  doc["sdMounted"] = gSd.mounted();   // 纯内存标志(由主循环维护), 非阻塞
  // ★记忆的播放位置(关机/重启后也知道上次播到哪首; -1=无记忆)。纯内存读, 不碰 SD 卡。
  doc["sdLast"]   = gSd.lastIndex();
  // ---- SBR(2026-10-07): 供后台"音效设置"回显当前开关 ----
  // SBR 把 HE-AAC 输出采样率翻倍(48k->96k); 96kHz 下 I2S DMA 只有 170ms 余量,
  // 而部分电台是 ~200ms 突发推包 -> 必然排空 -> 发颤。默认关。
  doc["sbr"] = pPlayer->sbrEnabled() ? 1 : 0;
  doc["volume"]      = gState.volume;
  doc["index"]       = gState.index;
  doc["stationName"] = gState.stationName;
  doc["title"]       = gState.title;
  doc["bitrate"]     = gState.bitrate;
  doc["codec"]       = gState.codec;      // 编码名(AAC/MP3/…), 与屏幕第3行同源
  doc["status"]      = gState.status;
  doc["battery"]     = gState.batteryV;   // 电池电压(V); 分压中点接 GPIO17(ADC2_CH6), 主循环节流采样
  doc["charging"]    = gState.charging;   // 是否充电中: CHRG 脚(GPIO18)低电平=充电中
  // ---- 时间 / 天气(320x240 大屏; 开机一次 + 每小时一次, 断网时为上次的值或空) ----
  {
    struct tm tmn; timeLocal(&tmn);
    char ts[8] = {0};
    snprintf(ts, sizeof(ts), "%02d:%02d", tmn.tm_hour, tmn.tm_min);
    doc["time"]        = ts;
    doc["timeSynced"]  = gState.timeValid;     // false=还没用网络校准过(用的是编译期兜底时间)
    doc["date"]        = String(tmn.tm_year + 1900) + "-" + String(tmn.tm_mon + 1) + "-" + String(tmn.tm_mday);   // tm_mon 0~11, +1
    doc["weekday"]     = WEEKDAY_CN[tmn.tm_wday];
    const LunarInfo lun = lunarFromSolar(tmn.tm_year + 1900, tmn.tm_mon + 1, tmn.tm_mday);
    doc["lunar"]       = lun.ok ? (String(lun.ganZhiYear) + lun.zodiac + "年" + lun.monthDay) : String("");
    JsonObject w = doc.createNestedObject("weather");
    w["ok"]       = gState.wx.valid;
    w["city"]     = gState.wx.city;
    w["text"]     = gState.wx.text;
    w["tempC"]    = gState.wx.tempC;
    w["feelsC"]   = gState.wx.feelsC;
    w["humidity"] = gState.wx.humidity;
    w["windDir"]  = gState.wx.windDir;
    w["windScale"]= gState.wx.windScale;
    w["tminC"]    = gState.wx.tminC;
    w["tmaxC"]    = gState.wx.tmaxC;
    w["ageMin"]   = gState.wx.valid ? (uint32_t)((millis() - gState.wx.updMs) / 60000UL) : 0;
    // 生效中的接口地址(串口 X/Y 可在运行时改; 这里回显便于确认到底在用哪个源)
    w["urlGeo"]   = WX_PROV_KEYLESS ? weatherGeoUrl() : "";
    w["urlFc"]    = WX_PROV_KEYLESS ? weatherFcUrl()  : String("qweather:") + (strlen(WEATHER_HOST) ? WEATHER_HOST : WEATHER_API_BASE);
    w["provider"] = WX_PROV_KEYLESS ? "keyless(ipwho+open-meteo)" : "qweather";
  }
  // 功放/数据流诊断(排查"显示播放中却没声音"):
  //   amp=false 且 dataAgeMs 大 -> 没有音频数据在流(网络/解码问题), 功放被正确关掉了;
  //   amp=true  却仍无声           -> 数据在流、功放已开, 问题在 I2S 输出/喇叭/接线。
  doc["amp"]         = gAmpOn;
  // 网络侧 DAC 供电状态(2026-09-22 加): 排查"关机后还在耗电"。
  //   仅网络收音机: 播放/待机时 netDac=true; 深度休眠前被拉低(此时无 Web 可查, 用串口日志确认)。
  doc["netDac"]      = gNetDacOn;
  doc["dataAgeMs"]   = gState.playing ? (uint32_t)(millis() - gState.lastDataMs) : 0;
  // 显示设置当前值(供页面回填"显示设置"卡)
  doc["screen"]      = pDisp ? pDisp->screenType()  : SCREEN_DEFAULT;
  doc["contrast"]    = pDisp ? pDisp->contrastVal() : LCD_CONTRAST;
  doc["rot"]         = pDisp ? pDisp->rotation()     : 0;   // 0/90/180/270°
  doc["blTimeout"]   = pDisp ? pDisp->blTimeoutVal() : LCD_BL_TIMEOUT_MS;
  doc["bright"]      = pDisp ? pDisp->brightVal()    : LCD_BL_BRIGHT_DEFAULT;  // 背光亮度 0~100%
  // ---- 屏幕背景图(2026-10-06): 供"屏幕背景"页判断按哪个尺寸生成、以及回显当前状态 ----
  // ★bgHas() / st7789PortraitGet() 都是【纯内存读】(主循环已维护好缓存/全局标志),
  //   不在这里碰文件系统 —— 本函数所属的快照重建也在主循环, 但保持"异步侧零 FS 操作"的习惯。
  doc["orient"] = st7789PortraitGet() ? "P" : "L";   // ST7789 当前方向: L=横屏 320x240 / P=竖屏 240x320
  doc["bgLand"] = bgHas(false);                      // 横屏是否已存有彩色背景图
  doc["bgPort"] = bgHas(true);                       // 竖屏是否已存有彩色背景图
  doc["bgAlpha"] = bgUiAlphaGet();// 界面不透明度 0~100(100=纯色不混合)
  doc["bgBright"] = bgBrightGet(); // 背景图亮度 0~100(100=原图; 只压暗底图, 不动屏幕背光)
  doc["bgBytes"] = BG_RGB_BYTES;                     // 单张背景图的字节数(供页面校验上传尺寸)
  // ---- ST7789 / ILI9341 反显(2026-10-07 新增, 供后台"反色"开关回填) ----
  // 不同批次模组的反显极性不一样, 页面据此显示当前状态; 对非彩屏屏也照样返回(前端会置灰)。
  doc["inv"] = st7789InvGet() ? 1 : 0;
  // ---- 元素配色(2026-10-10): 每个显示元素当前选中的色板下标, 供"显示设置"卡的多个下拉回填 ----
  { JsonArray ea = doc.createNestedArray("ecol");
    for (int i = 0; i < ELEM_COUNT; i++) ea.add(pDisp ? pDisp->elemColor(i) : 0); }
  // ---- 卡通背景色(2026-10-16): 当前选中的 kBgPalette 下标, 供"显示设置"卡的下拉回填 ----
  doc["bg"] = pDisp ? pDisp->bgColorIdx() : 0;
  // ---- 内存诊断(2026-10-06 加): 背景图那 150KB 能不能分配出来, 全看这几项 ----
  // ★血的教训: ps_malloc() 内部是 heap_caps_malloc_prefer(SPIRAM, 8BIT) —— 它【本来就会
  //   降级到内部 RAM】。所以 ps_malloc(150KB) 返回 NULL 就意味着"PSRAM 拿不到【且】DRAM
  //   也拿不到", 而不是"只是 PSRAM 不够"。这时要看 psramSize 是不是 0:
  //   若 psramSize==0 而板子明明是 N16R8(8MB OPI), 说明编译时的 PSRAM 模式配错了
  //   (sdkconfig 里 CONFIG_SPIRAM_MODE_QUAD 而硬件是 Octal) —— 那样连音频的 512KB
  //   输入缓冲也一直在退回 DRAM 小缓冲, 是个影响面更大的问题。
  doc["psramSize"]  = (uint32_t)(ESP.getPsramSize()  / 1024);
  doc["psramFree"]  = (uint32_t)(ESP.getFreePsram()  / 1024);
  doc["psramMax"]   = (uint32_t)(heap_caps_get_largest_free_block(MALLOC_CAP_SPIRAM) / 1024);
  doc["heapFree"]   = (uint32_t)(ESP.getFreeHeap()   / 1024);
  doc["heapMax"]    = (uint32_t)(heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL) / 1024);
  // 红外学习状态: 供页面显示已学动作 + 学习指示(学习/比对在 ir_poll 主循环里跑)
  JsonObject ir = doc.createNestedObject("ir");
  ir["ready"]           = ir_is_ready();    // RMT 接收是否初始化成功(硬件接线/外设可用性的实时判据)
  ir["learning"]        = ir_is_learning();
  ir["learningAction"]  = ir_is_learning() ? ir_action_name(ir_learning_action()) : "";
  // 最近一次【真正命中并触发】的动作: 诊断"按了某个键却没反应" —— 看它被认成了什么。
  // 最常见根因是两个动作学成了同一个遥控键(匹配按枚举序号顺序, 序号小的先赢)。
  ir["last"]            = ir_last_action_name();
  JsonObject ircodes = ir.createNestedObject("codes");
  for (int a = 0; a < IR_COUNT; a++)
    ircodes[ir_action_name((IRAction)a)] = ir_has_code((IRAction)a);
  // 注意: 电台列表【不】放进周期快照! 大列表每 1.2s 序列化会持续产生大块 heap 分配,
  // 无 PSRAM 板上碎片累积 -> 音频解码 malloc 失败 -> 播放卡顿。列表改由 /api/stations 按需返回。
  out = "";                    // 长度归零但保留容量(Arduino String 的 reserve 只增不减)
  serializeJson(doc, out);
}

// ===================== 播放链诊断(纯文本) =====================
// 判读: 运行=0->未建连(地址/网络); 运行=1 编码=MP3 缓冲涨->解码链正常(查 I2S/功放); 缓冲恒0且运行=0->流不可达。
static void buildDiagInto(String& out) {
  const uint32_t filled = pPlayer ? pPlayer->inBufferFilled() : 0;
  // ★分母必须用 bufferCapacity()(真实容量), 不能写 AUDIO_RAM_BUFSIZE:
  //   缓冲已按 PSRAM 分支调到 512KB, 除以 16KB 会算出 3000%+ 的荒谬值,
  //   与 audio_player.cpp 的欠载检测是同一个坑(那里已修, 这里漏了)。
  const uint32_t cap    = pPlayer ? pPlayer->bufferCapacity() : AUDIO_RAM_BUFSIZE;
  const uint32_t pct    = cap ? (filled * 100 / cap) : 0;
  out = "";
  out += "固件      : " + String(FW_VERSION) + "   (构建 " + gBuild + ")\n";
  out += "WiFi      : " + String(gState.wifiConnected ? "已连 " : "未连 ") + gState.ip + "\n";
  out += "播放      : " + String(gState.playing ? "是" : "否") + "   状态=" + gState.status + "\n";
  out += "电台      : [" + gState.stationName + "]\n";
  out += "节目信息  : [" + gState.title + "]" +
         "  编码判定=" + (gState.titleEnc.length() ? gState.titleEnc : String("?")) + "\n";
  out += "实际地址  : " + gState.url + "\n";
  out += "缓冲      : " + String(filled) + " / " + String(cap) +
         " (" + String(pct) + "%)" +
         (gState.buffering ? "  ★等待库出声" : "") + "\n";
  // 运行时实际生效值(串口 B 可改写): 如实反映闸门开/关与真实水位。
  {
    uint32_t pb = (pPlayer ? pPlayer->prebufBytes() : 0);
    out += String("起播预缓冲: ") +
           (pb > 0
              ? ("开, " + String(pb / 1024) + " KB (库攒够才开始出声)")
              : String("★关(build_opt.h 未设 AUDIO_MIN_BUFFER_BYTES, 库按上游行为: 攒到一帧就出声)")) + "\n";
  }
  out += "运行      : " + String(pPlayer && pPlayer->audioRunning() ? 1 : 0) +
         "  (1=库已建连成功)\n";
  out += "编码      : " + String(pPlayer ? pPlayer->audioCodec() : "?") + "\n";
  out += "码率      : " + String(pPlayer ? pPlayer->audioBitrate() : 0) + " bps\n";
  out += "解码错    : " + String(pPlayer ? pPlayer->audioDecodeErr() : 0) + "\n";
  out += "音量      : " + String(gState.volume) + "/" + String(VOLUME_MAX) + "\n";
  out += "电池电压  : " + String(gState.batteryV, 2) + " V (分压中点 GPIO" + String(BATT_ADC_PIN) + ")\n";
  out += "充电状态  : " + String(gState.charging ? "充电中" : "未充电") +
         " (CHRG GPIO" + String(CHG_STAT_PIN) + ", " + String(CHG_ACTIVE_LOW ? "低有效" : "高有效") + ")\n";
  out += "当前阶段  : " + String(stageText(lastStage())) + "\n";
  out += "可用堆    : " + String(ESP.getFreeHeap() / 1024) + " KB\n";
}

// ---- 主循环侧: 修正 gState + 定期重建状态快照 ----
// 必须在 Arduino 主循环中调用(webradio-s3p.ino 的 loop())。
void WebServerSvc::loop() {
#if OTA_ENABLED
  // 0) 在线升级: 新固件已写入且校验通过 -> 稍等片刻(把"成功"响应发回浏览器)再重启。
  //    ★重启必须放在主循环做: 异步任务里 delay/restart 会把响应憋死在半路。
  //    ★必须放在本函数最开头 —— 下面的状态快照有个节流早退, 放后面会被它挡掉。
  if (sOtaOk) {
    if (sOtaRebootMs == 0) {
      sOtaRebootMs = millis();
      Serial.println("[OTA ] 升级成功, 1.5s 后重启进新固件");
    } else if (millis() - sOtaRebootMs >= OTA_REBOOT_DELAY_MS) {
      Serial.println("[OTA ] 重启中...");
      Serial.flush();
      ESP.restart();
    }
  }
  // 兜底通路: ArduinoOTA(端口 3232)。未连接时每圈开销极小(只查一下 UDP 有无数据)。
  ArduinoOTA.handle();
#endif

  // 0b) 在线电台搜索(radio-browser): 有挂起请求就在这里做 HTTPS 拉取(实测 1~6s)。
  //     ★必须放在下面"快照节流早退"之前, 否则请求会被 return 挡掉永远不执行。
  //     ★为什么在主循环做: 与 weatherTick() 同一套路 —— 音频泵是独立任务, 不受这里阻塞影响;
  //       而放进 async_tcp 回调会把整个 Web/WS 卡住数秒, 页面表现为"点了没反应"。
  rbPoll();

  // 1) 电台列表被 Web 端改动过 -> 在主循环线程修正 gState 的 String 字段
  //    (异步任务里写 gState.stationName 会与主循环显示/轮询竞争 -> 堆损坏)
  if (gStoreChanged) {    gStoreChanged = false;
    if (pStore) {
      if (gState.index >= pStore->count()) gState.index = 0;
      pStore->setLast(gState.index);
      gState.stationName = (pStore->count() > 0) ? pStore->name(gState.index) : String("");
    }
  }

  // 2) 重建状态快照(供 /api/state 零风险读取)
  if (millis() - gSnapMs < SNAPSHOT_MS) return;
  gSnapMs = millis();
  xSemaphoreTake(gSnapMutex, portMAX_DELAY);
  buildStateInto(gSnap);
  buildDiagInto(gDiag);      // 播放链诊断文本(供 /api/diag)
  xSemaphoreGive(gSnapMutex);
#if STATUS_HUB_ENABLE
  // V1.20: 统一系统状态(供 /api/status 与手机页 /status)。仍在主循环里构建, 只读现有播放器访问器,
  //   不新增任何任务; 内部按 STATUS_JSON_MS(2.5s)限频, 其余圈只做一次很轻的"播放状态边沿检测"。
  {
    StatusPlayerInfo pi;
    pi.bufFilled = pPlayer ? pPlayer->inBufferFilled()   : 0;
    pi.bufCap    = pPlayer ? pPlayer->bufferCapacity()   : 0;
    pi.decodeErr = pPlayer ? pPlayer->audioDecodeErr()   : 0;
    pi.running   = pPlayer ? pPlayer->audioRunning()     : false;
    statusRebuildIfDue(pi);
  }
#endif
}

// ===================== 屏幕背景图落盘(2026-10-06, 仅主循环) =====================
// 消费 onBody 收进 PSRAM 的那 150KB: 校验 -> 写 LittleFS -> 强制重画。
// ★为什么与 loop() 分开: loop() 开头有个"快照节流"的早退, 背景图落盘不能被那个节流挡住。
void WebServerSvc::bgTick() {
  // ① 界面不透明度(异步任务只改了内存里的待应用值; 写 NVS 必须在主循环)
  const int8_t al = sBgAlpha;
  if (al >= 0) {
    sBgAlpha = -1;
    bgUiAlphaSet((uint8_t)al, true);
    if (pDisp) pDisp->invalidate();
  }

  // ①b 背景图亮度(同上: 写 NVS 只能在主循环; 若方向匹配会触发重读+重算并重画)
  const int8_t br = sBgBright;
  if (br >= 0) {
    sBgBright = -1;
    bgBrightSet((uint8_t)br, true);
    if (pDisp) pDisp->invalidate();
  }

  // ② 删除请求(异步任务只置了标志, 真正删文件在这里做)
  const int8_t clr = sBgClear;
  if (clr >= 0) {
    sBgClear = -1;
    if (clr == 0)      bgClear(false);
    else if (clr == 1) bgClear(true);
    if (pDisp) pDisp->invalidate();       // 取消背景后必须重画
  }

  // ③ 上传落盘
  if (!sBgUpFull || !sBgUpBuf) return;
  const bool   portrait = sBgUpPort;
  const size_t got      = sBgUpGot;
  const bool   bad      = sBgUpBad;
  sBgUpFull = false;                      // ★先清标记: 即使落盘失败, 也不要在主循环里反复重试刷 flash
  if (bad || got != (size_t)BG_RGB_BYTES) {
    Serial.printf("[BG  ] 丢弃不完整的上传数据(%u/%d)\n", (unsigned)got, (int)BG_RGB_BYTES);
    return;
  }
  const uint32_t t0 = millis();
  sBgUpBusy = true;                       // ★2026-10-11: 读 sBgUpBuf 期间挡住新一批上传(否则写出半新半旧的坏图)
  const bool savedOk = bgSave(sBgUpBuf, portrait);
  sBgUpBusy = false;
  if (savedOk) {
    if (pDisp) pDisp->invalidate();       // ★必须: 否则整帧指纹没变, 下一帧会被跳过, 屏上还是旧画面
    Serial.printf("[BG  ] Web 上传的%s彩色背景已生效(落盘 %ums)\n",
                  portrait ? "竖屏" : "横屏", (unsigned)(millis() - t0));
  }
}

// ===================== 存活诊断访问器(供主循环心跳打印) =====================
// httpReqCount() 增长=请求已到设备; 不增长=请求没到(WiFi/路由), 与 Web 代码无关。
uint32_t WebServerSvc::httpReqCount() { return gHttpReq; }
int      WebServerSvc::wsClients()    { return (int)gWs.count(); }

// ===================== HTTP POST 参数解析 =====================
// 前端以 application/x-www-form-urlencoded 提交, ESPAsyncWebServer 会自动把
// body 解析进 r->arg()(WebRequest.cpp:_parsePlainPostChar, 已做 urlDecode)。
// 注意: 一旦提供了自定义 onBody, 库会走"原始 body"分支而不再自动解析成 arg,
// 导致 r->arg() 取空 —— 所以这里【不挂 onBody】, 直接用 r->arg()。

// 大响应续传问题已由"拆成 3 个 <4KB gzip 资源、浏览器原生分别拉取"根治(见 page_assets.h)。


// ===================== 路由 =====================
void WebServerSvc::begin(StationStore* s, AudioPlayer* p, WiFiPortal* w, DisplayUI* d) {
  pStore = s; pPlayer = p; pPortal = w; pDisp = d;
  rbBegin();                            // 在线电台搜索: 建锁 + 初始快照(2026-10-20)
  gBuild = String(__DATE__) + " " + String(__TIME__);   // 编译时刻, 每次烧录都不同
  Serial.printf("[Web] 固件 %s | 构建时间: %s\n", FW_VERSION, gBuild.c_str());

  // 网页资源全部放在 flash(page_assets.h), 启动时不再构建 RAM 副本 ——
  // 旧实现常驻一个 15.6KB 的 gPage String, 对"无 PSRAM + 解码器要连续堆"的板子是纯负担,
  // 现在这部分堆全部让给 MP3 解码器。
  Serial.printf("[Web] 网页资源(flash, gzip): html %uB / css %uB / js %uB, 可用堆=%u\n",
                (unsigned)PAGE_GZ_LEN, (unsigned)CSS_GZ_LEN, (unsigned)JS_GZ_LEN,
                (unsigned)ESP.getFreeHeap());

  // 状态快照锁 + 首帧快照(避免页面在首次 loop() 之前请求到空响应)
  gSnapMutex = xSemaphoreCreateMutex();
  buildStateInto(gSnap);
  buildDiagInto(gDiag);

  gWs.onEvent(onWsEvent);
  server.addHandler(&gWs);
  // 红外状态变化(进入/退出学习、完成学习)经 WebSocket 即时广播, 页面即时反馈
  ir_set_notify_cb([](const String& j) { gWs.textAll(j); });

  // ---- 极简连通性探针: 浏览器打开 /ping 若能看到 pong, 说明"小响应"链路完好 ----
  server.on("/ping", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    r->send(200, "text/plain; charset=utf-8", "pong");
  });


  // ---- 静态资源: 3 个 gzip 资源, 每个都远小于 TCP_SND_BUF(≈5744B), 单次发完 ----
  // 统一用 const uint8_t* + 显式长度 -> AsyncProgmemResponse(keep-alive, 不主动断连),
  // 并加 Content-Encoding: gzip(ESPAsyncWebServer README 官方推荐做法)。
  server.on("/", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    if (apNeedRedirect(r)) { apSendRedirect(r); return; }   // captive 浏览器经检测域名访问 -> 先跳网关
    Serial.printf("[Web] GET / (html gz %uB) 堆=%uKB 最大块=%uKB\n",
                  (unsigned)PAGE_GZ_LEN,
                  (unsigned)(ESP.getFreeHeap() / 1024), (unsigned)(ESP.getMaxAllocHeap() / 1024));
    AsyncWebServerResponse* res = r->beginResponse_P(200, "text/html; charset=utf-8", PAGE_GZ, PAGE_GZ_LEN);
    res->addHeader("Content-Encoding", "gzip");
    res->addHeader("Cache-Control", "no-store");
    r->send(res);
  });

  server.on("/a.css", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    Serial.printf("[Web] GET /a.css (gz %uB)\n", (unsigned)CSS_GZ_LEN);
    AsyncWebServerResponse* res = r->beginResponse_P(200, "text/css; charset=utf-8", CSS_GZ, CSS_GZ_LEN);
    res->addHeader("Content-Encoding", "gzip");
    res->addHeader("Cache-Control", "no-store");
    r->send(res);
  });

  server.on("/a.js", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    Serial.printf("[Web] GET /a.js (gz %uB)\n", (unsigned)JS_GZ_LEN);
    AsyncWebServerResponse* res = r->beginResponse_P(200, "application/javascript; charset=utf-8", JS_GZ, JS_GZ_LEN);
    res->addHeader("Content-Encoding", "gzip");
    res->addHeader("Cache-Control", "no-store");
    r->send(res);
  });

  // ---- /listop.js: 电台列表"多选 + 批量设分类/删除"(2026-10-07) ----
// 独立资源: 它增强 app.js 已渲染的表格, 不改动 app.js(app.js 只剩百来字节 gzip 余量)。
  server.on("/listop.js", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    Serial.printf("[Web] GET /listop.js (gz %uB)\n", (unsigned)LISTOP_JS_GZ_LEN);
    AsyncWebServerResponse* res = r->beginResponse_P(200, "application/javascript; charset=utf-8", LISTOP_JS_GZ, LISTOP_JS_GZ_LEN);
    res->addHeader("Content-Encoding", "gzip");
    res->addHeader("Cache-Control", "no-store");
    r->send(res);
  });

// ---- /snd.js: "音频设置"标签页(SBR 开关, 2026-10-07) ----
// 同 bg.js/sd.js: 单独一份资源, 不动已逼近水位的 app.js。
  server.on("/snd.js", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    Serial.printf("[Web] GET /snd.js (gz %uB)\n", (unsigned)SND_JS_GZ_LEN);
    AsyncWebServerResponse* res = r->beginResponse_P(200, "application/javascript; charset=utf-8", SND_JS_GZ, SND_JS_GZ_LEN);
    res->addHeader("Content-Encoding", "gzip");
    res->addHeader("Cache-Control", "no-store");
    r->send(res);
  });

// ---- /color.js: "元素配色"下拉组(2026-10-10, 由 tyio 分支移植) ----
// 同 snd.js/ota.js: 单独一份资源 —— app.js 的 gzip 只剩 167B, 这组下拉一行都塞不下。
  server.on("/color.js", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    Serial.printf("[Web] GET /color.js (gz %uB)\n", (unsigned)COLOR_JS_GZ_LEN);
    AsyncWebServerResponse* res = r->beginResponse_P(200, "application/javascript; charset=utf-8", COLOR_JS_GZ, COLOR_JS_GZ_LEN);
    res->addHeader("Content-Encoding", "gzip");
    res->addHeader("Cache-Control", "no-store");
    r->send(res);
  });

// ---- /ota.js: "设置 -> 固件升级"卡片的脚本(2026-10-07) ----
// 同 bg.js/sd.js/snd.js: 单独一份资源 —— app.js 的 gzip 只剩几十字节, 塞不下任何上传逻辑。
  server.on("/ota.js", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    Serial.printf("[Web] GET /ota.js (gz %uB)\n", (unsigned)OTA_JS_GZ_LEN);
    AsyncWebServerResponse* res = r->beginResponse_P(200, "application/javascript; charset=utf-8", OTA_JS_GZ, OTA_JS_GZ_LEN);
    res->addHeader("Content-Encoding", "gzip");
    res->addHeader("Cache-Control", "no-store");
    r->send(res);
  });

// ---- /alarm.js: "设置 -> 定时开机(闹钟)"卡片的脚本(2026-10-08) ----
// 同 snd.js/ota.js: 单独一份资源 —— app.js 的 gzip 只剩 167B, 这张卡一行都塞不下。
  server.on("/alarm.js", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    Serial.printf("[Web] GET /alarm.js (gz %uB)\n", (unsigned)ALARM_JS_GZ_LEN);
    AsyncWebServerResponse* res = r->beginResponse_P(200, "application/javascript; charset=utf-8", ALARM_JS_GZ, ALARM_JS_GZ_LEN);
    res->addHeader("Content-Encoding", "gzip");
    res->addHeader("Cache-Control", "no-store");
    r->send(res);
  });

// ---- /sd.js: "本地SD卡"标签页的独立脚本(2026-10-07 阶段②) ----
  // 同 bg.js/wifi.js: 单独一份资源, 不动已逼近水位的 app.js。
  server.on("/sd.js", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    Serial.printf("[Web] GET /sd.js (gz %uB)\n", (unsigned)SD_JS_GZ_LEN);
    AsyncWebServerResponse* res = r->beginResponse_P(200, "application/javascript; charset=utf-8", SD_JS_GZ, SD_JS_GZ_LEN);
    res->addHeader("Content-Encoding", "gzip");
    res->addHeader("Cache-Control", "no-store");
    r->send(res);
  });

  // ---- /ctrl.js: "控制"标签页的"设备控制(等效遥控)"独立脚本(2026-10-16 新增) ----
  // 同 sd.js/bg.js: 单独一份资源, 不动已贴近水位的 app.js(全 10 个动作按钮 + 说明会超 4800B)。
  // 仅经 app.js 的全局 wsSend() 协作: 每个按钮 wsSend('act=xxx'), 固件 ir_web_trigger 复用遥控派发。
  server.on("/rb.js", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    Serial.printf("[Web] GET /rb.js (gz %uB)\n", (unsigned)RB_JS_GZ_LEN);
    AsyncWebServerResponse* res = r->beginResponse_P(200, "application/javascript; charset=utf-8", RB_JS_GZ, RB_JS_GZ_LEN);
    res->addHeader("Content-Encoding", "gzip");
    res->addHeader("Cache-Control", "no-store");
    r->send(res);
  });

  server.on("/ctrl.js", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    Serial.printf("[Web] GET /ctrl.js (gz %uB)\n", (unsigned)CTRL_JS_GZ_LEN);
    AsyncWebServerResponse* res = r->beginResponse_P(200, "application/javascript; charset=utf-8", CTRL_JS_GZ, CTRL_JS_GZ_LEN);
    res->addHeader("Content-Encoding", "gzip");
    res->addHeader("Cache-Control", "no-store");
    r->send(res);
  });

  // ---- /bg.js: "屏幕背景"标签页的独立脚本(2026-10-06) ----
  // ★为什么单独一个资源而不是写进 app.js: app.js 的 gzip 已经 4704B, 距单次响应安全水位
  //   4800B 只剩 96B, 塞不下任何上传逻辑。而"标签页切换"这件事是 index.html 里的通用内联脚本,
  //   所以新增一个 tab 只需 HTML 加两行, 完全不碰 app.js —— 这也是本次能不破坏现有功能的关键。
  server.on("/bg.js", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    Serial.printf("[Web] GET /bg.js (gz %uB)\n", (unsigned)BG_JS_GZ_LEN);
    AsyncWebServerResponse* res = r->beginResponse_P(200, "application/javascript; charset=utf-8", BG_JS_GZ, BG_JS_GZ_LEN);
    res->addHeader("Content-Encoding", "gzip");
    res->addHeader("Cache-Control", "no-store");
    r->send(res);
  });

  // ---- /bgb.js: "背景图亮度"滑块(2026-10-10 加, 由 DMradio-tyio 模板同步) ----
  // ★独立资源的硬原因: bg.js 的 gzip 已顶 4800B 水位, 这个滑块+提示再塞进去直接超限。
  //   ★加载顺序: index.html 里在 /bg.js【之后】引入(它 append 到 bg.js 建好的 #bgbox,
  //     并用 bg.js 挂好的 window.BGB/redraw 联动预览)。
  server.on("/bgb.js", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    Serial.printf("[Web] GET /bgb.js (gz %uB)\n", (unsigned)BGB_JS_GZ_LEN);
    AsyncWebServerResponse* res = r->beginResponse_P(200, "application/javascript; charset=utf-8", BGB_JS_GZ, BGB_JS_GZ_LEN);
    res->addHeader("Content-Encoding", "gzip");
    res->addHeader("Cache-Control", "no-store");
    r->send(res);
  });

  // ---- /dith.js: RGB565 量化 + 8x8 Bayer 抖动 的共享库(2026-10-10 由 01 层同步) ----
  // 供 /bg.js 调用: 修"渐变底图一条条色带"(面板只吃 65K 色, 渐变必分层, 抖动打散台阶)。
  // ★独立资源的硬原因: bg.js 的 gzip 已顶 4800B 水位, 那套查表+逐像素循环塞不进去。
  //   ★加载顺序: index.html 里必须在 /bg.js【之前】引入(它是纯函数库, 不碰 DOM, 加载即可用)。
  server.on("/dith.js", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    Serial.printf("[Web] GET /dith.js (gz %uB)\n", (unsigned)DITH_JS_GZ_LEN);
    AsyncWebServerResponse* res = r->beginResponse_P(200, "application/javascript; charset=utf-8", DITH_JS_GZ, DITH_JS_GZ_LEN);
    res->addHeader("Content-Encoding", "gzip");
    res->addHeader("Cache-Control", "no-store");
    r->send(res);
  });

  // 多网络凭据页的逻辑(2026-10-06)。同 /bg.js: 单独一份资源, 不动 app.js(那边只剩几十字节余量)。
  server.on("/wifi.js", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    Serial.printf("[Web] GET /wifi.js (gz %uB)\n", (unsigned)WIFI_JS_GZ_LEN);
    AsyncWebServerResponse* res = r->beginResponse_P(200, "application/javascript; charset=utf-8", WIFI_JS_GZ, WIFI_JS_GZ_LEN);
    res->addHeader("Content-Encoding", "gzip");
    res->addHeader("Cache-Control", "no-store");
    r->send(res);
  });

  // ---- 屏幕背景图: 上传(裸二进制, 恰好 BG_RGB_BYTES 字节) ----
  // ★拆成 /api/bg/l 与 /api/bg/p 两条路由, 比"在 body 里夹方向标记"更简单可靠:
  //   一旦挂了自定义 onBody, 库就不再自动把 body 解析进 r->arg()(见上方 POST 参数解析注释),
  //   查询串/表单字段都取不到了, 方向只能从 URL 上带。
  // ★★这里的响应刻意做成"三重自证", 因为"上传无效"可能卡在三个完全不同的地方,
  //   而它们的现象都是"屏上没变化"。用一条响应把三者一起回报给页面, 一次点击就能定位:
  //     ① 浏览器声明了什么长度(clen)  -> 不对说明是前端发的包就不对(或用了 chunked, 那样 clen=0)
  //     ② 设备实际收到多少字节(got)   -> 收了 0 说明 onBody 压根没被调用
  //     ③ PSRAM 缓冲分配成功没有(buf) -> 失败说明设备内存不足
  {
    auto regBgPost = [](const char* uri, bool portrait) {
      server.on(uri, HTTP_POST,
        [](AsyncWebServerRequest* r) {
          gHttpReq++;
          const size_t clen = r->contentLength();          // 浏览器声明的 Content-Length
          const size_t got  = sBgUpGot;                    // onBody 实际喂进来多少
          const bool   bad  = sBgUpBad;
          const bool   hasB = (sBgUpBuf != nullptr);
          Serial.printf("[BG  ] POST 收完: 声明=%u 实收=%u 缓冲=%s bad=%d\n",
                        (unsigned)clen, (unsigned)got, hasB ? "有" : "无", (int)bad);
          if (clen != (size_t)BG_RGB_BYTES) {
            sBgUpFull = false;                             // 长度不对 -> 整批作废, 不污染文件系统
            r->send(400, "application/json",
                    "{\"ok\":false,\"msg\":\"长度不符: 设备需要 " + String((int)BG_RGB_BYTES) +
                    " 字节, 浏览器声明 " + String((unsigned)clen) + " 字节\"}");
            return;
          }
          if (!hasB || bad || got != (size_t)BG_RGB_BYTES) {
            sBgUpFull = false;
            // 把内存实数一起回报 —— 否则页面只能显示一句"分配失败", 没法判断到底缺多少。
            // (写成 if/else 而不是嵌套三元: 这种长字符串拼接用三元极易数错括号。)
            String why;
            if (!hasB) {
              why = "设备内存分配失败(需 " + String((int)BG_RGB_BYTES) + " 字节连续块; PSRAM 总" +
                    String((unsigned)(ESP.getPsramSize() / 1024)) + "KB 空闲" +
                    String((unsigned)(ESP.getFreePsram() / 1024)) + "KB 最大连续" +
                    String((unsigned)(heap_caps_get_largest_free_block(MALLOC_CAP_SPIRAM) / 1024)) +
                    "KB; 内部RAM 最大连续" +
                    String((unsigned)(heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL) / 1024)) + "KB)";
            } else if (bad) {
              why = "数据超长, 整批作废";
            } else {
              why = "body 没收全: 实收 " + String((unsigned)got) + " 字节";
            }
            Serial.printf("[BG  ] 上传被拒: %s\n", why.c_str());
            r->send(500, "application/json", "{\"ok\":false,\"msg\":\"" + why + "\"}");
            return;
          }
          sBgUpFull = true;                                // 交主循环落盘
          Serial.printf("[BG  ] 已接收 %s 背景 %u 字节, 交主循环落盘\n",
                        sBgUpPort ? "竖屏" : "横屏", (unsigned)got);
          r->send(200, "application/json",
                  "{\"ok\":true,\"queued\":true,\"bytes\":" + String((unsigned)got) + "}");
        },
        nullptr,                                                // 不用 multipart 上传回调
        [portrait](AsyncWebServerRequest* r, uint8_t* data, size_t len, size_t index, size_t total) {
          (void)r; (void)total;
          if (index == 0) bgUpReset(portrait);                  // 每批第一块 -> 重置缓冲
          bgUpChunk(data, len, index);
        });
    };
    regBgPost("/api/bg/l", false);
    regBgPost("/api/bg/p", true);
  }

#if OTA_ENABLED
  // ---- 固件在线升级(2026-10-07) ----
  // ★本版【免密】(见 config.h 的说明): 只有同一局域网内够得着本机才可能升级。
  // ① 信息: 前端先调它拿"当前版本 / 单包上限"。
  server.on("/api/ota/info", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    String s = "{\"ok\":true,\"ver\":\"" + String(FW_VERSION) + "\",\"cur\":\"" + gBuild +
               "\",\"max\":" + String((unsigned)OTA_MAX_IMAGE) + "}";
    r->send(200, "application/json", s);
  });

  // ② 上传固件本体(POST, 裸二进制 body)。
  //    onRequest 回调在【body 全部收完】后才被库调用, 所以"发响应"放这里; 分块写入放 onBody。
  server.on("/api/ota", HTTP_POST,
    [](AsyncWebServerRequest* r) {
      gHttpReq++;
      const bool ok = sOtaOk;
      String s = "{\"ok\":";
      s += ok ? "true" : "false";
      s += ",\"msg\":\"";
      s += ok ? String("升级成功, 设备即将重启") : String(otaErrText(sOtaErr));
      s += "\",\"done\":" + String((unsigned)sOtaDone) + ",\"total\":" + String((unsigned)sOtaTotal) + "}";
      Serial.printf("[OTA ] 上传结束: %s (%u/%u) err=%d\n", ok ? "成功" : "失败",
                    (unsigned)sOtaDone, (unsigned)sOtaTotal, (int)sOtaErr);
      r->send(ok ? 200 : 500, "application/json", s);
    },
    nullptr,                                                  // 不用 multipart 上传回调(与背景图一致)
    [](AsyncWebServerRequest* r, uint8_t* data, size_t len, size_t index, size_t total) {
      if (index == 0) {                                       // 第一块: 校验 + 开工
        sOtaOk = false; sOtaErr = OTA_E_NONE; sOtaDone = 0; sOtaTotal = (uint32_t)total;
        sOtaPtGot = 0; sOtaPtDone = false;
        if (total == 0 || total > OTA_MAX_IMAGE) {
          sOtaErr = OTA_E_LEN;
          Serial.printf("[OTA ] 拒绝: 长度 %u 不合法(上限 %u)\n", (unsigned)total, (unsigned)OTA_MAX_IMAGE);
          return;
        }
        if (pPlayer) pPlayer->stop();                        // ★先停播(命令投递; 真正停播在主循环)
        Serial.printf("[OTA ] 开始写入 %u 字节到空闲 ota 分区...\n", (unsigned)total);
        if (!Update.begin(total)) {
          sOtaErr = OTA_E_BEGIN;
          Serial.printf("[OTA ] Update.begin 失败: %s\n", Update.errorString());
          return;
        }
      }
      if (sOtaErr != OTA_E_NONE || len == 0) return;         // 已出错/空块 -> 丢弃

      // ★防呆(见 sOtaPt 那段注释): 抓 0x8000 起的 16 字节, 判是不是"整片包"。
      //   放在写 flash 之前 —— 一旦命中就当场 abort, 不让它继续写进 app 分区。
      if (!sOtaPtDone) {
        const size_t PT = 0x8000;
        size_t lo = index > PT ? index : PT;
        size_t hi = index + len; if (hi > PT + sizeof(sOtaPt)) hi = PT + sizeof(sOtaPt);
        for (size_t o = lo; o < hi; o++) { sOtaPt[o - PT] = data[o - index]; sOtaPtGot++; }
        if (sOtaPtGot >= sizeof(sOtaPt)) {
          sOtaPtDone = true;
          // AA50 + data/nvs + 标签 "nvs" —— partitions.csv 的第一条恒为此
          if (sOtaPt[0] == 0xAA && sOtaPt[1] == 0x50 && sOtaPt[2] == 0x01 && sOtaPt[3] == 0x02 &&
              sOtaPt[12] == 'n' && sOtaPt[13] == 'v' && sOtaPt[14] == 's') {
            sOtaErr = OTA_E_FULL; Update.abort();
            Serial.println("[OTA ] 拒绝: 上传的是【整片包】(0x8000 处有分区表); 网页升级只收 *.ino.bin");
            return;
          }
        }
      }

      if (Update.write(data, len) != len) {
        sOtaErr = OTA_E_WRITE; Update.abort();
        Serial.println("[OTA ] 写入 flash 失败");
        return;
      }
      sOtaDone = (uint32_t)(index + len);
      if (sOtaDone >= sOtaTotal) {                           // 收齐 -> 校验(失败会自动 abort, 旧固件照常启动)
        if (Update.end(true)) { sOtaOk = true; sOtaErr = OTA_E_NONE; }
        else {
          sOtaErr = OTA_E_END;
          Serial.printf("[OTA ] Update.end 校验失败: %s\n", Update.errorString());
          Update.abort();
        }
      }
    });

  // ③ 进度查询(前端轮询画进度条; 很轻, 每 500ms 一次)
  server.on("/api/ota/progress", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    String s = "{\"done\":" + String((unsigned)sOtaDone) +
               ",\"total\":" + String((unsigned)sOtaTotal) +
               ",\"ok\":" + String(sOtaOk ? "true" : "false") +
               ",\"err\":" + String((int)sOtaErr) +
               ",\"msg\":\"" + String(otaErrText(sOtaErr)) + "\"}";
    r->send(200, "application/json", s);
  });
#endif  // OTA_ENABLED

  // ---- 屏幕背景图: 删除(同样只置标志, 由主循环执行删除) ----
  server.on("/api/bg/clear/l", HTTP_POST, [](AsyncWebServerRequest* r) {
    gHttpReq++; sBgClear = 0; r->send(200, "application/json", "{\"ok\":true}");
  });
  server.on("/api/bg/clear/p", HTTP_POST, [](AsyncWebServerRequest* r) {
    gHttpReq++; sBgClear = 1; r->send(200, "application/json", "{\"ok\":true}");
  });

  // ---- 界面不透明度(0~100): 只改内存里的待应用值, 写 NVS 交给主循环 ----
  // 这个路由【不挂 onBody】(见上方注释), 所以 r->arg() 能正常取到 urlencoded 字段。
  server.on("/api/bg/alpha", HTTP_POST, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    int a = r->arg("v").toInt();
    if (r->arg("v").length() == 0) { r->send(400, "application/json", "{\"ok\":false,\"msg\":\"缺少参数 v\"}"); return; }
    if (a < 0)   a = 0;
    if (a > 100) a = 100;
    sBgAlpha = (int8_t)a;
    r->send(200, "application/json", "{\"ok\":true,\"alpha\":" + String(a) + "}");
  });

  // ---- 背景图亮度(0~100): 同上, 只改内存里的待应用值, 写 NVS 交给主循环 ----
  server.on("/api/bg/bright", HTTP_POST, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    int b = r->arg("v").toInt();
    if (r->arg("v").length() == 0) { r->send(400, "application/json", "{\"ok\":false,\"msg\":\"缺少参数 v\"}"); return; }
    if (b < 0)   b = 0;
    if (b > 100) b = 100;
    sBgBright = (int8_t)b;
    r->send(200, "application/json", "{\"ok\":true,\"bright\":" + String(b) + "}");
  });

  // ---- /raw: 未压缩的 HTML 骨架(4943B, 已逼近 TCP_SND_BUF) ----
  // 诊断对照用: 若 /raw 秒开而 / 不行 -> 问题不在 gzip, 而在响应体大小/续传链。
  server.on("/raw", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    Serial.printf("[Web] GET /raw 未压缩 %uB\n", (unsigned)PAGE_HTML_LEN);
    AsyncWebServerResponse* res = r->beginResponse(200, "text/html; charset=utf-8",
                                                   (const uint8_t*)PAGE_HTML, PAGE_HTML_LEN);
    res->addHeader("Cache-Control", "no-store");
    r->send(res);
  });

  // ---- /sz?n=NNNN: 体积探针, 返回 NNNN 个 'A' ----
  // 用浏览器依次打开 /sz?n=1000 / 3000 / 5000 / 6000 / 8000 / 16000, 哪个开始转圈,
  // 就是这块板子实测的"单次响应水位" —— 把猜测换成实测, 下次排障直接看这个界限。
  server.on("/sz", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    int32_t n = 1000;
    if (r->hasParam("n")) n = r->getParam("n")->value().toInt();
    if (n < 0) n = 0;
    if (n > 60000) n = 60000;
    Serial.printf("[Web] /sz n=%d\n", (int)n);
    AsyncWebServerResponse* res = r->beginResponse("text/plain; charset=utf-8", (size_t)n,
        [n](uint8_t* buf, size_t maxLen, size_t index) -> size_t {
          if (index >= (size_t)n) return 0;
          size_t len = (size_t)n - index;
          if (len > maxLen) len = maxLen;
          memset(buf, 'A', len);
          return len;
        });
    res->setCode(200);
    res->addHeader("Cache-Control", "no-store");
    r->send(res);
  });

  server.onNotFound([](AsyncWebServerRequest* r) {
    gHttpReq++;
    if (apNeedRedirect(r)) { apSendRedirect(r); return; }   // 检测域名访问(如 /hotspot-detect.html) -> 先跳网关
    // captive 兜底: 未匹配路径(含 favicon.ico)一律回首页资源 —— 必须回"小响应",
    // 旧实现回 15KB 整页, 既会卡住收集器也白占一条连接。
    Serial.printf("[Web] 兜底 %s -> html(gz)\n", r->url().c_str());
    AsyncWebServerResponse* res = r->beginResponse_P(200, "text/html; charset=utf-8", PAGE_GZ, PAGE_GZ_LEN);
    res->addHeader("Content-Encoding", "gzip");
    res->addHeader("Cache-Control", "no-store");
    r->send(res);
  });

  server.on("/api/version", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    String s = "{\"ver\":\"" + String(FW_VERSION) + "\",\"build\":\"" + gBuild + "\"}";
    r->send(200, "application/json", s);
  });

  server.on("/api/state", HTTP_GET, [](AsyncWebServerRequest* r) {
    // 只读快照, 绝不在此读 gState(那是异步任务上下文, 与主循环写 String 竞争)。
    // ★★★ 这把锁只用来"取一份私有副本", 发送必须放在【放锁之后】:
    //   send_P()/beginResponse(content,len) 走的是 AsyncProgmemResponse —— 它【只存裸指针,
    //   不拷贝】(ESPAsyncWebServer/src/WebResponses.cpp 构造函数里只有 _content = content)。
    //   真正的数据读取发生在之后的异步发送任务里(_fillBuffer -> memcpy_P), 也就是说
    //   r->send(...) 返回时数据还没被读走。⇒ "锁内 send_P + 立刻放锁" == 根本没锁:
    //   主循环 1200ms 后重建 gSnap(String 变长时 serializeJson 会 realloc 换地址),
    //   异步任务随后按【旧地址】读 -> 偶发半截 JSON / 堆损坏重启(即"页面偶发转圈")。
    //   send(code, ct, const char*) 走 AsyncBasicResponse, 其 _content 是 String, 构造时确实拷贝,
    //   所以这里"锁内拷贝 + 放锁后发送"是安全的零风险写法。
    gHttpReq++;
    String snapshot;
    xSemaphoreTake(gSnapMutex, portMAX_DELAY);
    snapshot = gSnap;
    xSemaphoreGive(gSnapMutex);
    r->send(200, "application/json", snapshot.length() ? snapshot.c_str() : "{}");
  });
  // 播放链诊断(纯文本): 浏览器打开 http://<设备IP>/api/diag 直接可读, 便于排障/截图,
  // 不必去复制串口日志。内容由主循环预先构建, 这里同样"锁内拷贝 + 放锁后发送"(原因见上)。
  server.on("/api/diag", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    String snapshot;
    xSemaphoreTake(gSnapMutex, portMAX_DELAY);
    snapshot = gDiag;
    xSemaphoreGive(gSnapMutex);
    r->send(200, "text/plain; charset=utf-8",
            snapshot.length() ? snapshot.c_str() : "(诊断尚未生成, 稍后再试)");
  });
  // V1.20: 统一系统状态(只读 JSON; 内容由主循环预先构建, 这里"锁内拷贝 + 放锁后发送", 与 /api/state 同一套零风险写法)
  server.on("/api/status", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    String snapshot;
    statusJsonCopy(snapshot);          // 锁内拷贝(statusJsonCopy 内部持锁), 放锁后再发送 —— 与 /api/state 同写法
    r->send(200, "application/json", snapshot.length() ? snapshot.c_str() : "{}");
  });
  // V1.20: 手机状态页(单文件 HTML, 约 5 秒拉一次 /api/status)
  server.on("/status", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    AsyncWebServerResponse* res = r->beginResponse_P(200, "text/html; charset=utf-8", STATUS_PAGE_HTML);
    res->addHeader("Cache-Control", "no-cache");
    r->send(res);
  });
  server.on("/api/stations", HTTP_GET, [](AsyncWebServerRequest* r) {
    // 电台列表按需返回(页面打开/增删改后拉取), 不进周期 /api/state 快照。
    // 避免大列表每 3s 反复序列化拖慢后台 + 在无 PSRAM 板上吃 heap 导致播放卡顿。
    gHttpReq++;
    String body;
    if (pStore) pStore->buildStationsJson(body);
    else        body = "{\"stations\":[]}";
    r->send(200, "application/json", body);
  });

  // ===== 电台增删改: HTTP POST, 直接用 r->arg() 取 urlencoded 字段 =====
  // 不挂 onBody: 让 ESPAsyncWebServer 自动把 body 解析进 r->arg()(已做 urlDecode)
  // ===== 在线电台搜索 radio-browser.info (2026-10-20 新增) =====
  // 三段式, 目的: 绝不在异步任务里拉 HTTPS(那会把 Web/WS 卡住数秒 -> "点了没反应")
  //   ① GET  /api/rb/search?mode=name|top|cn&q=关键词   只置请求, 立即回 {"ok":true}
  //   ② 主循环 rbPoll() 真正拉取(1~6s), 结果进快照
  //   ③ GET  /api/rb/result                             页面轮询取 {state:"running|done|err",n,err,items[]}
  server.on("/api/rb/search", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    String mode = r->hasArg("mode") ? r->arg("mode") : String("name");
    String q    = r->hasArg("q")    ? r->arg("q")    : String("");
    bool ok = rbRequest(mode, q);
    r->send(200, "application/json",
            ok ? "{\"ok\":true}" : "{\"ok\":false,\"msg\":\"上一次搜索还没结束\"}");
  });
  server.on("/api/rb/result", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    r->send(200, "application/json", rbSnapshotJson());
  });
  server.on("/api/rb/play", HTTP_POST, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    int idx = r->hasArg("i") ? r->arg("i").toInt() : -1;
    String nm, url;
    if (!rbItem(idx, nm, url)) {
      r->send(200, "application/json", "{\"ok\":false,\"msg\":\"结果已失效, 请重新搜索\"}");
      return;
    }
    if (pPlayer) pPlayer->play(url);       // 只是投递命令, 主循环执行(与本工程约定一致)
    Serial.println("[RB ] 试听 [" + nm + "] " + url);
    r->send(200, "application/json", "{\"ok\":true}");
  });
  server.on("/api/rb/add", HTTP_POST, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    int idx = r->hasArg("i") ? r->arg("i").toInt() : -1;
    String nm, url;
    if (!rbItem(idx, nm, url)) {
      r->send(200, "application/json", "{\"ok\":false,\"msg\":\"结果已失效, 请重新搜索\"}");
      return;
    }
    if (pStore && pStore->hasUrl(url)) {
      r->send(200, "application/json", "{\"ok\":false,\"msg\":\"该地址已在列表里\"}");
      return;
    }
    bool ok = pStore && pStore->add(nm, url, "在线电台");
    gStoreChanged = true;                 // 列表变了 -> 主循环修正 gState(与 /api/station/add 同)
    Serial.println("[RB ] 加入本机列表 name=[" + nm + "] ok=" + (ok ? "1" : "0"));
    r->send(200, "application/json",
            String("{\"ok\":") + (ok ? "true" : "false") + ",\"msg\":\"" +
            (ok ? String("已加入 共") + String(pStore->count()) + "台" : String("添加失败")) + "\"}");
  });

  server.on("/api/station/add", HTTP_POST, [](AsyncWebServerRequest* r) {
    String name = r->arg("name");
    String url  = r->arg("url");
    String group = r->arg("group");            // 分类(可空 -> "未分类")
    if (name.length() == 0 || url.length() == 0) {
      r->send(200, "application/json", "{\"ok\":false,\"msg\":\"名称或地址为空\"}");
      return;
    }
    bool ok = pStore->add(name, url, group);
    gStoreChanged = true;                    // 列表变了 -> 主循环侧修正/刷新 gState
    Serial.println("[Web] 添加 name=[" + name + "] url=[" + url + "] group=[" + group + "] ok=" + (ok ? "1" : "0") + " 列表数=" + String(pStore->count()));
    r->send(200, "application/json", "{\"ok\":" + String(ok ? "true" : "false") + ",\"msg\":\"已添加 共" + String(pStore->count()) + "台\"}");
  });
  server.on("/api/station/edit", HTTP_POST, [](AsyncWebServerRequest* r) {
    int  id   = r->arg("id").toInt();
    String name = r->arg("name");
    String url  = r->arg("url");
    String group = r->arg("group");            // 空 -> 不改动原分类(见 StationStore::update)
    bool ok = pStore->update(id, name, url, group);
    gStoreChanged = true;                    // 可能改的是正在播的那台 -> 主循环刷新台名
    Serial.println("[Web] 编辑 id=" + String(id) + " name=[" + name + "] group=[" + group + "] ok=" + (ok ? "1" : "0"));
    r->send(200, "application/json", "{\"ok\":" + String(ok ? "true" : "false") + ",\"msg\":\"" + (ok ? "已修改" : "修改失败(序号越界)") + "\"}");
  });
  // ===== 批量设置分类(2026-10-07): 后台列表多选后统一改分类 =====
  // POST /api/station/group  字段: ids=3,7,12 (逗号分隔的【真实下标】)  group=目标分类
  // group 留空 = 归入"未分类"(与单台编辑同规则)。返回实际改动台数。
  server.on("/api/station/group", HTTP_POST, [](AsyncWebServerRequest* r) {
    const String idsTxt = r->arg("ids");
    if (idsTxt.length() == 0) {
      r->send(400, "application/json", "{\"ok\":false,\"msg\":\"没有选中任何电台\"}");
      return;
    }
    // 解析逗号分隔的下标。注意用 String::toInt 逐段解析, 不做 atoi 整串(那样 "3,7"只会得到 3)。
    std::vector<int> ids;
    int start = 0;
    for (int i = 0; i <= (int)idsTxt.length(); i++) {
      if (i == (int)idsTxt.length() || idsTxt[i] == ',') {
        const String one = idsTxt.substring(start, i);
        if (one.length()) ids.push_back(one.toInt());
        start = i + 1;
      }
    }
    if (ids.empty()) {
      r->send(400, "application/json", "{\"ok\":false,\"msg\":\"ids 格式不对(应为 3,7,12)\"}");
      return;
    }
    const String group = r->arg("group");
    const int changed = pStore->setGroupBatch(ids, group);
    gStoreChanged = true;                    // 分类变了 -> 主循环侧修正 gState
    Serial.printf("[Web] 批量设分类: 选中 %d 台, 改动 %d 台 -> [%s]\n",
                  (int)ids.size(), changed, group.c_str());
    r->send(200, "application/json",
            "{\"ok\":true,\"changed\":" + String(changed) +
            ",\"msg\":\"已把 " + String(changed) + " 台设为「" +
            (group.length() ? group : String("未分类")) + "」\"}");
  });

  server.on("/api/station/del", HTTP_POST, [](AsyncWebServerRequest* r) {
    int id = r->arg("id").toInt();
    bool ok = pStore->remove(id);
    // 注意: 【不在此写 gState】(异步任务上下文)。当前播放下标的修正交给主循环
    // WebServerSvc::loop() 处理 —— 直接写 gState.stationName(String) 会与
    // 主循环显示刷新/状态快照竞争造成堆损坏。
    gStoreChanged = true;
    Serial.println("[Web] 删除 id=" + String(id) + " ok=" + (ok ? "1" : "0") + " 剩余=" + String(pStore->count()));
    r->send(200, "application/json", "{\"ok\":" + String(ok ? "true" : "false") + ",\"msg\":\"已删除 共" + String(pStore->count()) + "台\"}");
  });

  // ===== 批量导入电台(CSV/TSV 文本) =====
  // 前端把选中的文件用 FileReader 读成文本(或直接粘贴), 以 urlencoded 的 list= 字段 POST 上来 ——
  // 故意不用 multipart/form-data: ESP32 上解析 multipart 既慢又占内存, 而文本提交同样可靠。
  // 本回调只解析进内存(importText)并 requestSaveNow() 请求主循环落盘 ——
  // ★绝不在异步任务里写文件系统(那正是"导入的电台重启后丢失/写半截"的老根因)。
  server.on("/api/station/import", HTTP_POST, [](AsyncWebServerRequest* r) {
    String listTxt = r->arg("list");
    bool   replace = (r->arg("replace") == "1");
    if (listTxt.length() == 0) {
      r->send(200, "application/json", "{\"ok\":false,\"msg\":\"内容为空(请粘贴或选择文件)\"}");
      return;
    }
    int before = pStore->count();
    int added  = pStore->importText(listTxt, replace);
    gStoreChanged = true;
    pStore->requestSaveNow();                 // 由主循环立刻落盘(不在本上下文写盘)
    Serial.printf("[Web] 导入 文本%uB replace=%d : %d台 -> %d台 (新增%d)\n",
                  (unsigned)listTxt.length(), replace ? 1 : 0, before, pStore->count(), added);
    r->send(200, "application/json",
            "{\"ok\":" + String(added > 0 ? "true" : "false") + ",\"msg\":\"导入完成: 新增" +
            String(added) + "台, 现有" + String(pStore->count()) + "台\"}");
  });

  // ===== WiFi 配网保存 / 重置: 普通 HTTP POST =====
  // 关键: 设备处于 AP 热点(无外网)时, 手机的 WebSocket 常被 captive portal 限制或自动改走
  // 蜂窝数据而连不上网关, 导致"页面能开、保存却无效"。改走 HTTP(与已能加载的页面同源同机制),
  // 跨设备一致可靠。设备收到即写 NVS 并置重启标志(真正重启在 loop() 执行), 响应是否到达客户端无所谓。
  // 注意: 不挂 onBody, 让库自动把 body 解析进 r->arg()(已做 urlDecode), 与 /api/station/* 一致。
  server.on("/api/wifi", HTTP_POST, [](AsyncWebServerRequest* r) {
    String ssid = r->arg("ssid");
    String pwd  = r->arg("pwd");
    if (ssid.length() == 0) {
      r->send(200, "application/json", "{\"ok\":false,\"msg\":\"SSID 为空\"}");
      return;
    }
    Serial.println("[Web] WiFi保存(HTTP) ssid=[" + ssid + "] pwd_len=" + String(pwd.length()));
    pPortal->saveAndRestart(ssid, pwd);
    r->send(200, "application/json", "{\"ok\":true,\"msg\":\"已保存, 设备重启中\"}");
  });
  server.on("/api/reset", HTTP_POST, [](AsyncWebServerRequest* r) {
    Serial.println("[Web] 重置配网(HTTP)");
    pPortal->resetConfig();
    r->send(200, "application/json", "{\"ok\":true,\"msg\":\"已重置, 设备重启中\"}");
  });
  // 睡眠定时器(2026-10-06 阶段①): POST min=<分钟>(0=取消)。与 WS sleep 指令同一后端。
  server.on("/api/sleep", HTTP_POST, [](AsyncWebServerRequest* r) {
    const int m = r->arg("min").toInt();
    pPlayer->setSleepTimer(m);
    Serial.println("[Web] 睡眠定时器(HTTP) min=" + String(m));
    r->send(200, "application/json", "{\"ok\":true,\"sleepMin\":" + String(m) + "}");
  });

  // ===== 定时开机(闹钟, 2026-10-08) =====
  // GET 读当前配置(页面回填用, 也可直接从 /api/state 的 alarm 字段取);
  // POST 保存。参数 urlencoded, 时间字段用 "HH:MM"; 未出现的字段保持原值。
  // ★线程纪律: 这里只调 alarmSave()(锁内改内存 + 置脏), NVS 落盘由 alarmTick() 在主循环做
  //   —— 与本工程"不在 Web 异步上下文写 flash"的既有约定一致。
  server.on("/api/alarm", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    const AlarmCfg c = alarmGet();
    String j = "{\"en\":"       + String(c.en    ? 1 : 0) +
               ",\"onH\":"      + String((int)c.onH) +
               ",\"onM\":"      + String((int)c.onM) +
               ",\"offEn\":"    + String(c.offEn ? 1 : 0) +
               ",\"offH\":"     + String((int)c.offH) +
               ",\"offM\":"     + String((int)c.offM) +
               ",\"url\":\""    + jsonEsc(c.url) +
               "\",\"name\":\"" + jsonEsc(c.name) + "\"}";
    r->send(200, "application/json", j);
  });
  // POST /api/alarm   en=0/1 & on=HH:MM & offen=0/1 & off=HH:MM & url=... & name=...
  server.on("/api/alarm", HTTP_POST, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    AlarmCfg c = alarmGet();
    if (r->hasParam("en"))    c.en    = r->arg("en").toInt()    != 0;
    if (r->hasParam("offen")) c.offEn = r->arg("offen").toInt() != 0;
    int h = 0, m = 0;
    if (r->hasParam("on")  && parseHHMM(r->arg("on"),  h, m)) { c.onH  = (uint8_t)h; c.onM  = (uint8_t)m; }
    if (r->hasParam("off") && parseHHMM(r->arg("off"), h, m)) { c.offH = (uint8_t)h; c.offM = (uint8_t)m; }
    if (r->hasParam("url"))  c.url  = r->arg("url");
    if (r->hasParam("name")) c.name = r->arg("name");
    const bool ok = alarmSave(c);
    Serial.printf("[Web] 定时开机保存: %s | 开播 %02u:%02u -> %s | 停播 %s %02u:%02u\n",
                  c.en ? "启用" : "关闭", (unsigned)c.onH, (unsigned)c.onM,
                  c.url.length() ? c.url.c_str() : "(未指定电台)",
                  c.offEn ? "启用" : "关闭", (unsigned)c.offH, (unsigned)c.offM);
    r->send(200, "application/json", ok ? "{\"ok\":true}" : "{\"ok\":false}");
  });

  // ===== 本地 SD 卡(阶段②) =====
  // ★线程纪律: 这三个路由都在 async_tcp 任务上下文, 因此【一律不碰 SD 卡驱动】——
  //   扫描只"置标志"交给主循环(sdReqScan), 播放只"投递命令"(playSdFile),
  //   列表只读主循环已构建好的 JSON 快照(sdGetJson)。理由见 sd_card.h 的线程模型说明。
  //
  // GET /api/sd/list?scan=1  读取文件列表(scan=1 时顺带请求重新扫描, 响应里带 "scanning":true)
  server.on("/api/sd/list", HTTP_GET, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    if (r->hasParam("scan") && r->getParam("scan")->value() == "1") sdReqScan();
    String j;
    if (!sdGetJson(j) || j.length() == 0) {
      // 还没扫描过: 返回一个明确的"请先扫描", 而不是空数组(页面据此自动触发一次扫描)
      r->send(200, "application/json",
              "{\"ok\":true,\"mounted\":false,\"count\":0,\"files\":[],\"scanning\":true}");
      return;
    }
    r->send(200, "application/json", j);
  });
  // POST /api/sd/scan  只请求重新扫描(不取列表)
  server.on("/api/sd/scan", HTTP_POST, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    sdReqScan();
    r->send(200, "application/json", "{\"ok\":true,\"msg\":\"正在扫描 SD 卡\"}");
  });
  // POST /api/sd/play?i=<序号>  播放指定文件
  server.on("/api/sd/play", HTTP_POST, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    const int i = r->arg("i").toInt();
    if (i < 0) { r->send(400, "application/json", "{\"ok\":false,\"msg\":\"序号不能为负\"}"); return; }
    pPlayer->playSdFile(i);              // 投递命令; 越界由主循环钳制
    Serial.println("[Web] SD 播放请求 #" + String(i));
    r->send(200, "application/json", "{\"ok\":true,\"msg\":\"已投递播放命令\"}");
  });
  // POST /api/sd/exit  退出 SD 音源, 回到网络电台
  server.on("/api/sd/exit", HTTP_POST, [](AsyncWebServerRequest* r) {
    gHttpReq++;
    sdReqExit();
    r->send(200, "application/json", "{\"ok\":true,\"msg\":\"已回到网络电台\"}");
  });

  // ===== 多网络凭据(2026-10-06): 最多 3 组, 后台"WiFi 配网"卡片用 =====
  // ★全走 HTTP POST 而不是 WebSocket —— 与上面 /api/wifi 同样的理由: 设备处于 AP 热点(无外网)时,
  //   手机的 WebSocket 常被 captive portal 限制或自动改走蜂窝数据而连不上网关,
  //   表现为"页面打得开、保存却没反应"。HTTP 与页面同源同机制, 跨设备一致可靠。
  // ★分工: slot/del 只写 NVS【不重启】(用户可能一次改好几个槽), 改完由 apply 统一重启。
  server.on("/api/wifi/slot", HTTP_POST, [](AsyncWebServerRequest* r) {
    const int slot = r->arg("slot").toInt();
    const String ssid = r->arg("ssid");
    if (slot < 0 || slot >= WIFI_SLOT_COUNT) {
      r->send(400, "application/json", "{\"ok\":false,\"msg\":\"槽位越界\"}"); return;
    }
    if (ssid.length() == 0) {
      r->send(400, "application/json", "{\"ok\":false,\"msg\":\"SSID 不能为空(要清空请用清空按钮)\"}"); return;
    }
    // ★密码: 请求里【没有 pwd 字段】= 保持原密码不变。页面上密码框永远留空(不显示已存密码),
    //   所以用户只改 SSID 时不会把密码抹掉。
    const bool keepPwd = !r->hasParam("pwd");
    const String pwd = keepPwd ? String("") : r->arg("pwd");
    Serial.printf("[Web] WiFi 槽%d <- [%s] keepPwd=%d\n", slot, ssid.c_str(), (int)keepPwd);
    pPortal->setSlot(slot, ssid, pwd, keepPwd);
    r->send(200, "application/json", "{\"ok\":true}");
  });
  server.on("/api/wifi/del", HTTP_POST, [](AsyncWebServerRequest* r) {
    const int slot = r->arg("slot").toInt();
    if (slot < 0 || slot >= WIFI_SLOT_COUNT) {
      r->send(400, "application/json", "{\"ok\":false,\"msg\":\"槽位越界\"}"); return;
    }
    Serial.printf("[Web] WiFi 清空槽%d\n", slot);
    pPortal->delSlot(slot);
    r->send(200, "application/json", "{\"ok\":true}");
  });
  server.on("/api/wifi/apply", HTTP_POST, [](AsyncWebServerRequest* r) {
    Serial.println("[Web] WiFi 多组配置已保存, 准备重启");
    pPortal->saveAllAndRestart();
    r->send(200, "application/json", "{\"ok\":true,\"msg\":\"已保存, 设备重启中\"}");
  });

  server.begin();
  Serial.println("[Web] 服务已启动 (80) ｜ WebSocket /ws");

#if OTA_ENABLED
  // ===================== 兜底通路: ArduinoOTA (端口 3232) =====================
  // 为什么留这条: 网页升级依赖"页面上传 + 分区写入"整条链都正常。万一哪天刷进去一个
  // 网页坏掉的固件, 网页入口就没了 —— 这时只有 ArduinoOTA 能把设备救回来
  // (Arduino IDE 里选"网络端口"上传, 或 arduino-cli upload -p <设备IP> --protocol network)。
  // ★本版【不设密码】(与网页升级一致): 局域网内自用, 少一道记密码的麻烦。
  //   要恢复: 在下面 setHostname 之前加一行 ArduinoOTA.setPassword("你的密码")。
  // ★begin() 会顺带把主机名注册进 mDNS —— IDE 就是靠它把设备列出来的。
  ArduinoOTA.setHostname(OTA_HOSTNAME);
  ArduinoOTA.onStart([]() {
    Serial.printf("\n[OTA ] ArduinoOTA 开始接收...\n");
    if (pPlayer) pPlayer->stop();          // 同样先停播
  });
  ArduinoOTA.onEnd([]() { Serial.println("\n[OTA ] ArduinoOTA 接收完成, 即将重启"); });
  ArduinoOTA.onProgress([](unsigned int done, unsigned int total) {
    static uint32_t last = 0;
    if (millis() - last < 500) return;     // 节流: 别把串口刷爆
    last = millis();
    Serial.printf("[OTA ] ArduinoOTA 进度 %u%%\n", total ? (unsigned)(done * 100ULL / total) : 0);
  });
  ArduinoOTA.onError([](ota_error_t e) { Serial.printf("[OTA ] ArduinoOTA 错误 code=%u\n", (unsigned)e); });
  ArduinoOTA.begin();
  Serial.printf("[OTA ] 网页升级就绪(免密) | ArduinoOTA 主机名 \"%s\" 端口 3232\n", OTA_HOSTNAME);
#endif  // OTA_ENABLED
}
