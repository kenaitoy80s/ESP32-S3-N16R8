================================================================
webradio-s3p v1.16  开发迁移包        wrb-s3p-v116-mig
                                    （导出于 2026-10-27）
================================================================

【这是什么】
  ESP32-S3 N16R8 网络收音机（四屏位主线版）的**完整可编译快照**。
  包里自带交叉编译器 + arduino-esp32 3.3.11 核心 + 全部依赖库，
  **新电脑不用装 Arduino IDE、不用联网、不用配环境变量**，
  解压后双击两个 .cmd 就能编出和原机器一样的 bin。

  包结构:
      wrb-s3p-v116-mig\
        ├─ webradio-s3p\      工程源码（全量, 含 docs / tools / firmware / _archive）
        ├─ tc\                工具链（2042 MB / 18564 个文件）
        │    ├─ arduino-cli.exe
        │    ├─ arduino15\               ← 当 ARDUINO_DIRECTORIES_DATA
        │    └─ user\libraries\          ← 当 ARDUINO_DIRECTORIES_USER
        │         （★要注意这一层: USER 要的是"用户目录", 库在它的 libraries\ 里）
        ├─ setup.cmd          环境自检（双击）
        └─ 00-README-先读我.txt


================================================================
★★ 第0步（最重要）：路径必须【纯英文】且【够短】
================================================================
  解压到哪儿决定了能不能编出来。两条硬约束：

  ① 纯英文 —— 不要 C:\Users\张三\桌面\、不要 D:\esp32项目\ 这类含中文的位置。
     中文路径会让链接器 ld.exe 找不到 -lcore / -lmbedtls 这些预编译库，
     报一大片 undefined reference（看着像"丢库了"，其实是路径问题）。

  ② 够短 —— 包路径（含末尾反斜杠）**不超过 71 个字符**。
     这是 Windows MAX_PATH(259) 的限制，而且是本包里最容易踩的坑：
     GCC 找 C++ 标准库头文件时用的是**带 `..` 的未规范化路径**，
     实测包里最长那条 = 包路径 + "tc\arduino15" + 175 字符。
     一旦超 259，编译就报
         bits/cpu_defines.h: No such file or directory
     —— 文件明明躺在硬盘上，却报"找不到"，非常容易误判成工具链残缺、白折腾。
     ★setup.cmd 会自动数这个字符数，超了直接告诉你超多少，不用自己算。

  推荐位置（都是 71 以内、纯英文）:
        D:\wrb\wrb-s3p-v116-mig\
        C:\wrb\wrb-s3p-v116-mig\
        C:\dev\wrb-s3p-v116-mig\
  不要用: D:\esp32项目\xx\ （中文）、
          C:\Users\hudie\Desktop\esp32\wrb-s3p-v116-mig\（45 字符, 勉强可以,
          但再往下一层就危险）、
          C:\Users\xxx\Documents\Arduino\projects\wrb-s3p-v116-mig\（太长）


================================================================
一、新电脑上三步
================================================================
  第1步  双击  setup.cmd
         只做检查（不改系统设置、不写注册表、不联网）:
           ① 包内文件齐不齐  ② 路径英文 + 长度  ③ 有没有 Python
           ④ 真调一次 arduino-cli 看平台装没装好
         看到  SETUP OK  继续。

  第2步  双击  webradio-s3p\compile.cmd
         首次全量编译（建库依赖表 + 编全部库）约 3~5 分钟，之后增量 30~60 秒。
         看到 EXIT 0 即成功，产物在 %TEMP%\wrb_s3p\:
             webradio-s3p.ino.bin             应用（烧录用这个）
             webradio-s3p.ino.bootloader.bin
             webradio-s3p.ino.partitions.bin

  第3步  插板子，双击  webradio-s3p\upload.cmd   （只写 app，保住 WiFi 与电台表）
         新板第一次装机 / 想彻底恢复出厂 → webradio-s3p\flash_full.cmd
         （连 nvs 和文件系统一起清，会丢 WiFi 密码和电台表）


================================================================
二、包里有什么
================================================================
  webradio-s3p\
    ├─ webradio-s3p.ino     主程序（约 10 万字节；各模块在 src\ 下）
    ├─ src\                 core / net / ui / data 四个子目录
    ├─ docs\                IO分配表.txt / 功能表.txt / 代码审查报告.md
    ├─ tools\               编译/烧录/网页资源生成/库补丁/路径解析 等脚本
    ├─ firmware\            v1.16 的 web+full 两个 bin 与 SHA256（_archive 是旧版）
    ├─ partitions.csv       自定义分区表（双 app 3MB，网页 OTA 用）
    ├─ build_opt.h          ★起播预缓冲宏 AUDIO_MIN_BUFFER_BYTES=32768
    ├─ README.md            完整开发约定（遇到细节先翻它）
    └─ compile.cmd / upload.cmd / flash_full.cmd    双击即用

  tc\
    ├─ arduino-cli.exe      1.5.1（36 MB）
    ├─ arduino15\packages\
    │    ├─ esp32\hardware\esp32\3.3.11      arduino-esp32 核心（75 MB）
    │    └─ esp32\tools\
    │         esp-x32            Xtensa GCC 交叉编译器（1.4 GB，编译必需）
    │         esp32s3-libs       S3 预编译库（236 MB）
    │         esp32-libs         经典 ESP32 预编译库（178 MB，本工程用不到，留着防身）
    │         esptool_py\5.3.1   烧录工具
    │         mklittlefs / mkspiffs
    └─ user\libraries\
         ESP32-audioI2S-nopsram   ★已打补丁的音频库（fork，别换回官方版）
         U8g2 / AsyncTCP / ESPAsyncWebServer / ArduinoJson
         SD / Adafruit_BusIO / Adafruit_GFX / Adafruit_ST77xx / Adafruit_seesaw


================================================================
三、编译参数（与原机器完全一致，别改）
================================================================
  FQBN:
    esp32:esp32:esp32s3:PartitionScheme=custom,PSRAM=opi,FlashMode=dio,
    FlashSize=16M,USBMode=hwcdc,CDCOnBoot=cdc

  ★FlashMode 必须是 dio，不能是 qio:
    N16R8 的 8MB PSRAM 是 Octal(OPI)，bootloader 的选择只由 FlashMode 决定。
    选 qio 会拿到按 QUAD 初始化 PSRAM 的 bootloader → psramSize=0
    → 背景图 150KB 分配不出来、音频 512KB 输入缓冲静默退回 16KB（表现为卡顿）。
    改 dio 后走 bootloader_dio_80m.elf，PSRAM 正常。（烧录的 flash 读取模式没变）

  ★别用 --skip-libraries-discovery:
    它会把 build 目录里的库 .o 清空，链接阶段报一大片 undefined reference
    （WiFiAPClass / Preferences / AsyncUDP ...），而 build.options.json 还在，
    很容易误以为工程坏了。


================================================================
四、被裁掉的东西（要的话联网装一次就有）
================================================================
  xtensa-esp-elf-gdb (126 MB)   调试器，纯编译烧录用不到
  openocd-esp32 (9.6 MB)        片上调试，同上
  library_index.json / package_esp32*.json   索引与安装缓存
  staging\、inventory.yaml      安装残留（新机器会自动重建）
  user\libraries\*\examples、extras  示例与测试，不影响编译
  想补回来（比如要单步调试）:
      tc\arduino-cli.exe core install esp32:esp32@3.3.11
  或用 Arduino IDE 的 Boards Manager 装 3.3.11。

  ★tc\user\libraries\ESP32-audioI2S-nopsram 是**打过补丁的 fork**，不是官方原版:
    补丁 = 起播预缓冲(AUDIO_MIN_BUFFER_BYTES) + HLS 重抓间隔(M3U8_REFRESH_MS)。
    别用官方版覆盖，否则"换台后卡十几秒才流畅"会回来。
    补丁丢了重打:  python tools\patch_audio_lib.py


================================================================
五、和原机器用法上的差别
================================================================
  1) 工具链不再依赖 %TEMP%\tyio_data / %TEMP%\tyio_libs。
     新增 tools\toolchain_paths.py 统一解析，优先级:
        环境变量  >  包内 tc\（或 toolchain\）  >  %TEMP% 的 ASCII 副本  >  历史路径
     原机器上行为一字未变（仍命中 %TEMP% 那份）；新机器自动命中包内 tc\。
     想知道实际用的哪份:   python tools\toolchain_paths.py
     编译前它还会顺手检查路径长度，超 MAX_PATH 直接给出人话提示。

  2) 工程文件夹名改成了 webradio-s3p（原机器叫
     webradio-s3p-4screen-mainline-v1.16）。Arduino 硬规则:
     **主 .ino 名必须等于所在文件夹名**，原名对不上要靠目录联接(junction)绕，
     同名后编译直连。以后发新版**别再改文件夹名**。

  3) 编译产物仍在 %TEMP%\wrb_s3p\（与 upload.cmd / flash_full.cmd 一致）。
     若新机器用户名是中文导致 %TEMP% 含中文，脚本会自动改用 C:\wrb_s3p_env\。


================================================================
六、包里现成的固件（不想编译可以直接烧）
================================================================
  webradio-s3p\firmware\
    webradio-s3p-v1.16-web.bin      2,207,088 B   网页后台 OTA（app-only）
    webradio-s3p-v1.16-full.bin     6,356,992 B   插线整片线刷（从 0x0）
    webradio-s3p-v1.16-SHA256.txt   两个包的校验值
  自检口径: web 包首字节 0xE9 且 0x8000 处**不是** AA 50 01 02；
            full 包 0x8000 处**必须**是 AA 50 01 02。


================================================================
七、继续开发的铁律（摘自工程 README / 项目记忆）
================================================================
  · 每次改动把 src\config.h 的 FW_VERSION +0.1，重编，同时出 web + full 两个包，
    旧包移进 firmware\_archive\，回复里写版本号 + 两个 sha256。
  · 加/改引脚或功能 → 同步 docs\IO分配表.txt 与 docs\功能表.txt。
    编码别乱: 功能表 = UTF-8-BOM + LF；IO表 = UTF-8-BOM + CRLF；README = UTF-8 + LF。
  · 三个 .cmd 必须 ANSI(GBK) + CRLF，不许写 chcp 65001。改完自查:
        python tools\fix_cmd_encoding.py --check
  · 改网页（tools\web_page\）后必须跑 python tools\gen_page_gz.py 重新生成
    src\net\page_assets.h（单资源 gzip > 4800B 是硬失败，会拖垮音频抢网时的后台）。
  · 线程模型: 音频泵是独立任务，库回调里绝不能写 gState 的 String；
    Web/WS 回调在 async_tcp 任务，只发 gSnap 快照，电台表只经 StationStore 递归锁。
  · 切屏必须主动关旧屏（SSD1306/ST7567/ST7789 三种关法不同，见工程 README）。

================================================================
八、编译不通过时按这个顺序查
================================================================
  1) setup.cmd 里哪项报了 [缺失]/[错误] —— 多半是复制不全、路径含中文、路径太长。
  2) python tools\toolchain_paths.py  看三个路径对不对、是否 ASCII、是否超长。
  3) 打开 %TEMP%\wrb_s3p_compile.log，搜第一条 error（不是 warning）。
  4) "main file missing from sketch" → 有人把文件夹改名了，改回 webradio-s3p。
  5) 一堆 undefined reference 且日志里能搜到 skip-libraries-discovery →
     删掉 %TEMP%\wrb_s3p 整个目录重编，别用 --fast。
  6) "bits/cpu_defines.h: No such file or directory" → **路径太长**，
     把包移到更短的英文路径（见本文开头第0步），不是工具链缺文件。

================================================================
