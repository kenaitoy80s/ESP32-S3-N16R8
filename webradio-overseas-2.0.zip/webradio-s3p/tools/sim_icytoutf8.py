#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
把 webradio-s3p 固件里的 icyToUtf8() / undoDoubleEncode() 算法【原样搬到 Python】,
用真实的 ICY 原始字节跑一遍, 看它对正常标题会不会误改写。

固件源码: src/core/audio_player.cpp (isUtf8 / looksGb2312 / nextCp / allCjkish /
          uniToGbk / decodeGbkAsUtf8 / undoDoubleEncode / icyToUtf8)
"""
import sys


# ---------- 用 Python 的 gb2312/gbk 编解码代替固件里的查表 ----------
def gb2312_mapped(c, t):
    """固件 gGb2312Uni[(c-0xA1)*94+(t-0xA1)] != 0  <->  GB2312 里该区位有字"""
    try:
        bytes([c, t]).decode("gb2312")
        return True
    except Exception:
        return False


def uni_to_gbk(cp):
    """固件 uniToGbk(): Unicode -> GBK 双字节; 未收录返回 0"""
    try:
        b = chr(cp).encode("gbk")
    except Exception:
        return 0
    if len(b) != 2:
        return 0
    return (b[0] << 8) | b[1]


# ---------- 固件 isUtf8() ----------
def is_utf8(bs):
    i, n = 0, len(bs)
    while i < n:
        c = bs[i]
        if c < 0x80:
            i += 1
        elif (c & 0xE0) == 0xC0:
            if i + 1 >= n or (bs[i + 1] & 0xC0) != 0x80:
                return False
            i += 2
        elif (c & 0xF0) == 0xE0:
            if i + 2 >= n or (bs[i + 1] & 0xC0) != 0x80 or (bs[i + 2] & 0xC0) != 0x80:
                return False
            i += 3
        elif (c & 0xF8) == 0xF0:
            if i + 3 >= n or (bs[i + 1] & 0xC0) != 0x80 or (bs[i + 2] & 0xC0) != 0x80 or (bs[i + 3] & 0xC0) != 0x80:
                return False
            i += 4
        else:
            return False
    return True


# ---------- 固件 looksGb2312() ----------
def looks_gb2312(bs):
    pairs = ok = 0
    i, n = 0, len(bs)
    while i < n:
        c = bs[i]
        if c < 0x80:
            i += 1
            continue
        if c < 0xA1 or c > 0xF7 or i + 1 >= n or bs[i + 1] < 0xA1 or bs[i + 1] > 0xFE:
            return False
        if gb2312_mapped(c, bs[i + 1]):
            ok += 1
        pairs += 1
        i += 2
    return pairs > 0 and ok * 2 >= pairs


# ---------- 固件 nextCp(): 从 UTF-8 串 pos 取码点, 4 字节序列刻意返回 False ----------
def next_cp(bs, pos):
    n = len(bs)
    if pos >= n:
        return None
    c = bs[pos]
    if c < 0x80:
        return c, pos + 1
    if (c & 0xE0) == 0xC0 and pos + 1 < n and (bs[pos + 1] & 0xC0) == 0x80:
        return ((c & 0x1F) << 6) | (bs[pos + 1] & 0x3F), pos + 2
    if (c & 0xF0) == 0xE0 and pos + 2 < n and (bs[pos + 1] & 0xC0) == 0x80 and (bs[pos + 2] & 0xC0) == 0x80:
        return ((c & 0x0F) << 12) | ((bs[pos + 1] & 0x3F) << 6) | (bs[pos + 2] & 0x3F), pos + 3
    return None


def all_cjkish(t):
    if not t:
        return False
    pos = 0
    while pos < len(t):
        r = next_cp(t, pos)
        if r is None:
            return False
        cp, pos = r
        if cp < 0x2E80:
            return False
    return True


# ---------- 固件 decodeGbkAsUtf8() ----------
def decode_gbk_as_utf8(b, seg_chars):
    # ① 严格: 整段合法 UTF-8
    t = bytearray()
    pos, ok = 0, True
    n = len(b)
    while pos < n:
        c = b[pos]
        if c < 0x80:
            t.append(c); pos += 1
        elif (c & 0xE0) == 0xC0 and pos + 1 < n and (b[pos + 1] & 0xC0) == 0x80:
            t += bytes(b[pos:pos + 2]); pos += 2
        elif (c & 0xF0) == 0xE0 and pos + 2 < n and (b[pos + 1] & 0xC0) == 0x80 and (b[pos + 2] & 0xC0) == 0x80:
            t += bytes(b[pos:pos + 3]); pos += 3
        else:
            ok = False; break
    if ok and all_cjkish(bytes(t)):
        return bytes(t)
    # ② 容错: 丢掉错位字节
    t2 = bytearray()
    pos = 0
    while pos < n:
        c = b[pos]
        if c < 0x80:
            t2.append(c); pos += 1; continue
        if (c & 0xE0) == 0xC0 and pos + 1 < n and (b[pos + 1] & 0xC0) == 0x80:
            t2 += bytes(b[pos:pos + 2]); pos += 2; continue
        if (c & 0xF0) == 0xE0 and pos + 2 < n and (b[pos + 1] & 0xC0) == 0x80 and (b[pos + 2] & 0xC0) == 0x80:
            t2 += bytes(b[pos:pos + 3]); pos += 3; continue
        pos += 1
    if all_cjkish(bytes(t2)) and len(t2) >= seg_chars * 2 // 3 - 1:
        return bytes(t2)
    return b""


# ---------- 固件 undoDoubleEncode() ----------
def undo_double_encode(s: str) -> bytes:
    raw = s.encode("utf-8")
    n = len(raw)
    out = bytearray()
    changed = False
    i = 0
    while i < n:
        j, blen, seg = i, 0, 0
        buf = bytearray()
        while j < n:
            save = j
            r = next_cp(raw, j)
            if r is None:
                j = save; break
            cp, j = r
            if cp < 0x80:
                j = save; break
            g = uni_to_gbk(cp)
            if not g:
                j = save; break
            if blen + 2 > 384:
                j = save; break
            buf.append(g >> 8); buf.append(g & 0xFF)
            blen += 2; seg += 1
        if seg == 0:
            save = i
            r = next_cp(raw, i)
            if r is not None:
                cp, i = r
                out += raw[save:i]
            else:
                out += raw[save:save + 1]; i = save + 1
            continue
        if j < n and raw[j] == 0x3F and (blen % 3) != 0:   # 吞掉残字节留下的 '?'
            j += 1
        r2 = decode_gbk_as_utf8(bytes(buf), seg)
        if r2:
            out += r2; changed = True
        else:
            out += raw[i:j]
        i = j
    return bytes(out) if changed else b""


# ---------- 固件 icyToUtf8() ----------
def icy_to_utf8(bs: bytes):
    if not bs:
        return b"", "空"
    if is_utf8(bs):
        s = bs.decode("utf-8", "replace")
        fixed = undo_double_encode(s)
        if fixed:
            return fixed, "UTF-8(已还原)"
        return bs, "UTF-8"
    if looks_gb2312(bs):
        out = bytearray()
        i = 0
        while i < len(bs):
            c = bs[i]
            if c < 0x80:
                out.append(c); i += 1; continue
            if 0xA1 <= c <= 0xF7 and i + 1 < len(bs) and 0xA1 <= bs[i + 1] <= 0xFE:
                try:
                    ch = bytes([c, bs[i + 1]]).decode("gb2312")
                    out += ch.encode("utf-8")
                except Exception:
                    out += b"?"
                i += 2; continue
            out += b"?"; i += 1
        return bytes(out), "GB2312"
    out = bytearray()
    for c in bs:
        if c < 0x80:
            out.append(c)
        else:
            out.append(0xC0 | (c >> 6)); out.append(0x80 | (c & 0x3F))
    return bytes(out), "Latin-1"


# ============================ 测试 ============================
CASES = [
    ("真实:乔维怡", "乔维怡 - 我们好像在哪见过 - QQ群:593039851".encode()),
    ("真实:陈宁、马小郡", "陈宁、马小郡 - 相爱的泪水 (中四版) - QQ群:593039851".encode()),
    ("繁体:張學友", "張學友 - 吻別".encode()),
    ("emoji 混排", "周杰伦 - 晴天 🎵".encode()),
    ("日文假名", "宇多田ヒカル - First Love".encode()),
    ("德文重音", "Rammstein - Mütter".encode()),
    ("俄文", "Мельница - Дорога сна".encode()),
    ("双重编码(真坏)", bytes.fromhex("e5afaea1e5bda1e5bda1")),   # 寮犵幃浼? 那类
]

print("=" * 78)
for name, raw in CASES:
    out, enc = icy_to_utf8(raw)
    same = (out == raw)
    try:
        shown = out.decode("utf-8")
    except Exception:
        shown = repr(out)
    print("%-18s 判定=%-14s 改写=%s" % (name, enc, "否(原样)" if same else "★是(被改了!)"))
    print("    in : %r" % raw.decode("utf-8", "replace"))
    print("    out: %r" % shown)
print("=" * 78)
