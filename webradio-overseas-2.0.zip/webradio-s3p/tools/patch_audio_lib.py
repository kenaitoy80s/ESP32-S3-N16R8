# -*- coding: utf-8 -*-
"""
给第三方音频库 ESP32-audioI2S-nopsram 重打 "HLS(m3u8) 重抓间隔" 补丁 (firmware-side Patch 11)。

【为什么要有这个脚本】
  补丁打在 Arduino/libraries/ 下 —— 库一旦重装/升级就没了(而库一升级, 前面打过的东西全丢)。
  本脚本幂等: 已打过就只提示, 不会重复插入; 未打过就备份 -> 锚点唯一性断言 -> 替换。
  库升级后跑一次即可复原:  python tools/patch_audio_lib.py

【它改了什么】(详见库文件头部 Patch 11 注释)
  上游 Audio::loop() 的 m3u8 分支: 本地分片队列吃空后, 要等【硬编码 1000ms】才重抓 playlist,
  而这 1s 正好落在输入缓冲被抽干的窗口里 -> 直播每隔一个 #EXT-X-TARGETDURATION(常见 10s)卡一下。
  ① remaintime = 1000        -> 可调宏 M3U8_REFRESH_MS   (默认 250ms)
  ② 队列刚吃空时的起算时刻   -> 缓冲见底(<M3U8_STARVED_BYTES)就按 M3U8_STARVED_MS(默认 100ms)
                                起算, 不再干等"预测的下一个分片边界"
  三个宏都可用工程侧 build_opt.h / -D 覆盖。
  ★改宏值后 arduino-cli 不会重编库对象 -> 必须手删 build 目录里
    libraries/ESP32-audioI2S-nopsram/Audio_nopsram.cpp.o 再编译(本脚本末尾会提醒)。

用法:
  python tools/patch_audio_lib.py                 # 用默认库路径
  python tools/patch_audio_lib.py --lib <路径>    # 指定库目录(指到 src 或库根都行)
"""
import argparse
import os
import shutil
import sys

DEFAULT_LIB = r"C:\Users\hudie\Documents\Arduino\libraries\ESP32-audioI2S-nopsram"
SRC_NAME = "Audio_nopsram.cpp"

# 幂等判据: 出现这个宏就认为已打过补丁
MARKER = "M3U8_REFRESH_MS"

# ---- 补丁 1/4: 头部补丁清单登记(锚点只取到 "Patches 1" 为止, 后面那个是 en-dash, 避开编码坑) ----
HEADER_ANCHOR = "* GCC 14 patches (Patches 1"
HEADER_NEW = """\
*   Patch 11 -- Audio::loop() m3u8 branch : (firmware-side patch, not from upstream)
*     Upstream waits a hard-coded 1000ms before re-fetching the playlist once the
*     locally queued HLS segments are exhausted -- and that wait lands exactly
*     while the input buffer is draining, so a live HLS stream drops out once per
*     #EXT-X-TARGETDURATION (10s on most CN mirrors).
*     The wait is now the tunable M3U8_REFRESH_MS (default 250ms), and it drops to
*     M3U8_STARVED_MS (default 100ms) as soon as the buffer runs low
*     (< M3U8_STARVED_BYTES, default 64KB); that low mark also starts the
*     re-fetch timer early instead of waiting for the predicted segment boundary.
*     All three macros can be overridden from the sketch's build_opt.h.
*     Re-apply after a library update:  python tools/patch_audio_lib.py
*
"""

# ---- 补丁 2/4: 修掉那句已经过时的 "build_opt.h is empty / 该补丁未启用" 说明 ----
STALE_OLD = """\
 *       Currently DISABLED for this firmware (build_opt.h is empty) => macro is 0
 *       and the whole block is inert, i.e. exact upstream behaviour.
"""
STALE_NEW = """\
 *       Enabled for this firmware via build_opt.h (-DAUDIO_MIN_BUFFER_BYTES=32768);
 *       the default stays 0, so other sketches linking this library are unaffected.
"""

# ---- 补丁 3/4: 宏定义块 + 队列吃空时的起算时刻 ----
LOOP_ANCHOR = "void Audio::loop() {\n"
MACROS = """\
//---------------------------------------------------------------------------------------------------------------------
// ★ [firmware-side patch 11] HLS(m3u8) 重抓间隔 —— 治 "每 targetDuration 卡一下"
// ----------------------------------------------------------------------------
// 上游行为: 本地分片队列吃空(= 分片全播完, 输入缓冲正被抽干)后, 库要等【1000ms】才重抓
//   playlist; 新分片到手前进不了数据 -> 周期性空隙(周期 ≈ #EXT-X-TARGETDURATION)。
// 本补丁: ① 那次干等 -> 可调 M3U8_REFRESH_MS(默认 250ms);
//         ② 缓冲"见底"时按 M3U8_STARVED_MS(默认 100ms)更快轮询, 并且【队列刚吃空就】
//            按小间隔起算, 不再干等上游那个"预测的分片边界"(那正是空隙的主要来源)。
//   三个宏都可在工程侧 build_opt.h / -D 覆盖。playlist 只有几百字节, 重抓变密几乎不耗带宽。
// ★改宏值后 arduino-cli 不会重编本文件 -> 手删 build 目录下
//   libraries/ESP32-audioI2S-nopsram/Audio_nopsram.cpp.o 再编译, 否则宏不生效。
//---------------------------------------------------------------------------------------------------------------------
#ifndef M3U8_REFRESH_MS
#define M3U8_REFRESH_MS     250
#endif
#ifndef M3U8_STARVED_MS
#define M3U8_STARVED_MS     100
#endif
#ifndef M3U8_STARVED_BYTES
#define M3U8_STARVED_BYTES  (64 * 1024)
#endif

"""

SITE1_OLD = """\
                else {
                    f_noNewHost = true;
                    timestamp2 = millis() + remaintime;
                    setDatamode(AUDIO_DATA); //fake datamode, we have no new audiosequence yet, so let audio run
                }
"""
SITE1_NEW = """\
                else {
                    f_noNewHost = true;
                    // [patch 11] 上游用"预测的下一分片边界"(≈targetDuration)起算 -> 缓冲已见底也
                    // 要干等将近一个分片周期。缓冲见底就按小间隔起算, 尽早重抓; 缓冲充足时保持上游行为。
                    if(InBuff.bufferFilled() < (uint32_t)M3U8_STARVED_BYTES) timestamp2 = millis() + (int32_t)M3U8_STARVED_MS;
                    else                                                     timestamp2 = millis() + remaintime;
                    setDatamode(AUDIO_DATA); //fake datamode, we have no new audiosequence yet, so let audio run
                }
"""

SITE2_OLD = """\
                if(f_noNewHost){
                    m_f_continue = false;
                    if(timestamp2 < millis()) {
                        httpPrint(m_lastHost);
                        remaintime = 1000;
                    }
                }
"""
SITE2_NEW = """\
                if(f_noNewHost){
                    m_f_continue = false;
                    if(timestamp2 < millis()) {
                        httpPrint(m_lastHost);
                        // [patch 11] 上游此处是 remaintime = 1000; (见文件上方 M3U8_* 说明)
                        remaintime = (InBuff.bufferFilled() < (uint32_t)M3U8_STARVED_BYTES)
                                     ? (int32_t)M3U8_STARVED_MS : (int32_t)M3U8_REFRESH_MS;
                    }
                }
"""


def find_src(lib):
    cand = os.path.join(lib, "src", SRC_NAME)
    if os.path.exists(cand):
        return cand
    cand = os.path.join(lib, SRC_NAME)
    if os.path.exists(cand):
        return cand
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lib", default=DEFAULT_LIB, help="ESP32-audioI2S-nopsram 库目录")
    ap.add_argument("--force", action="store_true", help="已打过也强行重打(先删标记块)")
    args = ap.parse_args()

    src = find_src(args.lib)
    if not src:
        sys.exit("找不到 %s —— 用 --lib 指定库目录(见文件头注释)" % SRC_NAME)

    with open(src, "rb") as f:
        raw = f.read()
    text = raw.decode("utf-8")

    if MARKER in text:
        if not args.force:
            print("[跳过] 已经打过补丁(marker %s 存在): %s" % (MARKER, src))
            print("       要换参数请改工程 build_opt.h, 或 --force 重打。")
            return
        # --force: 先从 .bak_m3u8 还原成干净副本, 再重打一遍(保证结果可复现)
        bak = src + ".bak_m3u8"
        if not os.path.exists(bak):
            sys.exit("--force 需要干净的原始副本 %s, 但它不存在 —— 手工恢复库文件后重跑" % bak)
        shutil.copy2(bak, src)
        with open(src, "rb") as f:
            raw = f.read()
        text = raw.decode("utf-8")
        print("[还原] 已从 %s 还原" % bak)
    if b"\r\n" in raw or b"\r" in raw:
        sys.exit("库文件含 CR —— 本脚本只处理 LF 换行的库文件, 请先确认库来源")

    # 1) 备份(只备份一次, 保留最原始的干净副本)
    bak = src + ".bak_m3u8"
    if not os.path.exists(bak):
        shutil.copy2(src, bak)
        print("[备份] %s" % bak)
    else:
        print("[备份] 已存在, 保留原副本: %s" % bak)

    # 2) 逐条锚点替换(每条断言唯一, 避免误替换)
    pairs = [
        ("header", HEADER_ANCHOR, HEADER_NEW + HEADER_ANCHOR),
        ("stale ", STALE_OLD, STALE_NEW),
        ("macro ", LOOP_ANCHOR, MACROS + LOOP_ANCHOR),
        ("site1 ", SITE1_OLD, SITE1_NEW),
        ("site2 ", SITE2_OLD, SITE2_NEW),
    ]
    for tag, old, new in pairs:
        n = text.count(old)
        if n != 1:
            sys.exit("[失败] 锚点 %s 命中 %d 次(应为 1 次) —— 库版本可能变了, 请重新核对这个位置" % (tag, n))
        text = text.replace(old, new)
        print("[打补丁] %s ok" % tag)

    out = text.encode("utf-8")
    if b"\r" in out:
        sys.exit("[失败] 结果里出现了 CR, 已放弃写入")
    with open(src, "wb") as f:
        f.write(out)
    print("[完成] %s  (%d -> %d 字节)" % (src, len(raw), len(out)))
    print()
    print("★下一步: 删掉 build 目录里的库对象强制重编(否则宏/改动可能不生效):")
    print("   del \"<build-path>\\libraries\\ESP32-audioI2S-nopsram\\Audio_nopsram.cpp.o\"")
    print("   del \"<build-path>\\libraries\\ESP32-audioI2S-nopsram\\Audio_nopsram.cpp.d\"")


if __name__ == "__main__":
    main()
