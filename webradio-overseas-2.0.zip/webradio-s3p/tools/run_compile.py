import os
import subprocess
import sys

# ============================================================================
# ESP32-S3 N16R8 编译助手 —— 【webradio-s3p】(网络收音机, 三屏 ST7567/SSD1306/ST7789)
#   用法: python run_compile.py
#
# ★★ build-path 必须本工程独享 ★★
#   本机有多个 ESP32 工程并存, 共用一个 build 目录会串缓存, 表现是
#   "改了代码却没重编"或"编出旧固件"; run_upload.py 的 build 归属自检也会拦下来。
#
# ★★ 起播预缓冲(保障"起播流畅")改 sketch 目录的 build_opt.h, 别动本脚本命令行 ★★
#   ESP32-audioI2S-nopsram 库的起播预缓冲由编译期宏 AUDIO_MIN_BUFFER_BYTES 控制
#   (库内 #ifndef 默认 0 = 关闭, 攒到一帧就出声 -> 换台后先卡十几秒才流畅)。
#   arduino-esp32 core 的 platform.txt 有官方 prebuild hook:
#     if exist "{source}\build_opt.h" COPY /y ... "{build.path}\build_opt.h"
#   再以 @build_opt.h 响应文件传给 gcc => sketch 目录的 build_opt.h 对 sketch 和所有库都生效,
#   且 Arduino IDE 与 arduino-cli 两种编译方式走同一 hook。★要改预缓冲值, 就改 sketch 里的 build_opt.h。
# ============================================================================

# ---- 工具链定位 ----
#   ★2026-10-27: 全部候选路径抽到 toolchain_paths.py(与 run_upload.py 共用一份),
#   顺序 = 环境变量 > 迁移包内自带 toolchain/ > 本机 %TEMP% 的 ASCII 副本 > 历史路径。
#   ⇒ 工程连同迁移包拷到另一台电脑后, 直接命中包内工具链, 不用改任何路径;
#     本机则仍然命中 %TEMP% 那份(行为与以前完全一致)。
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from toolchain_paths import resolve, describe, build_base, path_len_problem

cli, _data, _libs = resolve()
describe(cli, _data, _libs)
if not cli:
    print("✗ 找不到 arduino-cli.exe —— 设环境变量 ARDUINO_CLI 指向它, "
          "或确认迁移包里的 tc\\arduino-cli.exe 还在")
    sys.exit(1)
# ★路径长度检查: 撞 Windows MAX_PATH(259) 时会报"bits/cpu_defines.h 找不到", 极易误判
_len_err = path_len_problem(_data)
if _len_err:
    print(_len_err)
    sys.exit(1)
# ---- 数据目录 / 库目录必须走 ASCII 路径 ----
#   ★中文路径会让链接器 ld.exe 找不到 -lcore/-lmbedtls/-lgcc 等预编译库 -> 链接失败。
if not _data or not _libs:
    print("✗ 未找到工具链数据目录或库目录(见上面三行)")
    print("  本机: 应存在 <TEMP>\\tyio_data\\arduino15 与 <TEMP>\\tyio_libs")
    print("  迁移包: 应存在 <工程>\\..\\toolchain\\arduino15 与 ...\\toolchain\\libraries")
    sys.exit(1)
os.environ["ARDUINO_DIRECTORIES_DATA"] = _data
os.environ["ARDUINO_DIRECTORIES_USER"] = _libs

# ★sketch 路径 = 本工程实际所在(自 esp32项目 工作区内; 旧脚本写死的
#   C:\Users\hudie\Desktop\webradio-s3p 已不存在 —— 工程已挪进本工作区)。
#   ★★2026-10-27: 不能再直接拿"工程所在目录"去编译 ★★
#     Arduino 硬规则 = 主 .ino 名必须等于文件夹名。本工程文件夹叫
#     webradio-s3p-4screen-mainline-v1.16(v1.16 改名, 名字里带版本号), 而主文件是
#     webradio-s3p.ino -> arduino-cli 直接报 "main file missing from sketch" 编不了。
#     sketch_paths.py 会在 %TEMP%\wrb_s3p_sk\ 下建一个名为 webradio-s3p 的 junction
#     指回本工程, 编译用它 -> 产物名仍是 webradio-s3p.ino.bin, 工具链其余部分不变。
#     (位置/改名跟随、ASCII 路径、只此一份源码, 三件事都由该模块保证。)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sketch_paths import ROOT as sketch_root, sketch_target
sketch = sketch_target()
# ★2026-10-27: 产物目录也走 build_base() —— 本机仍是 %TEMP%\wrb_s3p(与 run_upload.py
#   及 flash_full.cmd 记的位置完全一致); 只有 %TEMP% 含中文时才会换到 ASCII 目录。
BUILD  = build_base("wrb_s3p")
print("工程目录:", sketch_root)
print("编译目标:", sketch)

args = [cli, "compile",
        # ★FlashMode 必须是 dio, 不能是 qio ★
        #   原因: N16R8 的 8MB PSRAM 是 Octal(OPI)。选 bootloader 用的是
        #   bootloader_{build.boot}_{boot_freq}.elf(platform.txt), 而 build.boot 只由 FlashMode 决定。
        #   PSRAM=opi 只改 build.psram_type(决定应用侧用 qio_opi 还是 qio_qspi 那套预编译库),
        #   完全不影响 bootloader —— 于是 FlashMode=qio 时会拿到按 QUAD 初始化 PSRAM 的 bootloader,
        #   结果 psramSize=0: 背景图 150KB 分配不出来, 音频的 512KB 输入缓冲也静默退回 DRAM 的 16KB。
        #   改成 dio 后 memory_type=dio_opi + bootloader_dio_80m.elf, PSRAM 正常。
        #   (两者 flash_mode 都是 dio, 所以实际烧录的 flash 读取模式没变, 风险很低。)
        "--fqbn", "esp32:esp32:esp32s3:PartitionScheme=custom,PSRAM=opi,FlashMode=dio,FlashSize=16M,USBMode=hwcdc,CDCOnBoot=cdc",
        "--build-path", BUILD,
        sketch]

# ★★ 库发现(library discovery) —— 结论: 就老实做, 别跳过(2026-10-08 二次踩坑后定) ★★
#   arduino-cli 要对【每个库的每个源文件】跑一次预处理来建依赖表, 听起来很慢, 但本机实测
#   "完整检测 + 全量编库 + 链接" 总共只要 ~2.5 分钟 —— 完全在可接受范围, 不要为了省它冒险。
#
#   ⚠⚠ 反面教材: `--skip-libraries-discovery`(跳过库发现)【会留下 0 个库对象】。
#     实测: 用它之后 <build>/libraries/ 下的 .o 被清空, 于是链接阶段报一大片
#     `undefined reference`(WiFiAPClass::softAPdisconnect / Preferences::putString /
#     DNSServer::start / AsyncUDP::~AsyncUDP ...), 构建失败。
#     即使编译产物(build.options.json)还在、sketch 的 .o 也齐全, 也救不回来。
#     ⇒ **只要用了跳过, 就必须完整编一次库**; 那还不如一开始就别跳。
#
#   因此现行策略: **默认完整检测**; 只有显式 `--fast` 且 build 目录里确实存在库对象时,
#   才允许跳过(用于"库对象都在、只想快速重编 sketch"的场景)。--no-fast 可强制完整。
def _count_lib_objs():
    """数一数 build 目录里已存在的库目标文件数量。"""
    libs = os.path.join(BUILD, "libraries")
    n = 0
    for _r, _d, _fs in os.walk(libs):
        n += sum(1 for f in _fs if f.endswith(".o"))
    return n


_lib_objs = _count_lib_objs()
_want_fast = ("--fast" in sys.argv) and ("--no-fast" not in sys.argv)
_fast = _want_fast and _lib_objs > 0
if _want_fast and _lib_objs == 0:
    print("⚠ 指定了 --fast, 但 build 目录里没有库 .o —— 跳过库发现会让链接报一堆 "
          "undefined reference, 已自动改为完整检测。")
if _fast:
    args.insert(2, "--skip-libraries-discovery")
print("库发现: %s" % ("跳过(显式 --fast, 且已有 %d 个库对象可复用)" % _lib_objs
                     if _fast else
                     "完整检测(默认; 全量约 2~3 分钟, 保证库列表与库对象都正确)"))

print("编译中(首次为全量, 可能数分钟)... 预缓冲由 sketch/build_opt.h 提供")
# ★输出【实时写日志文件】而不是 capture_output 攒到最后:
#   之前用 capture_output=True, 一旦编译卡住就什么线索都拿不到(日志只在结束时才写),
#   只能靠翻 build 目录猜卡在哪。改成直接重定向到文件后, 随时 tail 就能看到进度。
LOGF = BUILD + "_compile.log"
with open(LOGF, "w", encoding="utf-8", errors="replace") as _lf:
    p = subprocess.run(args, stdout=_lf, stderr=subprocess.STDOUT, text=True, timeout=2400)
print("EXIT", p.returncode, "| 完整日志:", LOGF)
out = open(LOGF, encoding="utf-8", errors="replace").read()
for ln in out.splitlines():
    if "bytes" in ln or "Sketch uses" in ln or "Global variables" in ln or "字节" in ln:
        print("SIZE>", ln)
for ln in out.splitlines()[-40:]:
    print(ln)

# Preserve the Arduino CLI result so wrappers and automation can detect failure.
sys.exit(p.returncode)
