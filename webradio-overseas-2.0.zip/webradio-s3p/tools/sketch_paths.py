# -*- coding: utf-8 -*-
"""
sketch 路径解析（run_compile.py / run_upload.py 共用，唯一权威）

★★ 为什么需要这个模块 ★★
Arduino 有一条硬规则：**主 .ino 文件名必须与所在文件夹同名**，否则
    arduino-cli compile 立刻报 "main file missing from sketch: <目录>\\<目录名>.ino"
一个字符都不会编。

本工程的主文件是 `webradio-s3p.ino`，但工程文件夹 2026-10 被改名成了
`webradio-s3p-4screen-mainline-v1.16`（名字里还带版本号）—— 于是名字对不上，
编译直接失败。而且文件夹名带版本号，以后每次发版重命名都会再撞一次，
所以【不能靠"把 .ino 改名成跟文件夹一致"】来修。

做法：在 %TEMP%\\wrb_s3p_sk\\ 下建一个名为 `webradio-s3p` 的
**目录联接(junction)** 指向工程根目录，编译目标用这个联接路径。对 arduino-cli
而言 sketch 就叫 webradio-s3p，源码仍然只有一份（没有拷贝、不会改错地方），
产物名保持 `webradio-s3p.ino.bin` —— 与 make_full_bin.py / run_upload.py /
flash_full.cmd 里写死的分段文件名完全一致，工具链其余部分一行都不用动。

为什么用 junction 而不是符号链接：junction 不需要管理员权限、不需要开发者模式，
普通用户双击 .cmd 就能建。
"""

import os
import subprocess

# 工程根目录（本文件在 <root>/tools/ 下）
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Arduino 认定的 sketch 名（= 主 .ino 主文件名，也是编译产物前缀）
SKETCH_NAME = "webradio-s3p"
MAIN_INO = SKETCH_NAME + ".ino"

_TMP = os.environ.get("TEMP", r"C:\Users\hudie\AppData\Local\Temp")
_LINK_DIR = os.path.join(_TMP, "wrb_s3p_sk")
SKETCH_LINK = os.path.join(_LINK_DIR, SKETCH_NAME)


def _same_target(link):
    """判断已有联接是否就指向本工程（用主 .ino 的 samefile 判定，最稳）。"""
    try:
        return os.path.samefile(os.path.join(link, MAIN_INO),
                                os.path.join(ROOT, MAIN_INO))
    except OSError:
        return False


def _make_junction():
    os.makedirs(_LINK_DIR, exist_ok=True)
    if os.path.exists(SKETCH_LINK):
        # 指向别处（另一个工程）—— 先删联接本身，绝不删目标内容
        try:
            os.rmdir(SKETCH_LINK)        # 对 junction 而言 rmdir 只摘链接
        except OSError:
            pass
    # ★必须用 shell=True 走 cmd：mklink 是 cmd 内建命令
    cmd = 'mklink /J "%s" "%s"' % (SKETCH_LINK, ROOT)
    r = subprocess.run(cmd, shell=True, capture_output=True,
                      text=True, encoding="gbk", errors="replace")
    if not os.path.isdir(SKETCH_LINK):
        raise RuntimeError(
            "无法创建目录联接(junction)：\n  命令: %s\n  输出: %s %s\n"
            "  可手工执行上面这条命令，或把工程文件夹改名成 %s。"
            % (cmd, (r.stdout or "").strip(), (r.stderr or "").strip(), SKETCH_NAME))


def sketch_target():
    """返回应该交给 arduino-cli 的 sketch 目录路径。

    - 文件夹名本来就对 -> 直接用真实目录（不做任何多余动作）；
    - 否则 -> 返回 %TEMP% 下的 junction 路径。
    """
    if (os.path.basename(ROOT) == SKETCH_NAME
            and os.path.isfile(os.path.join(ROOT, MAIN_INO))):
        return ROOT
    if not _same_target(SKETCH_LINK):
        _make_junction()
    return SKETCH_LINK


if __name__ == "__main__":
    # 自检：python tools/sketch_paths.py
    print("工程根目录 :", ROOT)
    print("主文件存在 :", os.path.isfile(os.path.join(ROOT, MAIN_INO)))
    t = sketch_target()
    print("编译目标   :", t)
    print("目标里有主文件:", os.path.isfile(os.path.join(t, MAIN_INO)))
