#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
抓 ICY 元数据的【原始字节】—— 用于诊断屏幕/后台乱码。
连上电台流(带 Icy-MetaData: 1), 读出 icy-metaint, 然后每跨过 metaint 字节音频
就读一块元数据, 把 StreamTitle 的【原始字节】按 hex + 多种编码试解打印出来。

这样就绕开了固件里的任何判别逻辑, 看到的是上游真正发来的东西。
"""
import socket
import sys
import time

host, port, path = sys.argv[1], int(sys.argv[2]), sys.argv[3]
NBLOCKS = int(sys.argv[4]) if len(sys.argv) > 4 else 4


def recv_until(sock, buf, marker, limit=64 * 1024):
    while marker not in buf:
        chunk = sock.recv(4096)
        if not chunk:
            raise RuntimeError("连接被关闭(读响应头时)")
        buf += chunk
        if len(buf) > limit:
            raise RuntimeError("响应头过长")
    i = buf.index(marker)
    return buf[:i + len(marker)], buf[i + len(marker):]


def recv_exact(sock, buf, n):
    while len(buf) < n:
        chunk = sock.recv(max(4096, n - len(buf)))
        if not chunk:
            raise RuntimeError("连接被关闭(读音频/元数据时)")
        buf += chunk
    return buf[:n], buf[n:]


def show(raw: bytes, label: str):
    print("  %s 原始 hex : %s" % (label, raw.hex(" ")))
    for enc in ("utf-8", "gbk", "latin-1"):
        try:
            print("  %s 按 %-8s: %r" % (" " * len(label), enc, raw.decode(enc)))
        except Exception as e:
            print("  %s 按 %-8s: <失败 %s>" % (" " * len(label), enc, e))


def main():
    s = socket.create_connection((host, port), timeout=10)
    s.settimeout(10)
    req = ("GET %s HTTP/1.0\r\nHost: %s:%d\r\n"
           "Icy-MetaData: 1\r\nUser-Agent: probe\r\nAccept: */*\r\n\r\n"
           % (path, host, port))
    s.sendall(req.encode())
    hdr, rest = recv_until(s, b"", b"\r\n\r\n")
    text = hdr.decode("latin-1")
    print("=== 响应头 ===")
    for ln in text.split("\r\n"):
        if ln:
            print("  " + ln)

    metaint = None
    for ln in text.split("\r\n"):
        if ln.lower().startswith("icy-metaint:"):
            metaint = int(ln.split(":", 1)[1].strip())
    if not metaint:
        print("!! 该流没有 icy-metaint(不带元数据)")
        return
    print("\nicy-metaint = %d (每 %d 字节音频后跟 1 字节长度 + 元数据)" % (metaint, metaint))

    buf = rest
    seen = set()
    for k in range(NBLOCKS):
        audio, buf = recv_exact(s, buf, metaint)      # 丢掉音频
        lb, buf = recv_exact(s, buf, 1)
        mlen = lb[0] * 16
        if mlen:
            meta, buf = recv_exact(s, buf, mlen)
        else:
            meta = b""
        print("\n=== 第 %d 块元数据 (len=%d) ===" % (k + 1, mlen))
        if not meta:
            print("  (空, 说明这段没换曲)")
            continue
        show(meta, "整块")
        a = meta.find(b"StreamTitle='")
        if a >= 0:
            b = meta.find(b"'", a + 13)
            if b > a:
                t = meta[a + 13:b]
                if t in seen:
                    print("  -> StreamTitle 同上一条, 跳过")
                    continue
                seen.add(t)
                print("  -> StreamTitle 原始字节:")
                show(t, "title")
        time.sleep(0.2)
    s.close()


main()
