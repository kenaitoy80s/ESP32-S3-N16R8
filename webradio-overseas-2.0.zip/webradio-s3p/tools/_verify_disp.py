# -*- coding: utf-8 -*-
"""
显示设置【持久化】端到端验证(2026-10-16 为查"配色重启就消失"而写, 可复用)。

做什么:
  1) 读 /api/state 拿基线(ver / ecol / bg);
  2) 用原生 WebSocket 发一条 disp= (8 段: 屏型||对比度||旋转||背光超时||亮度||反显||元素色CSV||背景色);
  3) 再读 /api/state, 确认【RAM 里已变】(说明指令链路通);
  4) 硬复位(esptool read_flash 结束时自带 hard reset);
  5) 复位后再读 /api/state —— 值还在 = ★持久化 OK★; 回到默认 = 落盘失败。
  6) --restore 时把配色还原成"默认卡通": ecol=11,2,3,8,7,3,4,13,6,8,4,13  bg=0。

用法:
  python tools/_verify_disp.py [设备IP] [COM口]
  python tools/_verify_disp.py 192.168.2.115 COM3
  python tools/_verify_disp.py --restore 192.168.2.115 COM3
"""
import os, sys, json, time, socket, subprocess, urllib.request

ARGS = [a for a in sys.argv[1:] if not a.startswith("--")]
RESTORE = "--restore" in sys.argv
IP  = ARGS[0] if len(ARGS) > 0 else "192.168.2.115"
COM = ARGS[1] if len(ARGS) > 1 else "COM3"
ESPTOOL = os.path.join(os.environ.get("LOCALAPPDATA", ""),
                       r"Arduino15\packages\esp32\tools\esptool_py\4.5.1\esptool.exe")

CUSTOM_ECOL = "1,2,3,4,5,6,7,8,9,10,11,12"          # 黑红绿蓝黄青洋红橙浅灰深灰深蓝深绿
CUSTOM_BG   = 6                                       # 深夜蓝
DEFAULT_ECOL = "11,2,3,8,7,3,4,13,6,8,4,13"           # kCartoonElemPal(卡通默认)
DEFAULT_BG   = 0                                      # 淡蓝天空

def state():
    with urllib.request.urlopen("http://%s/api/state" % IP, timeout=6) as r:
        return json.loads(r.read().decode("utf-8", "replace"))

def show(tag, d):
    print("  %-10s ver=%-6s screen=%-2s ctr=%-4s rot=%-3s bl=%-6s brg=%-4s inv=%s"
          % (tag, d.get("ver"), d.get("screen"), d.get("contrast"), d.get("rot"),
             d.get("blTimeout"), d.get("bright"), d.get("inv")))
    print("  %-10s ecol=%s  bg=%s" % ("", d.get("ecol"), d.get("bg")))

def ws_send(sock, text):
    p = text.encode("utf-8"); m = os.urandom(4); n = len(p)
    h = b"\x81"
    if n < 126:    h += bytes([0x80 | n])
    elif n < 65536: h += bytes([0x80 | 126]) + n.to_bytes(2, "big")
    else:          h += bytes([0x80 | 127]) + n.to_bytes(8, "big")
    sock.sendall(h + m + bytes(p[i] ^ m[i % 4] for i in range(n)))

def ws_open():
    s = socket.create_connection((IP, 80), timeout=6)
    key = "dGhlIHNhbXBsZSBub25jZQ=="
    s.sendall(("GET /ws HTTP/1.1\r\nHost: %s\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
               "Sec-WebSocket-Key: %s\r\nSec-WebSocket-Version: 13\r\n\r\n" % (IP, key)).encode())
    buf = b""
    while b"\r\n\r\n" not in buf:
        c = s.recv(512)
        if not c: raise RuntimeError("WS 握手失败")
        buf += c
    if b"101" not in buf.split(b"\r\n")[0]:
        raise RuntimeError("WS 未升级: " + buf[:120].decode("utf-8", "replace"))
    return s

def hard_reset():
    if not os.path.isfile(ESPTOOL):
        print("  (跳过硬复位: 找不到 esptool)"); return
    subprocess.run([ESPTOOL, "--chip", "esp32s3", "--port", COM, "--baud", "460800",
                    "read_flash", "0x0", "0x10", os.path.join(os.environ.get("TEMP", "."), "_rst.bin")],
                   capture_output=True, text=True)

def main():
    print("== 目标 %s (串口 %s) ==" % (IP, COM))
    d0 = state(); print("[1] 复位前基线:"); show("", d0)

    ecol = DEFAULT_ECOL if RESTORE else CUSTOM_ECOL
    bg   = DEFAULT_BG   if RESTORE else CUSTOM_BG
    cmd  = "disp=%s||%s||%s||%s||%s||%s||%s||%s" % (
        d0.get("screen", 3), d0.get("contrast", 120), d0.get("rot", 0),
        d0.get("blTimeout", 0), d0.get("bright", 100), d0.get("inv", 0), ecol, bg)
    print("[2] 下发: %s" % cmd)
    s = ws_open(); ws_send(s, cmd); time.sleep(2.0); s.close()
    time.sleep(1.5)

    d1 = state(); print("[3] 下发后(未复位):"); show("", d1)
    ok_live = (d1.get("ecol") == [int(x) for x in ecol.split(",")]) and (d1.get("bg") == bg)
    print("    -> RAM 生效: %s" % ("OK" if ok_live else "★失败"))

    print("[4] 硬复位(模拟重启)…")
    hard_reset(); time.sleep(9.0)

    d2 = state(); print("[5] 复位后:"); show("", d2)
    ok_persist = (d2.get("ecol") == [int(x) for x in ecol.split(",")]) and (d2.get("bg") == bg)
    print("    -> ★持久化: %s" % ("OK ✅ 重启后依然保留" if ok_persist else "★失败 ❌ 重启后被打回默认"))
    print("[6] 固件版本: %s" % d2.get("ver"))
    return 0 if (ok_live and ok_persist) else 1

if __name__ == "__main__":
    sys.exit(main())
