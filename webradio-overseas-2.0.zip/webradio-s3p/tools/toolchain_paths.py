# -*- coding: utf-8 -*-
"""
工具链定位（run_compile.py / run_upload.py 共用，唯一权威）

★ 为什么要有这个模块 ★
原来两个脚本里各写了一份候选路径，且默认数据目录固定指 %TEMP%\\tyio_data\\arduino15
—— 那是本机的"ASCII 副本"。把工程拷到另一台电脑后这些路径全都不存在，
编译会直接报"未找到 ASCII 工具链/库副本"，于是工程事实上不可移植。
现在改成按优先级自动找，本机原有位置仍然命中（行为零变化），
迁移包里则直接命中【包内自带工具链】，解压即用。

优先级（高 → 低）:
  1) 环境变量         ARDUINO_CLI / ARDUINO_DIRECTORIES_DATA / ARDUINO_DIRECTORIES_USER
  2) 迁移包布局       <工程>/../toolchain/{arduino-cli.exe, arduino15, libraries}
                      也兼容 <工程>/toolchain/...
  3) 本机老位置       %TEMP%/tyio_data/arduino15  +  %TEMP%/tyio_libs
  4) 历史候选         Arduino IDE 自带 cli / D 盘几个迁移包

★★ 中文路径必须避开 ★★
数据目录/库目录一旦落在含中文的路径里，链接器 ld.exe 会找不到 -lcore、-lmbedtls
这类预编译库（报一堆 undefined reference，看起来像库缺失，其实是路径问题）。
所以同优先级的多个候选里，**先挑路径纯 ASCII 的那一个**。
"""

import os
import string

# 工程根目录（本文件在 <root>/tools/ 下）
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

_ASCII = set(string.printable)


def is_ascii(path):
    """路径是否纯 ASCII（不含中文/全角符号等）。"""
    try:
        path.encode("ascii")
        return True
    except (UnicodeEncodeError, AttributeError):
        return False


def _parents_toolchain():
    """迁移包布局里的 toolchain 目录候选。

    ★★ 目录名必须【短】★★（2026-10-27 实测的血案）
    GCC 的 C++ 标准库搜索目录带 `..` 未规范化，拼上 `\\bits\\cpu_defines.h` 后在本机实测
    **刚好 260 字符**（Windows MAX_PATH 上限 259）→ 报 `bits/cpu_defines.h: No such file
    or directory`。看起来像"工具链少文件"，其实是路径太长。所以包里的工具链目录只叫 `tc`，
    包文件夹名也短（wrb-s3p-v116-mig）。详见 toolchain_paths.py 文件头的长度预算说明。
    """
    # This Dell keeps the verified toolchain in the sibling workspace
    # C:\Users\dell\Documents\Codex\w\tc rather than inside the project.
    # Resolve it relative to the project parent so the compile script uses the
    # same Core 3.3.11 inventory as verify_standard_env.ps1.
    out = [os.path.join(os.path.dirname(os.path.dirname(ROOT)), "w", "tc")]
    for tkname in ("tc", "toolchain"):
        out.append(os.path.join(ROOT, tkname))
        out.append(os.path.join(os.path.dirname(ROOT), tkname))
    return out


def _first_file(cands):
    for c in cands:
        if c and os.path.isfile(c):
            return c
    return None


def _first_dir(cands):
    """先在所有"存在"的候选里挑纯 ASCII 路径的，没有再退回第一个存在的。"""
    exist = [c for c in cands if c and os.path.isdir(c)]
    return next((c for c in exist if is_ascii(c)), (exist[0] if exist else None))


def _temp():
    return os.environ.get("TEMP") or os.environ.get("TMP") or r"C:\Windows\Temp"


def resolve():
    """返回 (cli, data, libs)。找不到的项为 None。"""
    tk = _parents_toolchain()

    cli = _first_file(
        [os.environ.get("ARDUINO_CLI", "")]
        + [os.path.join(t, "arduino-cli.exe") for t in tk]
        + [
            r"C:\Users\hudie\AppData\Local\Programs\Arduino IDE\resources\app\lib\backend\resources\arduino-cli.exe",
            r"D:\esp32项目\F-工具链与安装包\esp32-webradio-toolchain\arduino-cli.exe",
            r"D:\esp32项目\04-工具与环境\web-radio-4m-迁移包-20260927\arduino-cli\arduino-cli.exe",
            r"D:\esp32项目\04-工具与环境\web-radio-4m-迁移包-20260927\Arduino-IDE\resources\app\lib\backend\resources\arduino-cli.exe",
            r"D:\ESP32\web-radio-4m-迁移包-20260927\arduino-cli\arduino-cli.exe",
        ])

    data = _first_dir(
        [os.environ.get("ARDUINO_DIRECTORIES_DATA", "")]
        + [os.path.join(t, "arduino15") for t in tk]
        + [os.path.join(_temp(), "tyio_data", "arduino15")])

    # ★注意: ARDUINO_DIRECTORIES_USER 要的是"用户目录"(Arduino 那种 <用户>\Documents\Arduino),
    #   真正的库在它的 libraries\ 子目录里。原机器 _libs=%TEMP%\tyio_libs 就是这种结构
    #   (库在 %TEMP%\tyio_libs\libraries\...)。迁移包里同理: tc\user\libraries\...
    #   —— 直接把库目录本身当 USER 会报 "U8g2lib.h: No such file or directory"。
    libs = _first_dir(
        [os.environ.get("ARDUINO_DIRECTORIES_USER", "")]
        + [os.path.join(os.path.dirname(ROOT), "vendor")]
        + [os.path.join(t, "user") for t in tk]
        + [os.path.join(_temp(), "tyio_libs")])

    return cli, data, libs


def build_base(leaf):
    """编译产物目录。★同样必须避开中文路径（.o / .elf 路径会传给 ld）。

    本机 %TEMP% 是纯 ASCII -> 与原来写死的位置完全一致，行为不变；
    新机器若用户名是中文，则退到 C:\\wrb_s3p_env\\<leaf>，并自动建好。
    """
    tmp = _temp()
    base = tmp if is_ascii(tmp) else r"C:\wrb_s3p_env"
    path = os.path.join(base, leaf)
    os.makedirs(path, exist_ok=True)
    return path


def path_len_problem(data):
    """检查工具链路径是否会撞 Windows MAX_PATH(259) —— 撞了返回提示字符串。

    ★这是 2026-10-27 实测踩到的坑: GCC 报
        include/c++/14.2.0/xtensa-esp-elf/esp32s3/no-rtti/bits/c++config.h:683:10:
        fatal error: bits/cpu_defines.h: No such file or directory
      但那个文件明明在硬盘上。原因是 GCC 内部用**带 `..` 的未规范化路径**去拼头文件路径，
      实测拼出 260 字符 -> 超过 MAX_PATH -> 系统直接回"找不到"。
      看起来像工具链缺文件 / 库没装全, 极容易误判成重装工具链。
      ⇒ 工具链目录必须放在短路径下; 这条检查会在编译前把话说清楚。
    """
    if not data:
        return None
    tools = os.path.join(data, "packages", "esp32", "tools", "esp-x32")
    ver = "2601"
    if os.path.isdir(tools):
        subs = sorted(d for d in os.listdir(tools)
                      if os.path.isdir(os.path.join(tools, d)))
        if subs:
            ver = subs[0]
    worst = (os.path.join(tools, ver)
             + r"\lib\gcc\..\..\lib\gcc\xtensa-esp-elf\14.2.0\..\..\..\.."
               r"\xtensa-esp-elf\include\c++\14.2.0\xtensa-esp-elf\esp32s3\no-rtti"
               r"\bits\cpu_defines.h")
    n = len(worst)
    if n > 259:
        return ("✗ 工具链路径过长（%d 字符 > Windows 上限 259）\n"
                "    编译会报 bits/cpu_defines.h: No such file or directory —— 看着像丢文件，\n"
                "    其实是 MAX_PATH 溢出。请把整个迁移包移到更短的路径（至少要再短 %d 个字符，\n"
                "    例：D:\\wrb\\），或把工具链复制到 %TEMP% 这类短路径。\n"
                "    当前检测用的最长路径：%s" % (n, n - 259, worst))
    return None


def describe(cli, data, libs):
    """打印实际用到的工具链（排查"为什么编出来的东西不对"时先看这三行）。"""
    print("arduino-cli :", cli or "✗ 未找到")
    print("数据目录    :", data or "✗ 未找到", "" if data and is_ascii(data) else "  ⚠ 含非 ASCII 字符")
    print("库目录      :", libs or "✗ 未找到", "" if libs and is_ascii(libs) else "  ⚠ 含非 ASCII 字符")
    # ★库目录必须是"用户目录"(下面有 libraries\)。少了这一层 -> 所有库都找不到,
    #   报 U8g2lib.h / ArduinoJson.h 之类 No such file or directory, 极像"库没装"。
    if libs and not os.path.isdir(os.path.join(libs, "libraries")):
        print("  ⚠ 该目录下没有 libraries\\ 子目录 —— 层级不对, 库会全部找不到。")
        print("    ARDUINO_DIRECTORIES_USER 要的是【用户目录】, 库里放 <用户目录>\\libraries\\<库>。")


if __name__ == "__main__":
    c, d, l = resolve()
    describe(c, d, l)
    print("编译产物目录:", build_base("wrb_s3p"))
