/* 本地 SD 卡播放 —— 2026-10-07 阶段②
 * 独立成一个资源(与 bg.js/wifi.js 同理): app.js 的 gzip 已逼近单次响应安全水位, 绝不往里塞。
 * 设备端走 SD_MMC 1-bit(CLK/CMD/D0 三根线), 平铺扫描卡根目录的音频文件, 按顺序播放。
 *
 * ★为什么全部用 HTTP 而不用 WebSocket:
 *   与 /api/wifi /api/sleep 等一致 —— 设备处于 AP 热点(无外网)时, 手机的 WebSocket 常被
 *   captive portal 掐断或自动改走蜂窝数据, 表现为"页面打得开、按钮点了没反应"。
 *   HTTP 与页面同源同机制, 跨设备一致可靠。代价只是多几百字节请求, 可以忽略。
 */
(function () {
  'use strict';
  var box = document.getElementById('sdbox');
  if (!box) return;

  box.innerHTML =
    '<div class="card"><h1>本地 SD 卡播放</h1>' +
    '<div class="sub" id="sdstat">正在读取设备状态…</div>' +
    '<div class="row" style="margin-top:8px;flex-wrap:wrap;gap:8px">' +
    '<button class="btn" id="sdScan">重新扫描卡</button>' +
    '<button class="btn sec" id="sdExit" style="display:none">回到网络电台</button>' +
    '<button class="btn sm" id="sdToggle">切回电台 / 切到SD</button>' +
    '<button class="btn sm" id="sdPrev">上一首</button>' +
    '<button class="btn sm" id="sdNext">下一首</button>' +
    '</div>' +
    '</div>' +
    '<div class="card"><h1>卡内文件(<span id="sdcnt">0</span>)</h1>' +
    '<div id="sdlist" style="margin-top:8px">—</div></div>';

  var el = function (id) { return document.getElementById(id); };
  var timer = null;   // 轮询句柄(只在"扫描中"期间开启, 拿到结果即停)

  function esc(s) {
    // 文件名来自 SD 卡, 不可信 -> 必须转义后再插进 innerHTML
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function kb(b) { return b >= 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB'; }

  function render(j) {
    var st = el('sdstat');
    if (!j.mounted) {
      st.innerHTML = '<b style="color:#c0392b">SD 卡未挂载</b> —— 请检查接线与 FAT32 格式(串口 H 可看详细日志)';
      el('sdcnt').textContent = '0';
      el('sdlist').innerHTML = '<div class="hint">没有可列出的文件。</div>';
      return;
    }
    if (j.count === 0) {
      st.textContent = '卡已挂载, 但没有找到音频文件(根目录平铺扫描, 不进子目录)';
      el('sdcnt').textContent = '0';
      el('sdlist').innerHTML = '<div class="hint">把 mp3 等文件放到卡根目录后再点"重新扫描卡"。</div>';
      return;
    }
    st.innerHTML = '已挂载, 共 <b>' + j.count + '</b> 个音频文件' +
      (j.playing ? ' ｜ 当前播放: <b>' + esc(j.name) + '</b>' : '');
    el('sdExit').style.display = j.playing ? '' : 'none';
    el('sdcnt').textContent = j.count;

    var h = '<table><thead><tr><th>#</th><th>文件名</th><th>大小</th><th>操作</th></tr></thead><tbody>';
    for (var i = 0; i < j.files.length; i++) {
      var f = j.files[i];
      var cur = (j.playing && f.i === j.cur);
      h += '<tr' + (cur ? ' style="background:#eef7ee"' : '') + '>' +
        '<td>' + (f.i + 1) + (cur ? ' ▶' : '') + '</td>' +
        '<td>' + esc(f.n) + '</td>' +
        '<td>' + kb(f.sz) + '</td>' +
        '<td><button class="btn sm" data-i="' + f.i + '">播放</button></td></tr>';
    }
    h += '</tbody></table>';
    el('sdlist').innerHTML = h;

    // 事件委托: 一次绑定处理所有"播放"按钮(列表会整体重绘, 逐个绑定会漏)
    var tb = el('sdlist').querySelector('tbody');
    if (tb) tb.onclick = function (e) {
      var b = e.target.closest ? e.target.closest('button[data-i]') : null;
      if (!b) return;
      play(+b.getAttribute('data-i'));
    };
  }

  function poll() {
    fetch('/api/sd/list').then(function (r) { return r.json(); }).then(function (j) {
      // 首次(或点过扫描)时列表还是空的 -> 自动请求扫描一次
      if (j.scanning) {
        fetch('/api/sd/scan', { method: 'POST' });
        if (!timer) timer = setInterval(poll, 1200);   // 扫描期间轮询, 拿到结果就停
        return;
      }
      if (timer) { clearInterval(timer); timer = null; }
      render(j);
    }).catch(function () {
      if (timer) { clearInterval(timer); timer = null; }
      el('sdstat').innerHTML = '<b style="color:#c0392b">读不到设备状态, 请按 Ctrl+Shift+R 强制刷新。</b>';
    });
  }

  function play(i) {
    fetch('/api/sd/play?i=' + i, { method: 'POST' })
      .then(function () { setTimeout(poll, 600); })    // 等主循环真正切过去再刷新高亮
      .catch(function () {
        el('sdstat').innerHTML = '<b style="color:#c0392b">播放请求失败(网络错误)。</b>';
      });
  }

  el('sdScan').onclick = function () {
    el('sdstat').textContent = '正在扫描…';
    fetch('/api/sd/scan', { method: 'POST' }).then(poll);
  };
  el('sdExit').onclick = function () {
    fetch('/api/sd/exit', { method: 'POST' }).then(function () { setTimeout(poll, 500); });
  };
  // 音源切换(与遥控"音源切换"键同一后端): 方向由设备判断, 这里只发意图。
  el('sdToggle').onclick = function () {
    wsCmd('source');
    setTimeout(poll, 800);
  };
  el('sdPrev').onclick = function () { wsCmd('prev'); };
  el('sdNext').onclick = function () { wsCmd('next'); };

  // 上一首/下一首: 走 WebSocket 复用设备现有的 prev/next 语义。
  // (设备端已按音源分流: 在 SD 模式就是"上一个/下一个本地文件", 见 audio_player 的 processCmd。)
  // 拿不到 WS 时静默降级 —— 列表里的"播放"按钮仍可用。
  function wsCmd(c) {
    try {
      var s = new WebSocket('ws://' + location.host + '/ws');
      s.onopen = function () { s.send(c + '=1'); setTimeout(function () { s.close(); }, 300); };
    } catch (e) { /* 忽略: 热点下 WS 可能被 captive portal 掐断 */ }
  }

  poll();
})();