/* 定时开机(闹钟) —— 2026-10-08
 * 放在"设置"页里的一张卡(紧挨"睡眠定时器", 语义相关)。
 *
 * 【它做什么】到"开播时刻"自动切到指定电台开始播放; 到"停播时刻"自动停播 + 熄屏待机。
 *   两个时刻【每天各触发一次】。判定全在固件的 alarm 模块里(src/core/alarm.cpp),
 *   本文件只管配置界面 —— 改这里不会影响"到点会不会响"。
 *
 * ★前提(页面上也写了一句): 设备必须保持【通电】。本机的"睡眠"只是熄屏待机 ——
 *   停播+关屏, 但 CPU / WiFi / 系统钟都还在跑, 所以待机时闹钟照样能开播。
 *   但若设备是"定时关机 / 长按电源键"关进了深度休眠, CPU 已停机, 闹钟不会响
 *   —— 那只能靠电源键或红外唤醒(本功能不做 RTC 定时唤醒)。
 *
 * ★为什么独立成一个文件: app.js 的 gzip 只剩 167B 余量(4800B 是单次响应安全水位),
 *   一行逻辑都塞不下。本文件与 bg.js/sd.js/snd.js/wifi.js/ota.js/listop.js 同理。
 */
(function () {
  'use strict';
  var box = document.getElementById('alarmbox');
  if (!box) return;

  box.innerHTML =
    '<h1>定时开机（闹钟）</h1>' +
    '<div class="sub">到点自动切到指定电台开始播放；设备需保持通电（熄屏待机可以，深度关机不行）。</div>' +
    '<div class="row" style="margin-top:8px;align-items:center">' +
      '<label style="display:flex;align-items:center;gap:6px;font-size:14px">' +
      '<input type="checkbox" id="alEn"> 启用定时开机</label></div>' +
    '<div class="row" style="margin-top:8px">' +
      '<span style="white-space:nowrap">开播时刻</span>' +
      '<input type="time" id="alOn" value="07:00" style="flex:1;padding:8px;border:1px solid #ccc;border-radius:8px;font-size:14px"></div>' +
    '<div class="row" style="margin-top:8px">' +
      '<span style="white-space:nowrap">电台</span>' +
      '<select id="alSt" style="flex:1;padding:8px;border:1px solid #ccc;border-radius:8px;font-size:14px"></select></div>' +
    '<div class="row" style="margin-top:8px;align-items:center;gap:8px">' +
      '<label style="display:flex;align-items:center;gap:6px;font-size:14px;white-space:nowrap">' +
      '<input type="checkbox" id="alOffEn"> 到点自动停止</label>' +
      '<input type="time" id="alOff" value="08:00" style="flex:1;padding:8px;border:1px solid #ccc;border-radius:8px;font-size:14px"></div>' +
    '<div class="row" style="margin-top:8px;align-items:center">' +
      '<button class="btn" id="alSave">保存</button>' +
      '<span class="sub" id="alMsg" style="margin-left:8px"></span></div>';

  var el = function (id) { return document.getElementById(id); };

  // 本文件自带转义 —— 不依赖 app.js 的全局函数(它只剩百来字节, 随时可能被裁)。
  // 台名来自表单或 CSV 导入, 不可信; 拼进 innerHTML 前必须转义。
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function hhmm(h, m) { return pad(h) + ':' + pad(m); }

  var filled = false;        // 下拉是否已按设备里的配置填过一次
  var stations = [];

  function fillSelect(url, name) {
    var h = '';
    var inList = false;
    for (var i = 0; i < stations.length; i++) if (stations[i].url === url) inList = true;
    // ★闹钟指向的电台可能已被删除 —— 那时仍要把它显示出来。否则下拉会静默跳到第 1 台,
    //   用户一按保存就把闹钟改到别的台去了(而且他很可能没注意到)。
    if (url && !inList) {
      h += '<option data-n="' + esc(name || url) + '" value="' + esc(url) + '">' +
           esc(name || url) + '（已不在列表）</option>';
    }
    for (var j = 0; j < stations.length; j++) {
      h += '<option data-n="' + esc(stations[j].name) + '" value="' + esc(stations[j].url) + '">' +
           esc(stations[j].name) + '</option>';
    }
    el('alSt').innerHTML = h || '<option data-n="" value="">（电台列表为空）</option>';
    if (url) el('alSt').value = url;
  }

  // 拉电台列表; 已经填过下拉的话只重建选项、保留当前选中(用户可能正在挑)
  function loadStations(cb) {
    if (document.activeElement === el('alSt')) { cb(); return; }
    fetch('/api/stations').then(function (r) { return r.json(); }).then(function (j) {
      stations = (j && j.stations) || [];
      if (filled) {
        var cur = el('alSt').value;
        fillSelect(cur, '');
        if (cur) el('alSt').value = cur;
      }
      cb();
    }).catch(function () { cb(); });
  }

  function poll() {
    fetch('/api/state').then(function (r) { return r.json(); }).then(function (j) {
      var a = j.alarm;
      if (!a) { el('alMsg').textContent = '固件较旧, 请重新编译烧录'; return; }
      // 用户正在输入/选择时不回填, 免得把刚改的值盖掉
      var tag = document.activeElement ? document.activeElement.tagName : '';
      if (tag === 'INPUT' || tag === 'SELECT') return;
      el('alEn').checked    = !!a.en;
      el('alOn').value      = hhmm(a.onH, a.onM);
      el('alOffEn').checked = !!a.offEn;
      el('alOff').value     = hhmm(a.offH, a.offM);
      if (!filled) { filled = true; fillSelect(a.url, a.name); }
    }).catch(function () { /* 读不到就静默, 不刷错误文案 */ });
  }

  el('alSave').addEventListener('click', function () {
    var sel = el('alSt');
    var opt = sel.options[sel.selectedIndex];
    var url = sel.value || '';
    var name = opt ? (opt.getAttribute('data-n') || '') : '';
    var body = 'en='    + (el('alEn').checked ? 1 : 0) +
               '&on='   + encodeURIComponent(el('alOn').value) +
               '&offen='+ (el('alOffEn').checked ? 1 : 0) +
               '&off='  + encodeURIComponent(el('alOff').value) +
               '&url='  + encodeURIComponent(url) +
               '&name=' + encodeURIComponent(name);
    el('alMsg').textContent = '保存中…';
    fetch('/api/alarm', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body
    }).then(function (r) { return r.json(); }).then(function (j) {
      el('alMsg').textContent = j.ok ? '已保存' : '保存失败';
      setTimeout(function () { el('alMsg').textContent = ''; }, 3000);
    }).catch(function () { el('alMsg').textContent = '保存失败(网络)'; });
  });

  loadStations(function () { poll(); });
  setInterval(poll, 4000);
  // 电台列表可能被增删改 -> 每 30 秒重拉一次(轻量; 下拉内容过期的代价是选到旧台)
  setInterval(function () { loadStations(function () {}); }, 30000);
})();
