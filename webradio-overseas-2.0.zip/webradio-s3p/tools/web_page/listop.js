/* 电台列表多选 + 批量操作 —— 2026-10-07
 * ★为什么独立文件: app.js 的 gzip 已到 4685B / 上限 4800B(只剩 115B),
 *   再往里塞任何逻辑都会超水位 → 后台打不开。本文件只【增强】已有的表格,
 *   不改动 app.js 原有逻辑 —— 它等表格渲染完成后, 自己做增强 + 注入批量工具条。
 *
 * 【做了什么】
 *   1. 表格第一列插入"勾选框"列(表头一个全选框, 每行一个)。
 *   2. 选中 >=1 台时, 列表上方浮出一条【批量操作条】: 已选几台 / 全选 / 取消,
 *      以及"把选中的设为某分类(下拉 + 输入新分类)+ 应用 / 批量删除"。
 *   3. 分类下拉里列出设备上已有的分类, 也可手工输入新分类名。
 *
 * 【为什么要"真实下标"而不是行号】
 *   列表有分类筛选, 显示的第 N 行不等于设备里的第 N 台。本文件的勾选框把
 *   **设备里的真实序号**存在 checkbox 的 data-i 上(与 app.js 的 mktbl 一致),
 *   所以"筛选后只勾选可见的几个"也能正确对应到设备数据。
 */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var picked = {};        // {真实下标: true}
  var bar = null;

  function listData() {
    // app.js 维护的全局 gStations(设备里的全部电台, 与显示筛选无关)
    return (typeof gStations !== 'undefined' && gStations) ? gStations : [];
  }

  function selectedIds() {
    var out = [];
    for (var k in picked) if (picked[k]) out.push(parseInt(k, 10));
    return out;
  }

  function ensureBar() {
    if (bar) return bar;
    var tbl = $('tbl');
    if (!tbl || !tbl.parentNode) return null;
    bar = document.createElement('div');
    bar.className = 'card';
    bar.style.padding = '10px 12px';
    bar.style.marginBottom = '10px';
    bar.style.display = 'none';
    bar.innerHTML =
      '<div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;font-size:13px">' +
      '<b id="msCnt">已选 0 台</b>' +
      '<button class="btn sm" id="msAll">全选(当前筛选)</button>' +
      '<button class="btn sm sec" id="msNone">取消选择</button>' +
      '<span style="width:10px"></span>' +
      '<span>统一设为分类</span>' +
      '<input id="msGp" list="msGpList" placeholder="分类名(留空=未分类)" ' +
      'style="flex:1;min-width:130px;padding:6px 8px;border:1px solid #ccc;border-radius:8px;font-size:13px">' +
      '<datalist id="msGpList"></datalist>' +
      '<button class="btn sm" id="msApply">应用</button>' +
      '<button class="btn sm danger" id="msDel">批量删除</button>' +
      '</div>';
    tbl.parentNode.insertBefore(bar, tbl);

    $('msAll').onclick = function () {
      var seen = [], tb = $('tbody');
      if (tb) {
        tb.querySelectorAll('input[data-i]').forEach(function (cb) {
          seen.push(parseInt(cb.getAttribute('data-i'), 10));
        });
      }
      if (!seen.length) { toast('当前筛选下没有可见电台', 'err'); return; }
      seen.forEach(function (i) { picked[i] = true; });
      sync();
    };
    $('msNone').onclick = function () { picked = {}; sync(); };

    $('msApply').onclick = function () {
      var ids = selectedIds();
      if (!ids.length) { toast('请先勾选电台', 'err'); return; }
      var g = $('msGp').value;
      var body = new URLSearchParams();
      body.append('ids', ids.join(','));
      body.append('group', g);
      if (g && !confirm('把选中的 ' + ids.length + ' 台设为分类「' + g + '」?')) return;
      fetch('/api/station/group', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body.toString()
      })
        .then(function (r) { return r.json(); })
        .then(function (j) {
          if (j && j.ok) {
            toast(j.msg || '已批量设置分类');
            picked = {};
            return stations();               // 重新拉设备列表(唯一真值), 不做乐观更新
          }
          toast((j && j.msg) || '设置失败', 'err');
        })
        .catch(function () { toast('请求失败(网络)', 'err'); });
    };

    $('msDel').onclick = function () {
      var ids = selectedIds();
      if (!ids.length) { toast('请先勾选电台', 'err'); return; }
      if (!confirm('删除选中的 ' + ids.length + ' 台电台?此操作不可撤销。')) return;
      // ★倒序删: 删除会让下标前移, 从大到小删才不会漏删/错删(与页面提示的顺序无关)。
      ids.sort(function (a, b) { return b - a; });
      var chain = Promise.resolve();
      ids.forEach(function (i) {
        chain = chain.then(function () {
          return fetch('/api/station/del?' + new URLSearchParams({ id: i }).toString(), { method: 'POST' })
            .then(function (r) { return r.text(); });
        });
      });
      chain.then(function () {
        toast('已删除 ' + ids.length + ' 台');
        picked = {};
        return stations();
      }).catch(function () { toast('删除过程中出错', 'err'); });
    };

    return bar;
  }

  function fillGroupList() {
    var dl = $('msGpList');
    if (!dl) return;
    var seen = [];
    listData().forEach(function (s) {
      var g = s.group || '未分类';
      if (seen.indexOf(g) < 0) seen.push(g);
    });
    dl.innerHTML = seen.map(function (g) {
      return '<option value="' + g.replace(/"/g, '&quot;') + '">';
    }).join('');
  }

  // 勾选状态变化后: 更新计数 / 全选框 / 批量条显隐
  function sync() {
    var n = selectedIds().length;
    var c = $('msCnt');
    if (c) c.textContent = '已选 ' + n + ' 台';
    if (bar) bar.style.display = n ? '' : 'none';
    // 表头全选框: 只在"当前可见行全被选中"时打勾, 否则显示半选(indeterminate)
    var head = $('msHead');
    if (head) {
      var tbs = $('tbody');
      var vis = tbs ? tbs.querySelectorAll('input[data-i]') : [];
      var sel = 0;
      Array.prototype.forEach.call(vis, function (cb) {
        if (picked[cb.getAttribute('data-i')]) sel++;
      });
      head.checked = vis.length > 0 && sel === vis.length;
      head.indeterminate = sel > 0 && sel < vis.length;
    }
  }

  // 给表格插勾选列 + 注入批量条。table 结构: #tbl (table) > thead/tbody
  function enhance() {
    var tbl = $('tbl'), tb = $('tbody');
    if (!tbl || !tb) return;
    if (!ensureBar()) return;
    fillGroupList();

    // 表头: 在第一列前插入"全选"表头格
    var tr0 = tbl.querySelector('thead tr');
    if (tr0 && !$('msHead')) {
      var th = document.createElement('th');
      th.style.width = '28px';
      th.innerHTML = '<input type="checkbox" id="msHead" title="全选(当前筛选下的)">';
      tr0.insertBefore(th, tr0.firstChild);
      $('msHead').onchange = function () {
        Array.prototype.forEach.call(tb.querySelectorAll('input[data-i]'), function (cb) {
          cb.checked = $('msHead').checked;
          if ($('msHead').checked) picked[cb.getAttribute('data-i')] = true;
          else delete picked[cb.getAttribute('data-i')];
        });
        sync();
      };
    }

    // 每行: 在第一列前插入勾选框(data-i = 设备里的真实下标)
    Array.prototype.forEach.call(tb.rows, function (tr, idx) {
      if (tr.querySelector('input[data-i]')) return;
      // ★找出行号单元格里的数字 -> 它就是 app.js 写入的真实下标(i+1)
      var first = tr.cells[0];
      var txt = first ? (first.textContent || '').trim() : '';
      var realIdx = parseInt(txt, 10);
      if (!isFinite(realIdx)) realIdx = idx;        // 兜底: 解析不到就用行序
      realIdx = realIdx - 1;
      var td = document.createElement('td');
      var cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.setAttribute('data-i', realIdx);
      cb.style.width = '18px';
      cb.checked = !!picked[realIdx];
      cb.onchange = function () {
        if (cb.checked) picked[cb.getAttribute('data-i')] = true;
        else delete picked[cb.getAttribute('data-i')];
        sync();
      };
      td.appendChild(cb);
      tr.insertBefore(td, tr.firstChild);
    });

    sync();
  }

  // app.js 的 renderTable 每隔几秒 / 增删改后会重画 tbody, 勾选框随之被清掉。
  // 这里用 MutationObserver 盯着 tbody, 变了就自动重新增强 —— 否则用户勾选完一刷新就没了。
  function hook() {
    var tb = $('tbody');
    if (!tb || !tb.parentNode) { setTimeout(hook, 300); return; }
    enhance();
    var mo = new MutationObserver(function () {
      // tbody 被重画: 行内容变了, 但用户勾选的 picked 仍保留(按真实下标), 重新插入勾选框即可。
      enhance();
    });
    mo.observe(tb, { childList: true });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', hook);
  else hook();
})();