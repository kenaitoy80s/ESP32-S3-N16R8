/* WiFi 多组凭据 —— 2026-10-06
 * 最多 3 组 SSID/密码: 开机按顺序自动尝试(上次连上的那个优先), 全部失败才进配网热点。
 * ★提交走 HTTP POST 而不是 WebSocket: AP 热点(无外网)下手机的 WS 常被 captive portal 掐断,
 *   表现为"页面能开、点了保存却没反应"。HTTP 与页面同源同机制, 跨设备一致可靠。
 * ★密码只写不读: /api/state 的 wnet 只回 SSID 与"是否已配置", 密码框永远留空;
 *   留空提交时干脆【不带 pwd 字段】= 设备端保持原密码(由 hasParam 区分"没传"和"传了空串")。
 * ★独立成一个资源: app.js 的 gzip 余量只剩几十字节, 塞不进任何新逻辑。
 */
(function () {
  'use strict';
  var box = document.getElementById('wifiBox');
  if (!box) return;

  var N = 3, st = { slots: [], cur: -1, ap: false, rssi: 0, on: false };

  box.innerHTML =
    '<h1>WiFi 配网</h1>' +
    '<div class="hint" id="wfi">正在读取设备状态…</div>' +
    '<div id="wfs"></div>' +
    '<button class="btn" id="wfApply" style="margin-top:12px">保存并重启</button>' +
    '<div class="hint" id="wfm" style="margin-top:8px"></div>';

  function el(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function msg(t, bad) {
    el('wfm').innerHTML = '<b style="color:' + (bad ? '#c0392b' : '#1a7f37') + '">' + t + '</b>';
  }
  function post(url, params) {
    return fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams(params).toString()
    }).then(function (r) { return r.json(); });
  }

  function render() {
    var h = '';
    for (var i = 0; i < N; i++) {
      var s = st.slots[i] || {};
      h += '<div style="margin-top:10px;border-top:1px solid #888;padding-top:10px">' +
        '<b>网络 ' + (i + 1) + '</b> · ' +
        (s.set ? '<b style="color:#1a7f37">已配置</b>' : '未配置') +
        (st.cur === i ? ' · <b style="color:#1a7f37">当前在用</b>' : '') +
        '<div class="row" style="margin:6px 0">' +
        '<input id="ws' + i + '" placeholder="SSID" value="' + esc(s.ssid || '') + '">' +
        '<input id="wp' + i + '" type="password" placeholder="密码(留空 = 不改)"></div>' +
        '<button class="btn sm" id="wb' + i + '">写入</button>' +
        '<button class="btn danger sm" id="wd' + i + '" style="margin-left:6px">清空</button></div>';
    }
    el('wfs').innerHTML = h;
    for (var k = 0; k < N; k++) bind(k);
  }

  function bind(i) {
    el('wb' + i).onclick = function () {
      var ssid = el('ws' + i).value.trim();
      if (!ssid) { msg('网络 ' + (i + 1) + ' 的 SSID 不能为空 —— 想删掉它请点"清空"。', true); return; }
      var p = { slot: i, ssid: ssid };
      var pwd = el('wp' + i).value;
      if (pwd) p.pwd = pwd;                 // ★留空就【不带 pwd 字段】= 设备端保持原密码
      post('/api/wifi/slot', p).then(function (j) {
        if (!j.ok) { msg('写入失败: ' + (j.msg || '未知原因'), true); return; }
        el('wp' + i).value = '';
        msg('网络 ' + (i + 1) + ' 已写入 —— 改完记得点下方"保存并重启"才生效。');
        setTimeout(refresh, 800);
      }).catch(function () { msg('写入失败(网络错误)', true); });
    };
    el('wd' + i).onclick = function () {
      if (!confirm('清空网络 ' + (i + 1) + '?')) return;
      post('/api/wifi/del', { slot: i }).then(function (j) {
        if (!j.ok) { msg('清空失败: ' + (j.msg || '未知原因'), true); return; }
        msg('网络 ' + (i + 1) + ' 已清空。');
        setTimeout(refresh, 800);
      }).catch(function () { msg('清空失败(网络错误)', true); });
    };
  }

  function refresh() {
    fetch('/api/state').then(function (r) { return r.json(); }).then(function (j) {
      var w = j.wnet;
      if (!w) { el('wfi').textContent = '固件较旧: /api/state 里没有 wnet 字段, 请先烧入新固件。'; return; }
      st.slots = w.slots || []; st.cur = w.cur; st.ap = w.ap; st.rssi = w.rssi; st.on = !!j.wifi;
      if (w.n) N = w.n;
      if (st.on) {
        el('wfi').innerHTML = '已连接 <b>' + esc(j.ip) + '</b> · 信号 <b>' + st.rssi + ' dBm</b>';
      } else {
        el('wfi').innerHTML = (st.ap ? '<b style="color:#c0392b">未连上任何网络</b> —— 现处于配网热点模式'
                                     : '<b style="color:#c0392b">未连接</b>') +
          ' · 当前生效: ' + (st.cur >= 0 ? ('网络 ' + (st.cur + 1)) : '无');
      }
      render();
    }).catch(function () { el('wfi').textContent = '读不到设备状态, 请按 Ctrl+Shift+R 强制刷新。'; });
  }

  el('wfApply').onclick = function () {
    if (!confirm('保存并重启设备?\n重启后按新顺序尝试连接, 大约 10~30 秒。')) return;
    post('/api/wifi/apply', {}).then(function () {
      msg('已保存, 设备正在重启… 连上之后刷新本页即可。');
    }).catch(function () { msg('请求失败(设备可能已经在重启了)', true); });
    setTimeout(refresh, 20000);
  };

  refresh();
})();
