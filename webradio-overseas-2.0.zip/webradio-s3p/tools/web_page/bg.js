/* 屏幕背景(彩色) —— 2026-10-06
 * 横/竖两个方向的槽并列: 各自选图上传承删, 不用再切设备方向来回传两趟。
 * 重活全在浏览器: 居中裁剪 -> RGB565 裸字节 -> POST。设备端不解码图片、不缩放。
 * ★字节序: 固件推屏是 `*dst++ = c>>8`(大端), 这里必须高字节在前, 否则整屏半像素乱色。
 * ★为什么独立一个文件: app.js 的 gzip 只剩 92B; 而标签页切换是 index.html 末尾的通用内联
 *   脚本(遍历 .tab/.page), 所以本页只要挂两行 HTML 就工作, 完全不用碰 app.js。
 */
(function () {
  'use strict';
  var box = document.getElementById('bgbox');
  if (!box) return;

  // 两个方向: k = 设备端的方向键(也是 /api/bg/<k> 的路径段)
  var S = [{ k: 'l', n: '横屏', w: 320, h: 240 }, { k: 'p', n: '竖屏', w: 240, h: 320 }];
  var im = { l: null, p: null };          // 两个槽各自的原图
  var alpha = 100, known = false, want = 153600;

  var h = '<div class="card"><h1>屏幕背景(彩色)</h1><div class="hint" id="bgi">正在读取设备状态…</div>' +
    '<div style="display:flex;gap:18px;flex-wrap:wrap;margin-top:12px">';
  S.forEach(function (s) {
    h += '<div style="flex:1 1 260px;min-width:230px;border-top:1px solid #888;padding-top:10px">' +
      '<b>' + s.n + ' ' + s.w + '×' + s.h + '</b> · <span id="bgst_' + s.k + '">—</span>' +
      '<div><input type="file" id="bgf_' + s.k + '" accept="image/*" style="font-size:13px"></div>' +
      '<canvas id="bgc_' + s.k + '" width="' + s.w + '" height="' + s.h +
      '" style="width:100%;height:auto;image-rendering:pixelated;border:1px solid #777;margin:6px 0;display:block"></canvas>' +
      '<button class="btn sm" id="bgu_' + s.k + '">上传到设备</button>' +
      '<button class="btn danger sm" id="bgd_' + s.k + '" style="margin-left:6px">删除</button></div>';
  });
  h += '</div>' +
    '<div style="margin-top:10px"><button class="btn" id="bgAll">两张一起上传</button></div>';
  h += '<div style="margin-top:12px;border-top:1px solid #888;padding-top:10px">' +
    '界面不透明度 <b id="bgav">100%</b>' +
    '<input type="range" id="bga" min="0" max="100" step="5" value="100" style="width:100%;margin:4px 0">' +
    '<button class="btn sm" id="bgaUp">应用到设备</button></div>' +
    '<div style="margin-top:8px"><label><input type="checkbox" id="bgdith" checked> ' +
    '上传时做<b>有序抖动</b>(渐变底图更平滑)</label></div>' +
    '<div class="hint" id="bgm" style="margin-top:8px"></div></div>';
  box.innerHTML = h;

  function el(id) { return document.getElementById(id); }
  var L = {};
  S.forEach(function (s) { var c = el('bgc_' + s.k); L[s.k] = { s: s, cx: c.getContext('2d') }; });
  var elInfo = el('bgi'), elMsg = el('bgm'), elA = el('bga'), elAV = el('bgav'), elD = el('bgdith');
  // 抖动开关: 面板只吃 65K 色, 渐变必分层; 抖动靠人眼空间平均抹平台阶(库见 /dith.js)
  function dOn() { return !!(elD && elD.checked && window.DITH); }

  // 失败用红色加粗: "上传无效"的反馈必须一眼看见卡在哪
  function msg(t, bad) {
    if (!t) { elMsg.textContent = ''; return; }
    elMsg.innerHTML = '<b style="color:' + (bad ? '#c0392b' : '#1a7f37') + '">' + t + '</b>';
  }

  // 界面会占用的区域(仅预览示意; 与 display_ui.cpp 大屏布局对应)
  function uiRects(s) {
    return s.k === 'p'
      ? [[0, 0, 240, 24], [0, 28, 240, 24], [0, 48, 240, 94], [6, 150, 228, 100], [6, 256, 228, 62]]
      : [[0, 0, 320, 26], [0, 26, 190, 112], [196, 28, 120, 100], [8, 140, 304, 98]];
  }

  // 等比缩放 + 居中裁剪(cover): 不变形、不留黑边
  function cover(c, g, w, hh) {
    var k = Math.max(w / g.width, hh / g.height), dw = g.width * k, dh = g.height * k;
    c.drawImage(g, (w - dw) / 2, (hh - dh) / 2, dw, dh);
  }

  function draw(k) {
    var o = L[k], s = o.s, c = o.cx;
    c.clearRect(0, 0, s.w, s.h);
    // 预览也按真实 5/6/5 量化, 否则预览比真机好看, 用户会以为没效果
    if (im[k]) { cover(c, im[k], s.w, s.h); if (window.DITH) window.DITH.preview(c, s.w, s.h, dOn()); }
    else { c.fillStyle = '#000'; c.fillRect(0, 0, s.w, s.h); }
    var a = alpha / 100;
    c.lineWidth = 2;
    c.strokeStyle = 'rgba(255,255,255,' + a + ')';
    c.fillStyle = 'rgba(255,255,255,' + (a * 0.18).toFixed(3) + ')';
    uiRects(s).forEach(function (r) {
      c.fillRect(r[0], r[1], r[2], r[3]);
      c.strokeRect(r[0] + 1, r[1] + 1, r[2] - 2, r[3] - 2);
    });
  }

  // 转 RGB565 大端(与固件 DRAW_TILE 的发送顺序严格一致)
  function to565(d, w, hh) {
    var o = new Uint8Array(w * hh * 2), p = 0;
    for (var i = 0; i < d.length; i += 4) {
      var v = ((d[i] >> 3) << 11) | ((d[i + 1] >> 2) << 5) | (d[i + 2] >> 3);
      o[p++] = v >> 8;                  // 高字节先
      o[p++] = v & 0xFF;
    }
    return o;
  }

  function refresh() {
    fetch('/api/state').then(function (r) { return r.json(); }).then(function (j) {
      if (j.bgBytes) want = j.bgBytes;
      if (j.bgAlpha !== undefined && j.bgAlpha !== null) {
        alpha = j.bgAlpha; elA.value = alpha; elAV.textContent = alpha + '%';
      }
      el('bgst_l').textContent = j.bgLand ? '已设置 ✓' : '未设置';
      el('bgst_p').textContent = j.bgPort ? '已设置 ✓' : '未设置';
      // 内存一行: 150KB 能不能落进 PSRAM 全看这里
      var mem = '';
      if (j.psramSize !== undefined) {
        mem = ' ｜ PSRAM 总' + j.psramSize + 'KB 空闲' + j.psramFree + 'KB 最大连续' + j.psramMax +
              'KB ｜ 内部RAM 最大连续' + j.heapMax + 'KB' +
              (j.psramSize ? '' : ' <b style="color:#c0392b">← PSRAM 未启用, 背景图无法工作</b>');
      }
      elInfo.innerHTML = '设备当前: <b>' + (j.orient === 'P' ? '竖屏 240×320' : '横屏 320×240') +
        '</b>(上电实际用哪张由它决定)' + mem;
      known = true;
      S.forEach(function (s) { draw(s.k); });
    }).catch(function () {
      elInfo.textContent = '读不到设备状态, 请按 Ctrl+Shift+R 强制刷新。';
    });
  }

  // 返回 Promise: 供"两张一起上传"串行编排 —— 设备端收 150KB 的上传缓冲是共用的, 不能并发
  function up(s) {
    if (!im[s.k]) { msg('"' + s.n + '"还没选图片。', true); return Promise.resolve(false); }
    if (!known) { msg('还没读到设备状态, 请先强制刷新页面。', true); return Promise.resolve(false); }
    msg('正在转换并上传' + s.n + '…(150KB, 通常 1~3 秒)');
    // 用离屏 canvas 只画背景本身 —— 预览那个上面还叠着界面示意, 不能直接用
    var t = document.createElement('canvas'); t.width = s.w; t.height = s.h;
    var tc = t.getContext('2d');
    cover(tc, im[s.k], s.w, s.h);
    var b;
    // 有 /dith.js 就用带抖动的量化; 没加载到就回落本地 to565(行为与旧版一致)
    try { b = window.DITH ? window.DITH.to565(tc.getImageData(0, 0, s.w, s.h).data, s.w, s.h, dOn())
                          : to565(tc.getImageData(0, 0, s.w, s.h).data, s.w, s.h); }
    catch (e) { msg('这个图片来源不允许读取像素, 换个文件试试。', true); return Promise.resolve(false); }
    if (b.length !== want) { msg('内部错误: 生成 ' + b.length + ' 字节, 设备期望 ' + want, true); return Promise.resolve(false); }

    return fetch('/api/bg/' + s.k, { method: 'POST', body: b })
      // 先读 text 再自己 parse: 设备出错时可能返回非 JSON, 直接 r.json() 会抛异常被 catch 吞掉
      .then(function (r) { return r.text().then(function (x) { return { c: r.status, x: x }; }); })
      .then(function (y) {
        var j = null;
        try { j = JSON.parse(y.x); } catch (e) {}
        if (!j) { msg('设备返回 HTTP ' + y.c + ' —— ' + String(y.x).slice(0, 140), true); return false; }
        if (!j.ok) { msg('设备拒绝了(' + s.n + '): ' + (j.msg || '未知原因'), true); return false; }
        msg('已接收' + s.n + ' ' + j.bytes + ' 字节, 正在写入 flash…');
        return true;
      })
      .catch(function (e) { msg('上传失败(' + s.n + '): ' + ((e && e.message) ? e.message : '网络错误'), true); return false; });
  }

  S.forEach(function (s) {
    el('bgf_' + s.k).addEventListener('change', function () {
      var f = this.files && this.files[0];
      if (!f) return;
      msg('');
      var g = new Image();
      g.onload = function () {
        im[s.k] = g; draw(s.k);
        msg('已给"' + s.n + '"选好 ' + f.name + ' (' + g.width + '×' + g.height + '), 点"上传到设备"生效。');
      };
      g.onerror = function () { msg('这不是浏览器能识别的图片格式。', true); };
      g.src = URL.createObjectURL(f);
    });
    el('bgu_' + s.k).addEventListener('click', function () {
      up(s).then(function (ok) { if (ok) setTimeout(refresh, 2500); });
    });
    el('bgd_' + s.k).addEventListener('click', function () {
      if (!confirm('删除' + s.n + '方向的背景图?')) return;
      fetch('/api/bg/clear/' + s.k, { method: 'POST' })
        .then(function (r) { return r.json(); })
        .then(function () { msg('已请求删除。'); setTimeout(refresh, 1200); })
        .catch(function () { msg('删除请求失败。', true); });
    });
  });

  // 一键传两张: 串行(等横屏那批落盘完再发竖屏), 因为设备端上传缓冲只有一份
  el('bgAll').addEventListener('click', function () {
    if (!im.l || !im.p) { msg('要先给横屏和竖屏各选一张图片。', true); return; }
    msg('正在依次上传横屏、竖屏…');
    up(S[0]).then(function () { return up(S[1]); }).then(function () {
      msg('两张都已送达设备, 正在写入 flash…(约 3 秒后自动生效)');
      setTimeout(refresh, 3000);
    });
  });

  elA.addEventListener('input', function () {
    elAV.textContent = this.value + '%'; alpha = +this.value;
    S.forEach(function (s) { draw(s.k); });
  });
  el('bgaUp').addEventListener('click', function () {
    var v = +elA.value;
    var fd = new FormData(); fd.append('v', v);
    fetch('/api/bg/alpha', { method: 'POST', body: fd })
      .then(function (r) { return r.json(); })
      .then(function (j) { msg(j.ok ? ('界面不透明度已设为 ' + v + '%') : '设置失败', !j.ok); })
      .catch(function () { msg('设置失败(网络)', true); });
  });

  refresh();
})();
