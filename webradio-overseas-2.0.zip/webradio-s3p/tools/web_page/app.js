const $=id=>document.getElementById(id);
let BUILD="",VER="",gStations=[],editingId=-1,gIrState={codes:{}},irLearning=false;
// 本文件 gzip 编进固件, 单资源 4800B 硬水位(见 page_assets.h) -> 保持短小、高重复度写法。

// ---------- toast ----------
let toastTimer=null;
function toast(m,k){const t=$('toast');t.textContent=m;t.className=k==='err'?'err':'';t.style.display='block';clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.style.display='none',2200);}

// ---------- WebSocket(单条 "cmd=val" 文本指令) ----------
let ws=null;
function connectWs(){
  try{ws=new WebSocket('ws://'+location.host+'/ws');}catch(e){ws=null;return;}
  ws.onopen=()=>{$('net').textContent+=' ｜ WS已连';};
  ws.onclose=()=>setTimeout(connectWs,2000);   // 断线自动重连
  ws.onerror=()=>{};
  ws.onmessage=e=>{try{const d=JSON.parse(e.data);
    if(d.type==='state')applyState(d);
    else if(d.type==='ack'){if(d.ok)toast(d.msg||('已保存 ✓ 共'+d.count+'台'));else toast('操作失败: '+(d.msg||''),'err');}
    else if(d.type==='ir')onIrMsg(d);
  }catch(_){}};
}
function wsSend(s){if(ws&&ws.readyState===1)ws.send(s);else toast('未连接到设备, 请刷新页面','err');}

// ---------- 状态轮询 ----------
async function state(){try{const r=await fetch('/api/state?_='+Date.now(),{cache:'no-store'});applyState(await r.json());}catch(e){}}
// 电台列表按需拉取(不进周期轮询: 免得每 3s 重建表格丢焦点/丢编辑中的输入)
async function stations(){try{const r=await fetch('/api/stations?_='+Date.now(),{cache:'no-store'});const d=await r.json();gStations=d.stations||[];renderTable(gStations);}catch(e){}}

// 回填辅助: 控件正被用户操作时不覆盖
const keep=id=>document.activeElement!=$(id);
const sv=(id,v)=>{if(typeof v!=='undefined'&&keep(id))$(id).value=v;};
const sc=(id,v)=>{if(typeof v!=='undefined'&&keep(id))$(id).checked=!!v;};
function applyState(d){
  $('net').textContent=d.wifi?('已联网 '+d.ip):('配网热点 '+d.ip);
  $('cur').textContent=d.stationName||'—';
  $('meta').textContent=(d.playing?'▶':'⏸')+' '+d.status+'  '+d.bitrate+'  '+(d.title||'');
  $('vol').value=d.volume;$('volv').textContent=d.volume;
  sv('scrType',d.screen);sv('scrRot',d.rot);sv('scrBL',d.blTimeout);
  if(keep('ctr')){$('ctr').value=d.contrast;$('ctrv').textContent=d.contrast;}
  if(keep('brg')&&typeof d.bright!=='undefined'){$('brg').value=d.bright;$('brgv').textContent=d.bright;}
  sc('stInv',d.inv);
  if(d.build){                       // 版本自检: BUILD 初值为空, 必须先赋值再比较
    if(!BUILD){BUILD=d.build;VER=d.ver||'';
      $('verBadge').textContent=VER?('固件 '+VER):('构建: '+BUILD);
      $('ver').textContent=(VER?('固件 '+VER+' ｜ '):'')+'构建 '+BUILD;}
    else if(d.build!==BUILD){$('stale').style.display='block';
      $('stale').firstChild.textContent='⚠ 页面版本('+BUILD+')与设备('+d.build+')不一致, 可能是旧缓存页。';}
  }
  if(d.ir){gIrState=d.ir;irLearning=!!d.ir.learning;renderIr();}
  // 睡眠定时器剩余时间回显(规则与屏上一致) + 回填下拉
  if(d.sleepRemain>0){const m=Math.ceil(d.sleepRemain/60),h=m/60|0;
    $('sleepRemain').textContent='剩余 '+(h?h+'时'+(m%60?m%60+'分':''):m+'分');}
  else $('sleepRemain').textContent='未设定';
  if(keep('sleepMin')&&typeof d.sleepMin!=='undefined')$('sleepMin').value=d.sleepMin>0?String(d.sleepMin):'0';
}

// ---------- 列表渲染(电台表, 按分类筛选) ----------
// 下标 i = 设备里的【真实序号】, 筛选只影响显示哪些行 -> 播放/编辑/删除都用真实 i, 不会错台。
// 台名/分类来自表单或 CSV, 不可信 -> 拼进 innerHTML 前必须 esc(否则 "<" 会吃掉后面三个按钮)。
const esc=s=>String(s).replace(/[&<>"]/g,c=>'&#'+c.charCodeAt(0)+';');
function mktbl(tbId,list){
  const tb=$(tbId);tb.innerHTML='';
  const gf=$('fltGroup').value;                 // 选中的分类(空=全部)
  list.forEach((s,i)=>{
    const g=(s.group||'未分类');
    if(gf&&g!==gf)return;                        // 分类筛选
    const tr=document.createElement('tr');
    tr.innerHTML='<td>'+(i+1)+'</td><td>'+esc(s.name)+'</td><td>'+esc(g)+'</td><td></td>';
    const td=tr.lastChild;
    const pb=document.createElement('button');pb.className='btn sm';pb.textContent='播放';
    pb.onclick=()=>wsSend('play='+i);
    td.append(pb);
    const eb=document.createElement('button');eb.className='btn sm sec';eb.textContent='编辑';
    eb.onclick=()=>{editingId=i;$('nName').value=s.name;$('nUrl').value=s.url;$('nGroup').value=s.group||'';
      $('addTitle').textContent='编辑电台';$('bAdd').textContent='保存修改';
      $('bCancel').style.display='inline-block';$('editHint').style.display='block';
      $('addCard').scrollIntoView({behavior:'smooth'});$('nName').focus();};
    td.append(eb);
    const db=document.createElement('button');db.className='btn sm danger';db.textContent='删除';
    db.onclick=()=>{if(!confirm('删除 '+s.name+'?'))return;apiStation('del',{id:i});};
    td.append(db);tb.append(tr);
  });
}
// 分类下拉: 从列表里去重出所有分类(保持出现顺序), 加上"全部分类"与数量
function fillGroups(list){
  const sel=$('fltGroup'),cur=sel.value,seen=[];
  list.forEach(s=>{const g=s.group||'未分类';if(seen.indexOf(g)<0)seen.push(g);});
  sel.innerHTML='<option value="">全部分类</option>'+seen.map(g=>'<option>'+esc(g)+'</option>').join('');
  sel.value=(seen.indexOf(cur)>=0||cur==='')?cur:'';   // 分类被删/改名后回落到"全部"
}
const renderTable=list=>{fillGroups(list);mktbl('tbody',list);};
$('fltGroup').onchange=()=>mktbl('tbody',gStations);

// ---------- 添加 / 保存修改(同一按钮, 靠 editingId 区分) ----------
// 走 HTTP POST, 成功后重拉设备列表(唯一真值), 不做乐观更新
async function apiStation(op,params){
  try{
    const r=await fetch('/api/station/'+op,{method:'POST',
      headers:{'Content-Type':'application/x-www-form-urlencoded'},
      body:new URLSearchParams(params).toString()});
    let d={};try{d=await r.json();}catch(_){}
    if(d.ok){toast(d.msg||'已保存 ✓');stations();}
    else toast('操作失败: '+(d.msg||r.status),'err');
  }catch(e){toast('请求失败, 请刷新页面','err');}
}
function exitEdit(){
  editingId=-1;$('addTitle').textContent='添加电台';$('bAdd').textContent='添加';
  $('bCancel').style.display='none';$('editHint').style.display='none';
  $('nName').value='';$('nUrl').value='';$('nGroup').value='';
}
$('bAdd').onclick=()=>{
  const n=$('nName').value.trim(),u=$('nUrl').value.trim();
  if(!n||!u){alert('请填写名称和地址');return;}
  const g=$('nGroup').value.trim();                 // 分类可留空 -> 设备端归一为"未分类"
  if(editingId>=0)apiStation('edit',{id:editingId,name:n,url:u,group:g});  // 编辑=覆盖
  else apiStation('add',{name:n,url:u,group:g});                          // 新增=追加
  exitEdit();
};
$('bCancel').onclick=exitEdit;

// ---------- 导入电台(CSV/TSV) ----------
// 浏览器端读文本 -> urlencoded list= POST(不走 multipart, ESP32 更省内存)
$('impFile').onchange=e=>{const f=e.target.files[0];if(!f)return;
  const rd=new FileReader();rd.onload=()=>{$('impText').value=rd.result;toast('已读取 '+f.name);};
  rd.readAsText(f,'utf-8');};
$('bImport').onclick=async()=>{
  const t=$('impText').value.trim();if(!t){alert('请选择文件或粘贴内容');return;}
  const rp=$('impReplace').checked?'1':'0';
  if(rp==='1'&&!confirm('将清空现有全部电台再导入, 确定?'))return;
  try{
    const r=await fetch('/api/station/import',{method:'POST',
      headers:{'Content-Type':'application/x-www-form-urlencoded'},
      body:new URLSearchParams({list:t,replace:rp}).toString()});
    const d=await r.json();
    toast(d.msg||(d.ok?'导入完成 ✓':'导入失败'),d.ok?'':'err');
    if(d.ok)stations();
  }catch(e){toast('导入请求失败, 请刷新重试','err');}
};

// ---------- 播放/音量/WiFi ----------
$('bPrev').onclick=()=>wsSend('prev=1');
$('bNext').onclick=()=>wsSend('next=1');
$('bPlay').onclick=()=>wsSend('toggle=1');
$('vol').onchange=e=>wsSend('volume='+e.target.value);
$('bReset').onclick=()=>{if(!confirm('重置配网? 设备将进入热点模式'))return;
  fetch('/api/reset',{method:'POST'}).catch(()=>{});toast('重启中…');};

// ---------- 显示设置 ----------
// 首段=屏幕类型(1=ST7567/2=SSD1306/3=ST7789); 之后=对比度/旋转/背光超时/背光亮度
$('ctr').oninput=e=>{$('ctrv').textContent=e.target.value;};
$('brg').oninput=e=>{$('brgv').textContent=e.target.value;};
$('bDisp').onclick=()=>{
  wsSend('disp='+$('scrType').value+'||'+$('ctr').value+'||'+$('scrRot').value+'||'+$('scrBL').value+'||'+$('brg').value+'||'+(+$('stInv').checked));
  toast('已发送显示设置…');
};

// ---------- 睡眠定时器(2026-10-06 阶段①) ----------
$('bSleep').onclick=()=>{wsSend('sleep='+$('sleepMin').value);toast('睡眠定时器已设置');};

// ---------- 红外遥控学习 ----------
const IR_ACTS=['prev','next','toggle','volup','voldown','power','rotate','screen','sd','timer'];
function onIrMsg(d){
  if(typeof d.learning!=='undefined')irLearning=!!d.learning;
  if(typeof d.learningAction!=='undefined')gIrState.learningAction=d.learningAction;
  renderIr();
}
function irLearn(a){irLearning=true;wsSend('irlearn='+a);toast('等待按下遥控器对应按键…');}
function renderIr(){
  const rdy=$('irReady');
  if(rdy){const ok=gIrState.ready;
    rdy.textContent=(typeof ok==='undefined')?'未知':(ok?'RMT就绪 ✓':'未初始化(检查VS1838B接线)');
    rdy.style.color=ok?'#2e7d32':'#c62828';}
  IR_ACTS.forEach(a=>{
    const b=$('ir_'+a);if(b)b.disabled=irLearning;
    const s=$('ir_stat_'+a);if(s)s.textContent=(gIrState.codes&&gIrState.codes[a])?'✓':'—';
  });
  const info=$('irLearnInfo');
  if(info)info.textContent=irLearning?('学习: '+(gIrState.learningAction||'…')):'';
}
IR_ACTS.forEach(a=>{const b=$('ir_'+a);if(b)b.onclick=()=>irLearn(a);});
$('irClr').onclick=()=>{if(!confirm('清除全部已学红外码?'))return;wsSend('irclr=all');toast('已清除全部');};

// ---------- 启动 ----------
connectWs();
state();stations();setInterval(state,3000);
$('verBadge').textContent='读取中…';
$('ver').textContent='';
