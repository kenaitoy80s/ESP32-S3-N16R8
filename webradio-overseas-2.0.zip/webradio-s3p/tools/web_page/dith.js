/* RGB565 量化 + 8x8 Bayer 有序抖动 —— 共享库(独立资源 /dith.js, 由 bg.js 调用)。
 * 为什么需要: 面板只吃 16-bit RGB565(65K 色), 平滑渐变在 65K 色下必然分成一条条色带。
 *   抖动让相邻像素在量化台阶两边交替取整, 靠人眼空间平均把台阶抹平(拿空间换色深),
 *   观感接近 262K 色。颗粒按【屏幕物理像素】排列: 1 像素 1 点, 贴着看才有, 正常距离看不出。
 * 为什么单独一个文件: 详见 gen_page_gz.py —— 单次响应的 gzip 上限 4800B(bg.js 已顶格)。
 * 暴露: window.DITH.to565(data,w,h,dither) -> Uint8Array(大端 RGB565)
 *       window.DITH.preview(canvasCtx,w,h,dither) -> 就地把 canvas 量化成面板真实颜色
 */
(function () {
  'use strict';
  var B = [ 0,32, 8,40, 2,34,10,42, 48,16,56,24,50,18,58,26,
           12,44, 4,36,14,46, 6,38, 60,28,52,20,62,30,54,22,
            3,35,11,43, 1,33, 9,41, 51,19,59,27,49,17,57,25,
           15,47, 7,39,13,45, 5,37, 63,31,55,23,61,29,53,21 ];
  function cl(v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }
  // 抖动偏移(8bit 空间): R/B 相邻级步长 = 256/32 = 8, G = 256/64 = 4; 取 ±半级
  function off(on, x, y) { return on ? (B[((y & 7) << 3) | (x & 7)] / 64 - 0.5) : 0; }

  window.DITH = {
    // 转 RGB565 大端裸字节(与固件 DRAW_TILE 的发送顺序严格一致)
    //   ★不是 >>3 >>2(那是向下取整, 渐变必糊成台阶): 先加"四舍五入 + 抖动偏移"再截断。
    to565: function (d, w, h, on) {
      var o = new Uint8Array(w * h * 2), p = 0, i = 0;
      for (var y = 0; y < h; y++) {
        for (var x = 0; x < w; x++, i += 4) {
          var t = off(on, x, y);
          var r = cl(d[i] + t * 8), g = cl(d[i + 1] + t * 4), b = cl(d[i + 2] + t * 8);
          var v = ((((r + 4) >> 3) << 11) | (((g + 2) >> 2) << 5) | ((b + 4) >> 3)) & 0xFFFF;
          o[p++] = v >> 8;                  // 高字节先
          o[p++] = v & 0xFF;
        }
      }
      return o;
    },
    // 预览: 就地把 canvas 按真实 5/6/5 量化, 再把 bit 位复制展回 8bit 显示(与面板 DAC 一致)。
    //   不这么做预览会比真机好看, 用户会以为"没救"。
    preview: function (c, w, h, on) {
      var im; try { im = c.getImageData(0, 0, w, h); } catch (e) { return; }
      var d = im.data, p = 0;
      for (var y = 0; y < h; y++) {
        for (var x = 0; x < w; x++, p += 4) {
          var t = off(on, x, y);
          var r5 = (cl(d[p] + t * 8) + 4) >> 3;
          var g6 = (cl(d[p + 1] + t * 4) + 2) >> 2;
          var b5 = (cl(d[p + 2] + t * 8) + 4) >> 3;
          d[p] = (r5 << 3) | (r5 >> 2); d[p + 1] = (g6 << 2) | (g6 >> 4); d[p + 2] = (b5 << 3) | (b5 >> 2);
        }
      }
      c.putImageData(im, 0, 0);
    }
  };
})();
