/* rb.js —— "在线搜索电台(radio-browser.info)"卡片(2026-10-20 新增)
 *
 * 【它做什么】在"网络电台"页里加一张卡: 关键词搜索 / 热门 / 中国电台, 结果可"试听"或"加入"本机列表。
 *
 * ★为什么独立成一个资源: app.js 的 gzip 已贴 4800B 单次响应水位(见 gen_page_gz.py 顶部),
 *   搜索框 + 结果列表 + 轮询逻辑塞进去必超限 -> "后台打不开"。index.html 只放空壳
 *   <div class="card" id="rbbox"></div>, 本文件建卡。
 *
 * ★为什么不一次请求拿结果: 设备端 HTTPS 拉取要 1~10 秒, 放在 HTTP 回调里会把整个
 *   Web/WS 卡住(页面"点了没反应")。固件做法是"置请求 -> 主循环拉 -> 快照", 所以这里:
 *     POST /api/rb/search  -> 立刻返回
 *     GET  /api/rb/result  -> 每 700ms 轮询, state 变 done/err 即停
 */
(function () {
  'use strict';
  var box = document.getElementById('rbbox');
  if (!box) return;

  var busy = false, timer = null;

  box.innerHTML =
    '<div class="card">' +
      '<h1>🌐 在线搜索电台</h1>' +
      '<div class="sub">数据来自 radio-browser.info(免 Key, 社区维护)。搜索约 1~10 秒, 播放中可能短暂卡顿。</div>' +
      '<div class="row" style="margin-top:8px">' +
        '<input id="rbQ" placeholder="电台名: jazz / 新闻 / cctv">' +
        '<button class="btn" id="rbGo" style="flex:0 0 84px">搜索</button>' +
      '</div>' +
      '<div class="row" style="margin-top:8px">' +
        '<button class="btn sec sm" id="rbTop">🔥 热门</button>' +
        '<button class="btn sec sm" id="rbCn">🇨🇳 中国电台</button>' +
      '</div>' +
      '<div class="sub" id="rbSt" style="margin-top:8px"></div>' +
      '<div id="rbList"></div>' +
    '</div>';

  var $ = function (id) { return document.getElementById(id); };
  function setSt(t) { var e = $('rbSt'); if (e) e.textContent = t || ''; }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }
  function tip(m, err) { if (typeof toast === 'function') toast(m, err ? 'err' : ''); }

  function get(url, cb) {
    fetch(url).then(function (r) { return r.json(); }).then(cb).catch(function () {
      setSt('✗ 请求失败(网络中断或设备忙)'); busy = false;
    });
  }
  function post(url, params, cb) {
    var body = Object.keys(params).map(function (k) {
      return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]);
    }).join('&');
    fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body
    }).then(function (r) { return r.json(); }).then(cb).catch(function () {
      tip('请求失败', true); busy = false;
    });
  }

  function render(items) {
    var h = '';
    if (!items.length) { h = '<div class="sub">没有结果</div>'; $('rbList').innerHTML = h; return; }
    h = '<div class="row" style="margin-top:10px;font-size:12px;opacity:.7">' +
        '<span style="flex:1">共 ' + items.length + ' 条</span></div>';
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      h += '<div class="row" style="margin-top:8px;align-items:center;gap:6px">' +
             '<div style="flex:1;min-width:0">' +
               '<div style="font-size:14px;word-break:break-all">' + esc(it.n) + '</div>' +
               '<div class="sub" style="font-size:11px">' + esc(it.m) + '</div>' +
             '</div>' +
             '<button class="btn sm sec" data-try="' + i + '">试听</button>' +
             '<button class="btn sm" data-add="' + i + '">加入</button>' +
           '</div>';
    }
    $('rbList').innerHTML = h;

    $('rbList').querySelectorAll('[data-try]').forEach(function (b) {
      b.onclick = function () {
        var i = +b.getAttribute('data-try');
        b.disabled = true;
        post('/api/rb/play', { i: i }, function (j) {
          b.disabled = false;
          tip(j.ok ? '已切到试听' : (j.msg || '失败'), !j.ok);
        });
      };
    });
    $('rbList').querySelectorAll('[data-add]').forEach(function (b) {
      b.onclick = function () {
        var i = +b.getAttribute('data-add');
        b.disabled = true;
        post('/api/rb/add', { i: i }, function (j) {
          b.disabled = false;
          tip(j.ok ? (j.msg || '已加入') : (j.msg || '失败'), !j.ok);
          // 加入成功 -> 电台列表由主循环修正后推送, 这里不用手动刷新表格
        });
      };
    });
  }

  function poll() {
    clearTimeout(timer);
    get('/api/rb/result', function (j) {
      if (j.state === 'running') { setSt('搜索中… 请稍候'); timer = setTimeout(poll, 700); return; }
      busy = false;
      if (j.state === 'err') { setSt('✗ ' + (j.err || '搜索失败')); $('rbList').innerHTML = ''; return; }
      setSt('✓ 完成(' + (j.n || 0) + ' 条)');
      render(j.items || []);
    });
  }

  function start(mode, q) {
    if (busy) { tip('上一次搜索还没结束', true); return; }
    busy = true;
    setSt('提交请求…');
    $('rbList').innerHTML = '';
    get('/api/rb/search?mode=' + encodeURIComponent(mode) + '&q=' + encodeURIComponent(q || ''), function (j) {
      if (!j.ok) { busy = false; setSt('✗ ' + (j.msg || '失败')); return; }
      poll();
    });
  }

  $('rbGo').onclick = function () { start('name', $('rbQ').value.trim()); };
  $('rbQ').onkeydown = function (e) { if (e.key === 'Enter') $('rbGo').onclick(); };
  $('rbTop').onclick = function () { start('top', ''); };
  $('rbCn').onclick = function () { start('cn', ''); };
})();
