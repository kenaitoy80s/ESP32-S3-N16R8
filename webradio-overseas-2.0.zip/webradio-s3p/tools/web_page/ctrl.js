/* ctrl.js —— "控制"标签页的"设备控制(等效遥控)"卡片(2026-10-16 新增)
 *
 * 【它做什么】把设备现有的所有遥控动作做成网页按钮, 与遥控器一一对应、完全等价:
 *   上一台/下一台/播放暂停/音量±/关机开机/屏幕旋转/切换屏幕/音源切换/定时关机。
 *   (本工程无 6686, 故没有"音源循环/频段循环"两键; 有【切换屏幕】键 —— 四屏位主线。)
 *
 * ★为什么独立成一个资源: app.js 的 gzip 已贴近 4800B 单次响应安全水位(见 gen_page_gz.py
 *   顶部说明), 这些按钮 + 说明塞进去必超限 -> "后台打不开"。与 sd.js/bg.js 同理。
 *   index.html 里只放空壳 <div id="ctrlbox"></div>, 本文件建卡。
 *
 * ★与 app.js 的协作只经一个全局函数: wsSend()。每个按钮 wsSend('act=xxx'),
 *   设备端 ir_web_trigger() 复用遥控派发(投递到主循环执行) —— 网页按钮 = 遥控器等价。
 */
(function () {
  'use strict';
  var box = document.getElementById('ctrlbox');
  if (!box) return;

  // [动作名, 中文标签, 悬停备注]
  var A = [
    ['prev', '⏮ 上一台', ''],
    ['next', '下一台 ⏭', ''],
    ['toggle', '▶/⏸ 播放暂停', ''],
    ['volup', '🔊 音量+', ''],
    ['voldown', '🔉 音量-', ''],
    ['power', '⏻ 关机/开机', '待机态=开机, 其它=关机'],
    ['rotate', '↻ 屏幕旋转', '每按顺时针 90°'],
    ['screen', '🖵 切换屏幕', 'ST7567→SSD1306→ST7789→ILI9341'],
    ['sd', '💿 音源切换', '网络电台 ↔ 本地SD'],
    ['timer', '⏱ 定时关机', '关闭/1h…12h 循环']
  ];

  var btns = '';
  for (var i = 0; i < A.length; i++) {
    btns += '<button class="btn sm" data-act="' + A[i][0] + '" title="' + A[i][2] + '">' + A[i][1] + '</button>';
  }
  box.innerHTML =
    '<div class="card">' +
    '<h1>🎛 设备控制（等效遥控）</h1>' +
    '<div class="sub">以下按钮与遥控器一一对应, 点一下等于按一下遥控键。</div>' +
    '<div class="row" style="flex-wrap:wrap;gap:8px;margin-top:8px">' + btns + '</div>' +
    '</div>';

  // 绑定: 每个按钮经 app.js 的全局 wsSend() 发送 act=<动作名>
  box.querySelectorAll('button[data-act]').forEach(function (b) {
    b.onclick = function () { wsSend('act=' + b.getAttribute('data-act')); };
  });
})();
