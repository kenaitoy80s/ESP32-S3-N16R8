// 屏幕"元素配色"(2026-10-10 由 tyio 分支移植): 每个显示元素单独选颜色, 与"显示设置"卡共用"应用"按钮。
// ★为什么独立成文件: app.js 的 gzip 已顶到 4800B 水位(本工程实测 4633B, 只剩 167B), 新逻辑一律另开资源。
// ★三张表必须与固件【一一对应】, 改一边就要改另一边:
//     PAL -> src/ui/display_ui.cpp 的 kElemPalette[]
//     EL  -> src/ui/display_ui.h   的 ELEM_* 枚举
//     BG  -> src/ui/display_ui.cpp 的 kBgPalette[]  (卡通背景色, 2026-10-16 移植)
(function(){
const $=id=>document.getElementById(id);
const PAL=['白','黑','红','绿','蓝','黄','青','洋红','橙','浅灰','深灰','深蓝','深绿','紫'];
const EL=['顶栏(日期/农历)','大时钟','天气/湿度','电台名','节目信息','播放状态/码率','WiFi信号','音量条','本机IP','电量/睡眠','电台列表','边框/进度条'];
const BG=['淡蓝天空','薄荷绿','奶油白','樱花粉','薰衣草','蜜桃橙','深夜蓝','纯白'];
const N=EL.length;

function build(){
  const box=$('elemColors'); if(!box)return;
  const o=PAL.map((c,i)=>'<option value="'+i+'">'+c+'</option>').join('');
  let h='<div style="font-size:12px;color:#666;margin:2px 0">各元素颜色(浅色背景看不清就把字改成深色)</div>';
  for(let i=0;i<N;i++)
    h+='<div style="display:flex;align-items:center;gap:6px;margin-top:5px">'
     + '<span style="flex:1;font-size:13px">'+EL[i]+'</span>'
     + '<select id="ec'+i+'" style="padding:5px;border:1px solid #ccc;border-radius:8px;font-size:13px">'+o+'</select></div>';
  // ★卡通背景色(2026-10-16 移植): bit=0 且未上传背景图时的整屏底色(仅彩屏; 单色屏无效)。
  h+='<div style="display:flex;align-items:center;gap:6px;margin-top:5px">'
   + '<span style="flex:1;font-size:13px">背景色(仅彩屏)</span>'
   + '<select id="bgc" style="padding:5px;border:1px solid #ccc;border-radius:8px;font-size:13px">'
   + BG.map((c,i)=>'<option value="'+i+'">'+c+'</option>').join('')+'</select></div>';
  box.innerHTML=h;
  for(let i=0;i<N;i++){const s=$('ec'+i);if(s)s.onchange=()=>{window.dirty('ec'+i);};}
  {const s=$('bgc');if(s)s.onchange=()=>{window.dirty('bgc');};}
}

// ---- "改过还没保存"保护(本工程的 app.js 没有 tyio 那套 dz 脏标记, 这里自己实现) ----
// 背景: 页面每 3s 拉 /api/state 并把控件回填成设备当前值。于是"选完屏型 -> 转去改颜色 -> 3s 一到
//   屏型被冲回旧值 -> 点保存只发出最后动的那个"。tyio 是在 app.js 里加 dz 解决的,
//   但本工程 app.js 已无余量, 故在 color.js 里【劫持 window.state】: 每次轮询回填结束后,
//   立刻把用户改过但未保存的值覆盖回去 —— 不改动 app.js 一个字节。
window.dz=window.dz||{};
window.dirty=function(id){window.dz[id]=1;const h=$('dispDirty');if(h)h.style.display='inline';};
function restore(){
  for(const id in window.dz){
    if(!window.dz[id])continue;
    if(id.indexOf('ec')!==0&&id!=='bgc')continue;      // 只管本文件建的下拉(元素色 + 背景色)
    const want=window.dz[id];
    const s=$(id); if(s&&s.value!==String(want))s.value=want;
  }
}
// 记录"用户改过"的值(不只是标记, 存具体值才能被回填冲掉后再恢复)
function bind(i){
  const s=$('ec'+i); if(!s)return;
  s.addEventListener('change',function(){window.dz['ec'+i]=s.value;
    const h=$('dispDirty');if(h)h.style.display='inline';});
}
function bindBg(){
  const s=$('bgc'); if(!s)return;
  s.addEventListener('change',function(){window.dz['bgc']=s.value;
    const h=$('dispDirty');if(h)h.style.display='inline';});
}
// ★★关键: 回填要走【applyState】这条线, 不能自己去 fetch /api/state ——
//   app.js 的 applyState(d) 收到的是已经解析好的 JSON, 直接挂在它后面就能拿到 d.ecol,
//   全程不碰 app.js 一个字节(它只剩 167B 余量, 加一行就爆水位)。
function hookState(){
  if(typeof applyState==='function'){
    const orig=applyState;
    window.applyState=function(d){orig(d);if(d&&d.ecol)window.elemColorsSet(d.ecol);if(d&&d.bg!==undefined)window.bgSet(d.bg);restore();};
  }
  if(typeof state==='function'){          // 首帧也要触发一次(不等 3s 轮询)
    const orig2=state;
    window.state=async function(){await orig2.apply(this,arguments);restore();};
  }
}
function csv(){
  const a=[];
  for(let i=0;i<N;i++){
    const s=$('ec'+i);
    const d=window.dz['ec'+i];
    a.push(typeof d!=='undefined'?d:(s?s.value:0));
  }
  return a.join(',');
}
window.elemColorsSet=function(v){          // 设备值回填(没有脏标记的才回填)
  if(!v||!v.length)return;
  for(let i=0;i<N&&i<v.length;i++){
    const s=$('ec'+i); if(!s)continue;
    if(document.activeElement===s)continue;
    if(window.dz['ec'+i])continue;
    s.value=v[i];
  }
};
// 卡通背景色回填(2026-10-16): 与 elemColorsSet 同一套"正被操作/改过未存不覆盖"语义。
window.bgSet=function(v){
  const s=$('bgc'); if(!s)return;
  if(document.activeElement===s)return;
  if(window.dz['bgc'])return;
  s.value=v;
};

// 接管"应用显示设置": 一次性把【屏型+对比度+旋转+背光+亮度+反色+各元素颜色+卡通背景色】全发出去,
// 于是"选屏型 -> 勾反色 -> 调亮度 -> 挑好几个颜色 -> 只点一次保存"就全部生效。
// ★段数与 web_server.cpp 的 disp= 解析一致: type||ctr||rot||bl||brg||inv||ecol||bg (8 段, 2026-10-16 起)。
$('bDisp').onclick=function(){
  wsSend('disp='+$('scrType').value+'||'+$('ctr').value+'||'+$('scrRot').value+'||'+$('scrBL').value+'||'+$('brg').value
        +'||'+(+$('stInv').checked)+'||'+csv()+'||'+$('bgc').value);
  window.dz={};                       // 已下发 -> 解除保护, 让轮询回填设备真实值
  const h=$('dispDirty');if(h)h.style.display='none';
  toast('已发送显示设置…');
};

build();
for(let i=0;i<N;i++)bind(i);
bindBg();
hookState();
if(typeof state==='function')state();   // 立即拉一次状态, 免得等 3s 轮询才把颜色填上
})();
