/* 固件升级 —— 2026-10-07
 * 放在"设置"页里的一张卡(与 snd.js 同样由 index.html 挂个空壳容器, 本文件负责填充)。
 *
 * 【升级怎么走的】手机/电脑选一个 .bin -> 经【局域网】POST 给设备 -> 设备把新固件写进
 *   【空闲的 ota_1 分区】-> 校验通过才把启动目标切过去 -> 自动重启。
 *   ★全程不连任何外部服务器 —— 浏览器就是"服务器", 设备只监听自己的 80 端口。
 * 【为什么不会变砖】新固件写在【另一块】分区, 旧固件全程完好; 中途断电 / 断网 / 文件不完整,
 *   结果都只是"这次没升成", 设备照旧跑老版本。只有 Update.end() 校验通过才会切换。
 * 【要传哪个文件】构建目录里的 webradio-s3p.ino.bin(约 2MB) —— 只含【应用】那一段。
 *   ★不要传名字带 -full 的整片包(含 bootloader + 分区表, 是给空板线刷用的):
 *     那种包开头是 bootloader, 写进 app 分区后启动必失败。设备端已加识别 ——
 *     传了会当场被拒(不会写进去), 本页轮询到失败也会立即中断上传, 不用白等。
 *   ★也不要在同一级别的地方找 bootloader / partitions 那两个文件, 它们不是应用固件。
 * 【本版免密】升级不再需要密码(见 config.h 的 FW_VERSION 与 OTA 段说明)。
 *
 * ★为什么独立成一个 js 文件: app.js 的 gzip 已逼近 4800B 单次响应安全水位, 再往里塞任何东西
 *   都会超水位、导致"后台打不开"。本文件与 bg.js / wifi.js / sd.js / listop.js / snd.js 同理。
 */
(function () {
  'use strict';
  var box = document.getElementById('otabox');
  if (!box) return;

  box.innerHTML =
    '<div class="sub" id="otaCur">当前固件: 读取中…</div>' +
    '<div class="row" style="margin-top:8px"><input type="file" id="otaFile" accept=".bin"></div>' +
    '<div class="row" style="margin-top:8px"><button class="btn" id="otaGo">开始升级</button></div>' +
    '<div class="sub" id="otaMsg" style="margin-top:6px"></div>' +
    '<progress id="otaBar" value="0" max="100" style="width:100%;margin-top:6px;display:none"></progress>';

  var el = function (id) { return document.getElementById(id); };
  var busy = false;          // 升级进行中: 防止重复点击
  var uploadDone = false;    // 浏览器侧传完了没(传完才由 /api/ota/progress 接管进度显示)
  var poller = null;
  var curXhr = null;         // 当前上传的 XHR(后端提前判失败时用它中断, 免得白等)

  function setMsg(t) { el('otaMsg').textContent = t; }

  // 当前固件的版本号 + 构建时间(版本号来自 config.h 的 FW_VERSION)
  fetch('/api/version').then(function (r) { return r.json(); }).then(function (j) {
    el('otaCur').textContent = '当前固件: ' +
      (j.ver ? j.ver + '   (构建 ' + (j.build || '?') + ')' : (j.build || '未知'));
  }).catch(function () { el('otaCur').textContent = '当前固件: 读取失败'; });

  // 后端状态轮询: ① 后端提前判失败(如传的是整片包) -> 立刻中断上传; ② 上传完成后画写 flash 进度
  function pollProgress() {
    fetch('/api/ota/progress').then(function (r) { return r.json(); }).then(function (j) {
      if (j.err) {                                   // 后端已判失败 -> 不必把整个包传完
        if (poller) { clearInterval(poller); poller = null; }
        if (curXhr) { try { curXhr.abort(); } catch (e) {} }
        busy = false; el('otaGo').disabled = false;
        setMsg('✗ 升级失败: ' + (j.msg || '') + ' —— 设备仍在跑旧固件, 可重试');
        return;
      }
      if (!uploadDone || !j.total) return;
      var pct = Math.floor(j.done * 100 / j.total);
      el('otaBar').value = pct;
      setMsg('写入 flash 中 ' + pct + '%  (' +
             Math.floor(j.done / 1024) + ' / ' + Math.floor(j.total / 1024) + ' KB) —— 请勿断电');
    }).catch(function () { /* 设备正在忙, 读不到就跳过这一轮 */ });
  }

  el('otaGo').addEventListener('click', function () {
    if (busy) return;
    var f = el('otaFile').files[0];
    if (!f) { setMsg('先选择一个固件文件(.bin)'); return; }
    if (!confirm('确定把 ' + f.name + ' (' + Math.floor(f.size / 1024) + ' KB) 刷进设备?\n\n' +
                 '升级期间请勿断电; 写完后设备会自动重启。')) return;

    busy = true;
    uploadDone = false;
    el('otaGo').disabled = true;
    el('otaBar').style.display = '';
    el('otaBar').value = 0;
    setMsg('上传中… 请勿关闭本页');

    // 用 XHR 而不是 fetch: 多一个 upload.onprogress, 能把"上传"这一段也画进进度条
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/ota');
    xhr.setRequestHeader('Content-Type', 'application/octet-stream');
    xhr.upload.onprogress = function (e) {
      if (!e.lengthComputable || uploadDone) return;
      var p = Math.floor(e.loaded * 100 / e.total);
      el('otaBar').value = p;
      setMsg('上传中 ' + p + '%');
    };
    xhr.upload.onload = function () {
      uploadDone = true;
      setMsg('固件已送达, 正在写入 flash —— 请勿断电');
    };
    xhr.onload = function () {
      if (poller) { clearInterval(poller); poller = null; }
      curXhr = null;
      var j = {};
      try { j = JSON.parse(xhr.responseText); } catch (e) {}
      if (xhr.status === 200 && j.ok) {
        el('otaBar').value = 100;
        // 这里【不】解锁 busy: 就是要让用户知道"正在进行中, 别乱点"
        setMsg('★ 升级成功, 设备正在重启… 约 10 秒后刷新页面');
        return;
      }
      busy = false; el('otaGo').disabled = false;
      setMsg('✗ 升级失败: ' + (j.msg || ('HTTP ' + xhr.status)) + ' —— 设备仍在跑旧固件, 可重试');
    };
    xhr.onerror = function () {
      if (poller) { clearInterval(poller); poller = null; }
      curXhr = null;
      busy = false; el('otaGo').disabled = false;
      setMsg('✗ 上传中断(网络断了?) —— 设备仍在跑旧固件, 可重试');
    };
    curXhr = xhr;
    xhr.send(f);

    poller = setInterval(pollProgress, 500);
  });
})();
