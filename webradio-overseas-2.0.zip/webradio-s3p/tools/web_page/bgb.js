/* 背景图亮度(0~100) —— 独立小资源(2026-10-10 加)。
 * ★为什么单独成文件: bg.js 的 gzip 已顶到 4800B 水位(实测 4663, 只剩 137B 余量),
 *   这个滑块+提示再塞进去必然超限(超限 -> 该资源要多轮续传, 音频抢网时卡死 = "后台打不开")。
 *   照 ota.js / color.js 的做法拆成独立资源; 拆出后 bg.js 一字节都不用改。
 * 职责: 只有这一个滑块 + 一个 POST。预览亮度用 CSS filter 直接加在 bg.js 建好的两张
 *       <canvas id="bgc_l/bgc_p"> 上 —— 纯视觉, 不碰 bg.js 的绘制逻辑, 也不影响它重画。
 * ★与"界面不透明度"(bg.js 里的 bga)是两回事: 那个混的是【界面层】, 这个只压暗【背景图本身】。
 */
(function () {
  'use strict';
  var box = document.getElementById('bgbox');
  if (!box) return;                         // 本页没挂上(bg.js 未跑) -> 什么都不做

  var d = document.createElement('div');
  d.className = 'card';
  d.style.marginTop = '14px';
  d.innerHTML = '<h1>背景图亮度</h1>' +
    '<div class="hint">只压暗【背景图自己】的明暗 —— 不是屏幕亮度(那在"显示设置"里), 也不是' +
    '上面的界面不透明度。照片太亮、白字看不清时往下拉; 界面文字/边框的颜色不受影响。100% = 原图。' +
    '<br>预览是用滤镜压的, 连白色示意框也会一起变暗, 真机上只有底图变暗、文字不变。</div>' +
    '<div style="margin-top:8px">亮度 <b id="bgbv">100%</b>' +
    '<input type="range" id="bgb" min="0" max="100" step="5" value="100" style="width:100%;margin:4px 0">' +
    '<button class="btn sm" id="bgbUp">应用到设备</button> <span id="bgbm" style="font-size:13px"></span></div>';
  box.appendChild(d);

  function el(id) { return document.getElementById(id); }
  var sl = el('bgb'), lb = el('bgbv'), ms = el('bgbm');

  // 只改预览: 给两张预览 canvas 套 brightness 滤镜(值由滑块决定; 100% 时等于原样)
  function preview(v) {
    lb.textContent = v + '%';
    ['bgc_l', 'bgc_p'].forEach(function (id) {
      var c = el(id);
      if (c) c.style.filter = (v >= 100) ? '' : ('brightness(' + v + '%)');
    });
  }

  sl.addEventListener('input', function () { preview(+this.value); ms.textContent = ''; });

  el('bgbUp').addEventListener('click', function () {
    var v = +sl.value;
    var fd = new FormData(); fd.append('v', v);
    ms.textContent = '发送中…';
    fetch('/api/bg/bright', { method: 'POST', body: fd })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (j && j.ok) ms.textContent = '已设为 ' + v + '%(设备重读底图, 约 1 秒)';
        else ms.innerHTML = '<b style="color:#c0392b">设置失败</b>';
      })
      .catch(function () { ms.innerHTML = '<b style="color:#c0392b">设置失败(网络)</b>'; });
  });

  // 回填设备当前值(读 /api/state; 与其它标签页一样纯只读)
  fetch('/api/state').then(function (r) { return r.json(); }).then(function (j) {
    if (j && j.bgBright !== undefined && j.bgBright !== null) { sl.value = j.bgBright; preview(j.bgBright); }
  }).catch(function () {});
})();
