/* SBR 开关 —— 2026-10-07
 * 放在"设置"页里的一张卡(用户要求: 不单独一个标签页, 且只留开关、不要说明文字)。
 *
 * 【SBR 是什么】SBR(Spectral Band Replication)是 HE-AAC 的高频重建技术:
 *   让解码器在核心采样率 48kHz 之上重建出到 24kHz 的高频, 于是【输出采样率翻倍成 96kHz】。
 * 【为什么要能关】I2S 的 DMA 深度固定(32 x 512 帧 = 16384 帧):
 *   48kHz -> 372ms 余量, 96kHz -> 【只有 170ms】。
 *   实测有些电台服务器是突发式推包(约 200ms 来一个包), 200ms > 170ms
 *   => 每个突发必然排空 DMA => 听感是规律性的【发颤】(不是断续)。
 *   关掉后输出回到 48kHz、余量 372ms, 同一台由发颤变流畅。
 * ★只对 audio/aacp (HE-AAC) 的台有作用; 普通 aac / mp3 台根本不触发 SBR, 开关怎么设都一样。
 * ★切换【换台后生效】: 解码器状态在建流那一刻就定了。
 *
 * ★为什么独立文件: app.js 的 gzip 已逼近 4800B 单次响应安全水位, 再往里塞会超水位、
 *   导致后台打不开。本文件与 bg.js/wifi.js/sd.js/listop.js 同理。
 */
(function () {
  'use strict';
  var box = document.getElementById('sndbox');
  if (!box) return;

  box.innerHTML =
    '<div class="row" style="align-items:center">' +
    '<label style="display:flex;align-items:center;gap:6px;font-size:14px">' +
    '<input type="checkbox" id="sbrOn"> SBR 高频重建</label>' +
    '<button class="btn sm" id="sndApply" style="margin-left:auto">应用</button>' +
    '<span class="sub" id="sndMsg" style="margin-left:6px"></span></div>';

  var el = function (id) { return document.getElementById(id); };
  var known = false;

  function poll() {
    fetch('/api/state').then(function (r) { return r.json(); }).then(function (j) {
      if (typeof j.sbr === 'undefined') {
        el('sbrOn').disabled = true;
        el('sndMsg').textContent = '固件较旧, 请重新编译烧录';
        return;
      }
      known = true;
      // 不覆盖用户刚点的选择: 只有当复选框没有焦点时才回填
      if (document.activeElement !== el('sbrOn')) el('sbrOn').checked = !!j.sbr;
    }).catch(function () { /* 读不到就静默, 不刷错误文案 */ });
  }

  el('sndApply').addEventListener('click', function () {
    if (!known) { el('sndMsg').textContent = '还没读到设备状态'; return; }
    var v = el('sbrOn').checked ? 1 : 0;
    // 走 WebSocket: 与其它控制指令同一通路(cmd=val)。连不上时靠串口 A 命令兜底。
    try {
      var s = new WebSocket('ws://' + location.host + '/ws');
      s.onopen = function () {
        s.send('sbr=' + v);
        el('sndMsg').textContent = '已下发, 换台后生效';
        setTimeout(function () { s.close(); }, 300);
        setTimeout(poll, 600);
      };
      s.onerror = function () { el('sndMsg').textContent = '下发失败(可用串口 A)'; };
    } catch (e) { el('sndMsg').textContent = '下发失败(可用串口 A)'; }
  });

  poll();
  setInterval(poll, 4000);
})();