#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
抓 5 个频道的 ICY 原始标题, 逐条用固件的 icyToUtf8 算法判定 ——
看上游是不是"换歌时偶尔发坏字节", 以及坏字节会被固件解成什么。
"""
import os
import socket
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sim_icytoutf8 import icy_to_utf8          # noqa: E402  复用同一份算法

HOST, PORT = "183.220.53.251", 7999
CHANNELS = ["/01", "/02", "/03", "/04", "/05"]
SECONDS = 24


def fetch_titles(path, seconds):
    """连上流, 收集该时段内出现过的所有不同 StreamTitle 原始字节"""
    outs, buf = [], b""
    try:
        s = socket.create_connection((HOST, PORT), timeout=8)
        s.settimeout(8)
        s.sendall(("GET %s HTTP/1.0\r\nHost: %s:%d\r\nIcy-MetaData: 1\r\n"
                   "User-Agent: probe\r\nAccept: */*\r\n\r\n" % (path, HOST, PORT)).encode())
        # 读头
        while b"\r\n\r\n" not in buf:
            c = s.recv(4096)
            if not c:
                raise RuntimeError("读头时连接被关")
            buf += c
        head, buf = buf.split(b"\r\n\r\n", 1)
        metaint = None
        for ln in head.decode("latin-1").split("\r\n"):
            if ln.lower().startswith("icy-metaint:"):
                metaint = int(ln.split(":", 1)[1])
        if not metaint:
            s.close()
            return ["<无 icy-metaint>"], []
        t0 = time.time()
        while time.time() - t0 < seconds:
            need = metaint
            while len(buf) < need + 1:
                c = s.recv(65536)
                if not c:
                    raise RuntimeError("流中断")
                buf += c
            buf = buf[need:]                     # 丢音频
            lb, buf = buf[:1], buf[1:]
            mlen = lb[0] * 16
            while len(buf) < mlen:
                c = s.recv(65536)
                if not c:
                    raise RuntimeError("流中断(元数据)")
                buf += c
            meta, buf = buf[:mlen], buf[mlen:]
            a = meta.find(b"StreamTitle='")
            if a >= 0:
                e = meta.find(b"'", a + 13)
                if e > a:
                    t = meta[a + 13:e]
                    if t not in outs:
                        outs.append(t)
        s.close()
    except Exception as ex:
        outs.append(("<错误: %s>" % ex).encode())
    return outs, None


print("=" * 96)
for ch in CHANNELS:
    titles, _ = fetch_titles(ch, SECONDS)
    print("\n### %s  (%ds 内共 %d 条不同标题)" % (ch, SECONDS, len(titles)))
    for raw in titles:
        if raw.startswith(b"<"):
            print("   %s" % raw.decode("utf-8", "replace"))
            continue
        out, enc = icy_to_utf8(raw)
        flag = "原样" if out == raw else "★被改写"
        try:
            shown = out.decode("utf-8")
        except Exception:
            shown = repr(out)
        print("   判定=%-12s %s" % (enc, flag))
        print("     原始 hex : %s" % raw.hex(" "))
        print("     上游原文 : %s" % raw.decode("utf-8", "replace"))
        if out != raw:
            print("     固件输出 : %s" % shown)
print("=" * 96)
