#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成 gbk_rev_tab.h —— Unicode 码点 -> GBK 双字节码 的反查表。

为什么需要它(2026-10-06):
  部分 Icecast 上游把【UTF-8 的标题字节按 GBK 两两切开解码】再以 UTF-8 发出,
  即"双重编码"(double-encoded / mojibake)。
  例: "张玮伦" 的 UTF-8 是 E5 BC A0 E7 8E AE E4 BC A6,
      上游按 GBK 每 2 字节切开 -> 寮 犵 幃 浼 + 1 个残字节, 屏上就成 "寮犵幃浼?"。
  设备端要还原, 就得把每个字符【重新按 GBK 编码】拿回原始字节, 再按 UTF-8 解码。
  这个"字符 -> GBK 字节"的动作需要一张反查表(正向表 gGb2312Uni 只有 GB2312, 不够)。

表结构: 按 Unicode 码点升序的一维交错数组 [uni0, gbk0, uni1, gbk1, ...], 供二分查找。
体积:   约 2.2 万项 x 4B = 约 86KB, 放 flash(.rodata), 不占 RAM。
"""
import os
import sys

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "data", "gbk_rev_tab.h")


def build():
    pairs = {}
    for hi in range(0x81, 0xFF):
        for lo in range(0x40, 0xFF):
            if lo == 0x7F:                      # GBK 次字节不含 0x7F
                continue
            try:
                ch = bytes([hi, lo]).decode("gbk")
            except Exception:
                continue
            if len(ch) != 1:
                continue
            cp = ord(ch)
            if cp > 0xFFFF:
                continue
            # 同一 Unicode 可能有多个 GBK 码位 -> 保留最小的那个(与原表方向一致)
            if cp not in pairs or ((hi << 8) | lo) < pairs[cp]:
                pairs[cp] = (hi << 8) | lo
    return sorted(pairs.items())


def emit(items, path):
    lines = []
    lines.append("// ======== 本文件由 tools/gen_gbk_rev_tab.py 自动生成, 请勿手改 ========")
    lines.append("// 用途: Unicode 码点 -> GBK 双字节码(反查), 供 audio_player.cpp 还原")
    lines.append("//       \"上游把 UTF-8 字节按 GBK 解码\"造成的双重编码乱码(见脚本注释)。")
    lines.append("// 结构: 按码点升序的交错数组 [uni0, gbk0, uni1, gbk1, ...], 二分查找。")
    lines.append("// 覆盖: GBK 全部 %d 个可编码字符。改完重跑: python tools/gen_gbk_rev_tab.py" % len(items))
    lines.append("#pragma once")
    lines.append("#include <stdint.h>")
    lines.append("")
    lines.append("#define GBK_REV_N %d" % len(items))
    lines.append("")
    lines.append("static const uint16_t gGbkRev[GBK_REV_N * 2] = {")
    row = []
    for cp, g in items:
        row.append("0x%04X,0x%04X" % (cp, g))
        if len(row) == 8:
            lines.append("  " + ",".join(row) + ",")
            row = []
    if row:
        lines.append("  " + ",".join(row) + ",")
    lines.append("};")
    lines.append("")
    data = "\n".join(lines)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(data)
    return len(data)


def main():
    items = build()
    size = emit(items, OUT)
    print("GBK 反查表: %d 项" % len(items))
    print("  C++ 文本 %d B, 编译进固件约 %d B(%.1f KB)" % (size, len(items) * 4, len(items) * 4 / 1024))
    print("  输出 -> %s" % os.path.normpath(OUT))
    # 自检: 用几个双重编码里真实出现过的字符验证
    d = dict(items)
    for ch in "寮犵幃浼鎬庝箞璇存垜嶇埍娴佹槦闆":
        print("    %s -> GBK %04X" % (ch, d.get(ord(ch), 0)))


if __name__ == "__main__":
    sys.exit(main())
