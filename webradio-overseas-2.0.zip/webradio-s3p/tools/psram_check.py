# -*- coding: utf-8 -*-
"""
PSRAM 体检(2026-10-06)

背景: 屏幕背景图上传时报"内存分配失败", 根因要看 PSRAM 到底有没有启用。
      这块板子是 ESP32-S3 N16R8, 本该有 8MB(8192KB) 的八线(OPI) PSRAM。

用法:
    python tools/psram_check.py <设备IP>
    python tools/psram_check.py 192.168.2.115

判读(脚本会直接给结论):
    psramSize == 0        -> PSRAM 根本没启用。这不只是背景图不可用:
                             audio_player.cpp:317 的 512KB 音频输入缓冲也会静默退回
                             DRAM 的 16KB —— 很可能是历史"卡顿"的隐藏原因。
    psramMax < 150KB      -> PSRAM 启用了, 但碎片化严重, 拿不出 150KB 连续块。
    psramMax >= 150KB     -> PSRAM 正常, 背景图那 150KB 分配得出来。

★为什么不用"看 sdkconfig"来判断: 真正的 PSRAM 初始化代码在预编译的
  libesp_psram.a 里(按 memory_type 选 qio_opi / qio_qspi 等变体),
  build 目录 sdkconfig 里那句 CONFIG_SPIRAM_MODE_QUAD 只是宏声明, 不能作依据。
  唯一可靠的判据是设备实测 —— 也就是本脚本读的这几个数。

只依赖 Python 标准库。
"""
import json
import sys
import urllib.request

BG_NEED_KB = 150 * 1024 // 1000  # 背景图所需 153600B ≈ 150KB


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 1
    ip = sys.argv[1]
    url = 'http://%s/api/state' % ip
    print('=== PSRAM 体检: %s ===' % ip)
    try:
        with urllib.request.urlopen(url, timeout=10) as r:
            s = json.loads(r.read().decode('utf-8', 'replace'))
    except Exception as e:
        print('读不到 %s: %r' % (url, e))
        print('  -> 设备不在线 / IP 不对 / 页面是从缓存打开的')
        return 2

    if 'psramSize' not in s:
        print('设备固件里还没有 psram 字段 —— 这是【旧固件】。')
        print()
        print('两个选择:')
        print('  A) 不用重烧: 重启设备, 看串口有没有这一行(现成代码就有):')
        print('       [Audio] PSRAM: 已启用 | 总 8192KB 空闲 XXXXKB | 输入缓冲 RAM 16384B + PSRAM 524288B')
        print('     显示“已启用 / 总 8192KB”= 正常; 显示“★未启用”或总 0KB = PSRAM 没起来。')
        print('  B) 烧最新的 run_upload_s3_320.py, 然后重跑本脚本(或串口发 D 看 [MEM ] 行)。')
        return 3

    tot = s.get('psramSize', 0)
    free = s.get('psramFree', 0)
    mx = s.get('psramMax', 0)
    hfree = s.get('heapFree', 0)
    hmx = s.get('heapMax', 0)

    print('PSRAM     总 %6d KB   空闲 %6d KB   最大连续块 %6d KB' % (tot, free, mx))
    print('内部RAM   空闲 %6d KB   最大连续块 %6d KB' % (hfree, hmx))
    print('背景图需要                最大连续块 %6d KB' % BG_NEED_KB)
    print()
    if tot == 0:
        print('❌ PSRAM 未启用(总容量 0 KB) —— 这就是背景图上传失败的根因。')
        print('   附带影响: 音频那 512KB 输入缓冲也已静默退回 DRAM 的 16KB,')
        print('             这很可能是过去“卡顿”的隐藏原因之一。')
        print('   修法(按优先级):')
        print('     1) 换用 esp32s3-octal 这个 board 定义重编(它默认就是 OPI PSRAM);')
        print('     2) 显式指定 board_build.psram_type=opi;')
        print('     3) 若都无效, 再排查硬件/模组是否真是 8MB OPI。')
        return 4
    if mx < BG_NEED_KB:
        print('⚠ PSRAM 已启用, 但最大连续块(%d KB)放不下 %d KB 背景图 —— 碎片化。' % (mx, BG_NEED_KB))
        print('   ps_malloc 失败时会自动降级到内部 RAM, 而内部最大块 %d KB 也不够。' % hmx)
        return 5
    print('✅ PSRAM 正常, 能放下 %d KB 背景图。' % BG_NEED_KB)
    print('   若上传仍失败, 问题就在别处(看串口 [BG  ] 日志定位是哪一环)。')
    return 0


if __name__ == '__main__':
    sys.exit(main())
