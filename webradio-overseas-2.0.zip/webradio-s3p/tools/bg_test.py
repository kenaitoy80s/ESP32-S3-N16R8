# -*- coding: utf-8 -*-
"""
屏幕背景图上传自检工具(2026-10-06)

用途: 当后台"屏幕背景"页点上传"没反应/无效"时, 用它绕过浏览器, 直接从电脑 POST 一张
      已知的测试图到设备。这样一步就能把故障范围切开:

        本工具成功 + 网页失败  -> 问题在浏览器侧(页面缓存/JS/图源)
        两者都失败             -> 问题在设备侧或网络(看下面打印的 HTTP 状态与响应体)

用法:
    python tools/bg_test.py <设备IP>             # 默认测横屏 /api/bg/l
    python tools/bg_test.py <设备IP> p           # 测竖屏 /api/bg/p
    python tools/bg_test.py <设备IP> l --dry     # 只生成文件并打印信息, 不发请求

测试图内容: 四条彩色渐变边框 + 中央色块 —— 传成功后屏幕上应该能明显看到颜色变化,
            所以"到底有没有生效"一眼可判, 不必靠猜。

只依赖 Python 标准库, 不需要装任何东西。
"""
import sys
import urllib.request
import urllib.error

W, H = 320, 240          # 横屏; 竖屏时会在下面按方向对调
BG_BYTES = 320 * 240 * 2  # 153600, 两个方向的字节数相同


def make_test_image(w, h):
    """生成一张 RGB565(大端, 行优先) 的测试图: 彩色渐变 + 边框, 便于肉眼确认。"""
    buf = bytearray(w * h * 2)
    o = 0
    for y in range(h):
        for x in range(w):
            # 横向走红->绿, 纵向走蓝, 再压一条白边框
            r = (x * 31 // max(1, w - 1))
            g = (y * 63 // max(1, h - 1))
            b = ((x + y) * 31 // max(1, w + h - 2))
            if x < 3 or y < 3 or x >= w - 3 or y >= h - 3:
                r, g, b = 31, 63, 31                      # 白边框(纯白 = RGB565 全 1)
            v = (r << 11) | (g << 5) | b
            buf[o] = v >> 8                               # ★大端: 高字节先, 与固件一致
            buf[o + 1] = v & 0xFF
            o += 2
    return bytes(buf)


def post(ip, path, data):
    url = 'http://%s%s' % (ip, path)
    req = urllib.request.Request(url, data=data, method='POST')
    req.add_header('Content-Type', 'application/octet-stream')
    print('POST %s  (%d 字节)' % (url, len(data)))
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            body = r.read().decode('utf-8', 'replace')
            print('HTTP %s' % r.status)
            print('响应: %s' % body)
            return True
    except urllib.error.HTTPError as e:
        body = e.read().decode('utf-8', 'replace')
        print('HTTP %s  <- 设备明确拒绝了' % e.code)
        print('响应: %s' % body)
        return False
    except Exception as e:
        print('请求失败: %r' % e)
        print('  -> 设备不在线 / IP 不对 / 上传途中连接被断开(可看设备串口有没有 [BG  ] 日志)')
        return False


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 1
    ip = sys.argv[1]
    direction = (sys.argv[2].lower() if len(sys.argv) > 2 else 'l')
    dry = '--dry' in sys.argv
    portrait = (direction == 'p')
    w, h = (240, 320) if portrait else (320, 240)

    print('=== 屏幕背景上传自检 ===')
    print('设备: %s   方向: %s (%dx%d)   字节数: %d' % (ip, direction, w, h, w * h * 2))
    data = make_test_image(w, h)
    print('已生成测试图 %d 字节' % len(data))

    out = 'bg_test_%s.rgb' % direction
    with open(out, 'wb') as f:
        f.write(data)
    print('测试图已存到 %s (想用 curl 的话: curl -X POST --data-binary @%s http://%s/api/bg/%s)'
          % (out, out, ip, direction))

    if dry:
        print('(--dry: 不发请求)')
        return 0
    ok = post(ip, '/api/bg/' + direction, data)
    print()
    if ok:
        print('✅ 设备已接收。若屏幕约 2 秒后仍无变化, 看设备串口有没有:')
        print('   [BG  ] 已保存 /bg_%s.rgb ...        -> 落盘成功, 那就是显示环节的问题' % direction)
        print('   [BG  ] 丢弃不完整的上传数据 ...      -> 收流不完整')
        print('   (什么都没有)                          -> bgTick 没被调用, 检查主循环')
    else:
        print('❌ 设备侧就是失败的。把上面"响应:"那行贴出来即可定位。')
    return 0 if ok else 2


if __name__ == '__main__':
    sys.exit(main())
