# -*- coding: utf-8 -*-
"""
把网页拆成 index.html / app.css / app.js 三个源文件, 各自 gzip 后生成
web-radio/page_assets.h, 由固件以「单次小响应」逐个直供。

背景(为什么不用一整个 15.6KB 页面):
  ESPAsyncWebServer 的 send_P() 走 AsyncAbstractResponse::_ack(), 每轮最多写
  `space`(= TCP_SND_BUF ≈ 5744B) 字节, 超过就必须等下一轮 ACK 续传。音频持续占用
  网络/堆时这条续传链会卡住 -> 浏览器收不满 Content-Length 声明的字节 -> 一直转圈
  = "后台打不开"。实测: 页面 15624B, gzip 后 5959B —— 中文占比高, gzip 压不动,
  仍然 > 5744, 所以"整页单次发完"这条路走不通。
  => 改为拆成 3 个各自远小于 5744B 的 gzip 资源, 由浏览器原生 <link>/<script src>
     分别拉取。浏览器自己负责重试与并发, 不再依赖手写 JS 的 fetch 链。
     (gzip + Content-Encoding 是 ESPAsyncWebServer README 官方推荐的发送方式)

用法:
  python gen_page_gz.py --extract   # 一次性: 从 web_server.cpp 抽出三个源文件
  python gen_page_gz.py             # 常规: 由源文件生成 page_assets.h (改完页面后跑这个)
"""
import gzip
import io
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)   # webradio-s3p 工程根(此工程即 sketch 目录, 不再嵌套 web-radio/)
SRC_CPP = os.path.join(ROOT, "src", "net", "web_server.cpp")
PAGE_DIR = os.path.join(HERE, "web_page")
OUT_H = os.path.join(ROOT, "src", "net", "page_assets.h")

LIMIT = 4800  # 单次响应安全水位(TCP_SND_BUF≈5744, 留余量)
OVER = []     # 超水位的资源(生成完统一报错退出, 见 main)


def extract_from_cpp():
    """从 web_server.cpp 的内联 HTML 抽出 index.html / app.css / app.js"""
    src = open(SRC_CPP, encoding="utf-8").read()
    m = re.search(r'static const char\* HTML = R"rawliteral\((.*?)\)rawliteral";', src, re.S)
    if not m:
        sys.exit("没找到内联 HTML: web_server.cpp 里应是 static const char* HTML = R\"rawliteral(...)rawliteral\";")
    html = m.group(1)

    m_css = re.search(r"<style>(.*?)</style>", html, re.S)
    m_js = re.search(r"<script>(.*?)</script>", html, re.S)
    if not (m_css and m_js):
        sys.exit("内联 HTML 里没同时找到 <style>...</style> 与 <script>...</script>")

    css = m_css.group(1)
    js = m_js.group(1)
    # 骨架: 去掉 style/script 块, 改为外链
    skel = html[: m_css.start()] + '<link rel="stylesheet" href="/a.css">' + html[m_css.end():]
    # 重新定位 script (前面替换改变了偏移, 用重新搜索)
    m_js2 = re.search(r"<script>.*?</script>", skel, re.S)
    skel = skel[: m_js2.start()] + '<script src="/a.js"></script>' + skel[m_js2.end():]
    # 页面版本占位: gzip 固化的资源无法再做字符串替换, 由 /api/state 的 build 字段回填
    skel = skel.replace("__BUILD__", "")

    os.makedirs(PAGE_DIR, exist_ok=True)
    for name, text in (("index.html", skel), ("app.css", css), ("app.js", js)):
        p = os.path.join(PAGE_DIR, name)
        open(p, "w", encoding="utf-8", newline="\n").write(text.lstrip("\n"))
        print("抽出 %-12s -> %s" % (name, p))

    print("\n注意: 下面请手工把 web_server.cpp 里的内联 HTML/PAGE_BOOT 删掉, 改用 page_assets.h")


def gz(data: bytes) -> bytes:
    buf = io.BytesIO()
    # mtime=0: 输出可复现(不含时间戳), 避免每次生成 diff 抖动
    with gzip.GzipFile(fileobj=buf, mode="wb", compresslevel=9, mtime=0) as f:
        f.write(data)
    return buf.getvalue()


def emit(name, data, kind, lines):
    g = gz(data)
    flag = "OK " if len(g) <= LIMIT else "!! "
    print("%s%-14s 原始 %6d B -> gzip %6d B (%.1f%%)" % (flag, name, len(data), len(g), len(g) * 100.0 / len(data)))
    if len(g) > LIMIT:
        # ★必须硬失败, 不能只警告: 超过水位 -> 该资源要分多轮续传, 音频抢网时这条续传链会卡住,
        #   浏览器收不满 Content-Length -> 一直转圈 = "后台打不开"。旧版只打印警告, 构建照样过,
        #   于是这种回归一路带到烧机才被发现。这里记下来, 由 main() 统一报错退出。
        print("   超过单次响应安全水位 %d B (超 %d B)" % (LIMIT, len(g) - LIMIT))
        OVER.append((name, len(g)))
    lines.append("// %s: 原始 %d B -> gzip %d B" % (name, len(data), len(g)))
    lines.append("static const uint32_t %s_LEN = %d;" % (kind, len(g)))
    lines.append("static const uint8_t %s[%d] PROGMEM = {" % (kind, len(g)))
    row = []
    for b in g:
        row.append("0x%02X," % b)
        if len(row) == 16:
            lines.append("  " + "".join(row))
            row = []
    if row:
        lines.append("  " + "".join(row))
    lines.append("};")
    lines.append("")
    return len(g)


def main():
    if "--extract" in sys.argv:
        extract_from_cpp()
        return

    paths = {n: os.path.join(PAGE_DIR, n) for n in ("index.html", "app.css", "app.js", "listop.js", "sd.js", "snd.js", "bg.js", "bgb.js", "dith.js", "wifi.js", "ota.js", "alarm.js", "color.js", "ctrl.js", "rb.js")}
    for p in paths.values():
        if not os.path.exists(p):
            sys.exit("缺少源文件 %s —— 先跑 python gen_page_gz.py --extract" % p)

    html = open(paths["index.html"], encoding="utf-8").read()
    css = open(paths["app.css"], encoding="utf-8").read()
    js = open(paths["app.js"], encoding="utf-8").read()
    # listop.js: 电台列表"多选 + 批量设分类/批量删除"(2026-10-07 加)。
    # 独立资源: 它是【增强】app.js 已渲染好的表格(注入勾选列), 不改 app.js 一行代码。
    listopjs = open(paths["listop.js"], encoding="utf-8").read()
    # sd.js: "本地SD卡"标签页的脚本(2026-10-07 阶段② 加)。
    # 同样必须独立成资源 —— app.js 的 gzip 已逼近 4800B 水位, 且本页要的是列表渲染 +
    # 轮询 + 文件名转义, 塞进 app.js 会直接超水位导致"后台打不开"。
    sdjs = open(paths["sd.js"], encoding="utf-8").read()
    # snd.js: "音频设置"标签页(SBR 开关, 2026-10-07 加)。同样独立成资源 —— app.js 只剩百来字节余量。
    sndjs = open(paths["snd.js"], encoding="utf-8").read()
    # bg.js: "屏幕背景"标签页的脚本(2026-10-06 加)。
    # ★必须独立成一个资源: app.js 的 gzip 只剩 96B 余量, 而标签页切换是 index.html 里的
    #   通用内联脚本, 所以新页面挂两条 HTML 就能工作, 完全不用动 app.js。
    bgjs = open(paths["bg.js"], encoding="utf-8").read()
    # bgb.js: "背景图亮度"滑块的脚本(2026-10-10 加, 由 DMradio-tyio 模板同步)。
    # ★独立资源的硬原因: bg.js 的 gzip 已顶到 4800B 水位, 这个滑块+提示再塞进去必超限。
    #   ★加载顺序: index.html 里在 bg.js【之后】引入(它 append 到 bg.js 的 #bgbox,
    #     并用 bg.js 挂好的 window.BGB / window.BGB.redraw 联动预览变暗)。
    bgbjs = open(paths["bgb.js"], encoding="utf-8").read()
    # dith.js: RGB565 量化 + 8x8 Bayer 抖动 的共享库(2026-10-10 由 01 层移植)。
    # 同 bgb.js: bg.js 的 gzip 已顶水位, 那只查表+逐像素循环塞不进去, 必须独立成资源。
    dithjs = open(paths["dith.js"], encoding="utf-8").read()
    # wifi.js: "设置 -> WiFi 配网"卡片的多组凭据逻辑(2026-10-06 加)。
    # 同样独立成资源 —— 顺带把原本写在 app.js 里的那段 WiFi 提交代码删掉了, app.js 反而更小。
    wjs = open(paths["wifi.js"], encoding="utf-8").read()
    # ota.js: "设置 -> 固件升级"卡片(2026-10-07 加)。
    # 同 snd.js: 必须独立成资源 —— app.js 的 gzip 只剩几十字节余量, 上传逻辑一行都塞不下。
    otajs = open(paths["ota.js"], encoding="utf-8").read()
    # alarm.js: "设置 -> 定时开机(闹钟)"卡片(2026-10-08 加)。
    # 同 snd.js/ota.js 必须独立成资源 —— app.js 的 gzip 只剩 167B, 而这张卡要放两个
    # <input type="time"> + 一个电台下拉 + 保存逻辑, 塞进去必然超水位("后台打不开")。
    alarmjs = open(paths["alarm.js"], encoding="utf-8").read()
    # color.js: "元素配色"下拉组(2026-10-10 由 tyio 分支移植)。
    # 同 alarm.js: app.js 只剩 167B 余量, 这组 12 个下拉一行都塞不下, 必须独立成资源。
    colorjs = open(paths["color.js"], encoding="utf-8").read()
    # ctrl.js: "控制"标签页的"设备控制(等效遥控)"脚本(2026-10-16 新增)。
    # 同 color.js: 必须独立成资源 —— app.js 的 gzip 已贴近 4800B 水位, 各动作按钮 + 说明塞进去必超限。
    ctrljs = open(paths["ctrl.js"], encoding="utf-8").read()
    # rb.js: "网络电台"页的"在线搜索(radio-browser)"卡片(2026-10-20 新增)。
    # 同 ctrl.js 必须独立成资源 —— app.js 已贴近水位, 搜索框 + 结果列表 + 轮询逻辑塞不下。
    rbjs = open(paths["rb.js"], encoding="utf-8").read()

    print("=== 网页资源拆分 & gzip 结果 (单次响应水位 %d B) ===" % LIMIT)
    lines = []
    lines.append("// ======== 本文件由 tools/gen_page_gz.py 自动生成, 请勿手改 ========")
    lines.append("// 源文件: tools/web_page/{index.html,app.css,app.js,sd.js,bg.js,bgb.js,wifi.js,listop.js,snd.js,ota.js,alarm.js,color.js,ctrl.js,rb.js}")
    lines.append("// 改完页面后重新生成: python tools/gen_page_gz.py")
    lines.append("// 用途: 拆成 6 个各自远小于 TCP_SND_BUF(≈5744B) 的 gzip 资源, 由浏览器原生")
    lines.append("//       <link>/<script src> 分别拉取, 规避大响应多轮续传卡死导致的\"后台打不开\"")
    lines.append("#pragma once")
    lines.append("#include <stdint.h>")
    lines.append("#include <pgmspace.h>")
    lines.append("")
    emit("index.html", html.encode("utf-8"), "PAGE_GZ", lines)
    emit("app.css", css.encode("utf-8"), "CSS_GZ", lines)
    emit("app.js", js.encode("utf-8"), "JS_GZ", lines)
    emit("listop.js", listopjs.encode("utf-8"), "LISTOP_JS_GZ", lines)
    emit("sd.js", sdjs.encode("utf-8"), "SD_JS_GZ", lines)
    emit("snd.js", sndjs.encode("utf-8"), "SND_JS_GZ", lines)
    emit("bg.js", bgjs.encode("utf-8"), "BG_JS_GZ", lines)
    emit("bgb.js", bgbjs.encode("utf-8"), "BGB_JS_GZ", lines)
    emit("dith.js", dithjs.encode("utf-8"), "DITH_JS_GZ", lines)
    emit("wifi.js", wjs.encode("utf-8"), "WIFI_JS_GZ", lines)
    emit("ota.js", otajs.encode("utf-8"), "OTA_JS_GZ", lines)
    emit("alarm.js", alarmjs.encode("utf-8"), "ALARM_JS_GZ", lines)
    emit("color.js", colorjs.encode("utf-8"), "COLOR_JS_GZ", lines)
    emit("ctrl.js", ctrljs.encode("utf-8"), "CTRL_JS_GZ", lines)
    emit("rb.js", rbjs.encode("utf-8"), "RB_JS_GZ", lines)

    # ★超水位 = 构建失败(硬退出), 且必须在写文件之前 —— 免得用超限资源覆盖掉上一份好的
    #   page_assets.h。这样"改页面撑爆预算"会在生成阶段就暴露, 而不是烧机后才发现后台打不开。
    if OVER:
        print()
        print("!! 构建失败: 以下资源 gzip 后超过单次响应安全水位 %d B:" % LIMIT)
        for n, sz in OVER:
            print("   %-14s %6d B  (超 %d B)" % (n, sz, sz - LIMIT))
        print("   后果: 该资源要分多轮续传, 音频抢网时续传链会卡住 -> 浏览器一直转圈(后台打不开)。")
        print("   处理: 把新逻辑拆到独立 .js 资源(照 snd.js / ota.js 的做法), 或精简该文件后重试。")
        sys.exit(1)
    # 未压缩骨架: 仅供 /raw 诊断对照(不参与常规访问)
    hb = html.encode("utf-8")
    lines.append("// index.html 未压缩版(仅 /raw 诊断用): %d B" % len(hb))
    lines.append("static const uint32_t PAGE_HTML_LEN = %d;" % len(hb))
    lines.append("static const char PAGE_HTML[] PROGMEM = R\"rawl(" + html + ")rawl\";")
    lines.append("")

    open(OUT_H, "w", encoding="utf-8", newline="\n").write("\n".join(lines))
    print("已写出: %s" % OUT_H)


if __name__ == "__main__":
    main()
