#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成"整片线刷包"(从 0x0 开始的完整固件镜像) —— 但只到【真正有内容】为止。

背景:
  arduino-cli 编译时会自动产出 webradio-s3p.ino.merged.bin, 但它按 FlashSize=16M
  补齐到 16MB(尾部全是 0xFF 填充)。实际内容只到 app 结束(约 2.1MB), 尾部 14MB 都是空。
  对新板/空板而言, 那些空白区本来就是 0xFF —— 写不写完全一样。
  所以这里裁成实际大小(取整到 64KB), 文件小 7 倍, 分发/线刷都省事。
  刷的时候 flash_full.cmd 带 --erase-all, 会先整片擦干净再写 -> 仍是彻底的出厂状态。

用法:
  python tools/make_full_bin.py            # 版本号自动从 config.h 的 FW_VERSION 取
  python tools/make_full_bin.py v1.1       # 也可手动指定

输出:
  <工程根目录>/firmware/webradio-s3p-<版本>-full.bin
"""
import hashlib
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                       # 工程根目录
BUILD = r"C:\Users\hudie\AppData\Local\Temp\wrb_s3p"

# 整片镜像里"谁在哪" —— 与 partitions.csv / esptool 烧录参数一致
# ★★★ 2026-10-16 【必读】app 为什么要写两份 ★★★
#   本机分区表是双 app(ota_0@0x10000 / ota_1@0x3F0000), 引导器启动哪一块由 otadata(0xE000)决定。
#   Arduino 自带的 boot_app0.bin 里 ota_seq=1 ⇒ 指向 ota_1; 而原来 app 只写 0x10000(ota_0)。
#   于是: 只要设备以前做过一次"网页 OTA"(旧固件被写进 ota_1), 之后每次整片线刷,
#   引导器都启动 ota_1 里那份【旧固件】 —— 新固件躺在 ota_0 永远不被执行,
#   现象是"刷完重启, 屏幕上一点变化都没有"(实测踩过: 设备一直跑 v1.13, 而 ota_0 里是 v1.14)。
#   ⇒ 修法: 同一份 app 同时写进 ota_0 与 ota_1。这样无论 otadata 指向哪块、
#     无论引导器的 rollback 逻辑怎么切, 跑的都是【同一份新固件】, 彻底免疫该问题。
#     代价: 整片包从 ~2.3MB 变成 ~6.3MB(仍是一个文件一次烧录)。
SEGS = [
    ("bootloader",   0x0,      "webradio-s3p.ino.bootloader.bin"),
    ("partitions",   0x8000,   "webradio-s3p.ino.partitions.bin"),
    ("boot_app0",    0xE000,   "boot_app0.bin"),
    ("app(ota_0)",   0x10000,  "webradio-s3p.ino.bin"),
    ("app(ota_1)",   0x3F0000, "webradio-s3p.ino.bin"),   # ★双写: 见上方说明
]
MERGED = "webradio-s3p.ino.merged.bin"
ALIGN = 0x10000          # 结果向上取整到 64KB


def read_version():
    """从 src/config.h 里读 #define FW_VERSION "vX.Y" """
    cfg = os.path.join(ROOT, "src", "config.h")
    if os.path.exists(cfg):
        m = re.search(r'#\s*define\s+FW_VERSION\s+"([^"]+)"',
                      open(cfg, encoding="utf-8", errors="replace").read())
        if m:
            return m.group(1)
    return "v0"


def main():
    ver = sys.argv[1] if len(sys.argv) > 1 else read_version()
    src = os.path.join(BUILD, MERGED)
    if not os.path.exists(src):
        print("[错误] 找不到 %s\n       先跑 compile.cmd 编译一次。" % src)
        return 1

    # 1) 各段实际占位 -> 内容结束位置
    end = 0
    for name, off, fn in SEGS:
        p = os.path.join(BUILD, fn)
        if not os.path.exists(p):
            print("[错误] 缺少分段文件 %s" % p)
            return 1
        n = os.path.getsize(p)
        end = max(end, off + n)
        print("  %-11s @0x%06X .. 0x%06X  %8d B" % (name, off, off + n, n))

    size = ((end + ALIGN - 1) // ALIGN) * ALIGN
    print("内容结束 0x%06X -> 取整到 64KB = 0x%06X (%.2f MB)" % (end, size, size / 1048576))

    merged = open(src, "rb").read()
    if len(merged) < size:
        print("[错误] merged.bin 比预期小, 数据不完整")
        return 1
    # 2) 被裁掉的部分必须全是 0xFF(否则说明有东西被漏掉)
    if not all(b == 0xFF for b in merged[size:size + 0x100000]):
        print("[警告] 被裁掉的区域里出现了非 0xFF 数据, 请人工确认后再用! 未写出。")
        return 1

    # 3) 裁剪 + 逐段复核(merged.bin 里没有的段就地补写 —— 目前只有 ota_1 的那份 app 副本)
    img = bytearray(merged[:size])
    wrote = 0
    for name, off, fn in SEGS:
        d = open(os.path.join(BUILD, fn), "rb").read()
        if img[off:off + len(d)] == d:
            continue
        if off == 0x3F0000 and name.startswith("app"):
            img[off:off + len(d)] = d          # ★双写: Arduino 的 merged.bin 不含 ota_1, 这里补上
            wrote += 1
            print("  补写 %-11s @0x%06X .. 0x%06X  %8d B" % (name, off, off + len(d), len(d)))
            continue
        print("[错误] %s 段字节不一致, 未写出。" % name)
        return 1
    img = bytes(img)
    if wrote:
        print("(app 已双写 ota_0 + ota_1: 引导器选哪块都是同一份新固件)")

    outdir = os.path.join(ROOT, "firmware")
    os.makedirs(outdir, exist_ok=True)
    out = os.path.join(outdir, "webradio-s3p-%s-full.bin" % ver)
    open(out, "wb").write(img)
    print("\n已写出: %s" % out)
    print("大小   : %d B (%.2f MB)  [原 16MB 版的 %.0f%%]"
          % (len(img), len(img) / 1048576, 100.0 * len(img) / 16777216))
    print("SHA256 : %s" % hashlib.sha256(img).hexdigest())
    print("头部   : 0x0=%s  0x10000=%s" %
          (img[0:4].hex(" "), img[0x10000:0x10004].hex(" ")))
    return 0


if __name__ == "__main__":
    sys.exit(main())
