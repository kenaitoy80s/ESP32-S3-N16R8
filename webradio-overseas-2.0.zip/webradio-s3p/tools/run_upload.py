import subprocess, sys, json, os, glob

# ============================================================================
# ESP32-S3 N16R8 烧录助手 —— 【webradio-s3p】
#   用法: python run_upload.py [COM口]      不传则自动挑 ESP32 的 USB 口
#
# ★ 本脚本只"上传", 不编译: 用 --input-dir 把 build 目录里已编好的
#   bootloader / 分区表 / 应用 一起烧进去。改完代码请先跑 run_compile.py。
#
# ★★★ 本机的 build 常量必须与 run_compile.py 完全一致 ★★★
#   sketch = Desktop\webradio-s3p, build = Temp\wrb_s3p,
#   bootloader 文件名 = webradio-s3p.ino.bootloader.bin
#   (Arduino 强制要求 sketch 主文件名 == 所在文件夹名)
#
# ★★ 烧前自检(build 归属 + bootloader 头 16MB)必须保留 ★★
#   烧错工程 / 烧错 FQBN(FlashSize=4M) 会导致上电分区表校验失败死循环,
#   而且那个校验发生在 App 之前, 【改代码永远修不好】, 只能重烧 bootloader。
# ============================================================================

# ---- 工具链定位(与 run_compile.py 同一套; 唯一权威 = toolchain_paths.py) ----
#   ★2026-10-27: 原来这里又抄了一份候选路径, 与 run_compile.py 各自维护 ->
#   迁到另一台电脑/换个工具链位置就得改两处。现统一从 toolchain_paths 取。
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from toolchain_paths import resolve, describe, build_base

cli, _data, _libs = resolve()
describe(cli, _data, _libs)
if not cli:
    print("✗ 找不到 arduino-cli.exe —— 设环境变量 ARDUINO_CLI 指向它, 或确认迁移包还在")
    sys.exit(1)
# ★烧录前把数据/库目录也指到 ASCII 副本(与 run_compile.py 一致)。
if _data: os.environ["ARDUINO_DIRECTORIES_DATA"] = _data
if _libs: os.environ["ARDUINO_DIRECTORIES_USER"] = _libs
# ★本行必须与 run_compile.py 的 fqbn 完全一致, 否则烧录参数与编译产物不匹配。
fqbn = "esp32:esp32:esp32s3:PartitionScheme=custom,PSRAM=opi,FlashMode=dio,FlashSize=16M,USBMode=hwcdc,CDCOnBoot=cdc"
build = build_base("wrb_s3p")      # ★与 run_compile.py 同一份产物目录
# ★sketch = 本工程实际所在(工程已挪进 esp32项目 工作区)。
#   ★★2026-10-27: 必须与 run_compile.py 用同一个解析结果★
#   编译实际发生在 %TEMP%\wrb_s3p_sk\webradio-s3p(junction) 上, build.options.json 里的
#   sketchLocation 记的就是它。这里若仍用"工程真实目录"去比, 自检会误判成
#   【另一个工程编的】而拒绝烧录 —— 两边都从 sketch_paths.py 取, 永不打架。
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sketch_paths import ROOT as sketch_root, sketch_target
sketch = sketch_target()
ino_name = "webradio-s3p.ino"      # ★ 与文件夹同名

# USB 转串口/原生USB 的厂商号: Espressif / CP210x / CH340 / FTDI(0403) / Arduino(2341)
USB_VIDS = {"0x303A", "0x10C4", "0x1A86", "0x0403", "0x2341"}

FLASH_SIZE_NAME = {0: "1MB", 1: "2MB", 2: "4MB", 3: "8MB", 4: "16MB", 5: "32MB"}


def hdr_flash_size(binpath):
    """读 bootloader 镜像头前 4 字节。第 4 字节: 低半字节=速度, 高半字节=容量。"""
    b = open(binpath, "rb").read(4)
    return b, FLASH_SIZE_NAME.get((b[3] >> 4), "?")


def pick_port():
    """挑端口。★别只判 properties.type —— 本机那个字段常是空的, 会挑到主板自带 COM1。"""
    r = subprocess.run([cli, "board", "list", "--format", "json"], capture_output=True, text=True)
    cands = []
    try:
        for p in json.loads(r.stdout).get("detected_ports", []):
            port = p.get("port", {})
            addr = port.get("address", "")
            if port.get("protocol") != "serial" or not addr.upper().startswith("COM"):
                continue
            props = port.get("properties", {}) or {}
            vid = (props.get("vid") or "").upper()
            boards = p.get("matching_boards") or []
            score = 0
            if vid in USB_VIDS:
                score -= 4                      # USB 串口桥 / 原生 USB
            if props.get("pid"):
                score -= 1
            if any("esp32" in (b.get("fqbn", "") or "").lower() for b in boards):
                score -= 4                      # 识别成 ESP32
            if addr.upper() == "COM1":
                score += 10                     # ACPI 主板自带口, 不可能是它
            try:
                num = int(addr[3:])
            except Exception:
                num = 0
            cands.append((score, -num, addr))
    except Exception as e:
        print("board list 解析失败:", e)
    cands.sort()
    return (cands[0][2] if cands else "COM5"), cands


# ---------------------------------------------------------------- 端口
port = sys.argv[1] if len(sys.argv) > 1 else None
if not port:
    port, cands = pick_port()
    print("自动选择端口:", port, "| 候选:", [(c[0], c[2]) for c in cands])

# ---------------------------------------------------------------- 烧前自检
print("=" * 68)
print("本脚本烧的是:", sketch)
print("build 目录   :", build)
print("=" * 68)

if not os.path.isdir(build):
    print("★★ 拒绝执行: build 目录不存在 ->", build)
    print("   先跑本工程的 run_compile.py。")
    sys.exit(2)

bop = os.path.join(build, "build.options.json")
if not os.path.isfile(bop):
    print("★★ 拒绝执行: build 目录里没有 build.options.json, 说明它不是一次完整编译的产物。")
    sys.exit(2)

with open(bop, encoding="utf-8") as f:
    _j = json.load(f)
_loc = _j.get("sketchLocation", "") or ""
if os.path.normcase(os.path.normpath(_loc)) != os.path.normcase(os.path.normpath(sketch)):
    print("★★ 拒绝执行: 这个 build 目录是【另一个工程】编的!")
    print("   build 里编的是:", _loc)
    print("   本脚本要烧的是:", sketch)
    print("   -> build 常量指错了。三个工程必须各用独立 build-path, 否则会把别的固件烧进来。")
    sys.exit(2)

_bl = os.path.join(build, ino_name + ".bootloader.bin")
if not os.path.isfile(_bl):
    print("★★ 拒绝执行: 找不到 bootloader.bin ->", _bl)
    sys.exit(2)
_b, _sz = hdr_flash_size(_bl)
if _sz != "16MB":
    print("★★ 拒绝执行: build 里的 bootloader 不是 16MB 配置(头 %s -> %s)。" % (_b.hex(), _sz))
    print("   说明该 build 目录是用错误的 FQBN(多半 FlashSize=4M)编出来的, 烧上去会死循环。")
    print("   -> 重跑 run_compile.py(它用的 FQBN 是对的)。")
    sys.exit(2)
print("烧前自检通过: build 归属正确 | bootloader 头 %s (%s)" % (_b.hex(), _sz))

# ---------------------------------------------------------------- 烧录
args = [cli, "upload", "-p", port, "--fqbn", fqbn, "--input-dir", build, sketch]
p = subprocess.run(args, capture_output=True, text=True, timeout=600)
out = (p.stdout or "") + "\n" + (p.stderr or "")
open(build + "_upload.log", "w", encoding="utf-8").write(out)
print("EXIT", p.returncode, "| port", port)
for ln in out.splitlines():
    if any(k in ln for k in ["Hash of data verified", "Leaving", "Hard resetting", "riting at", "error", "Error",
                             "拒绝", "占用", "Permission", "Failed", "A fatal"]):
        print(">>", ln)

# ---------------------------------------------------------------- 烧后体检: 回读 0x0 的镜像头
_esp = None
for _c in sorted(glob.glob(os.path.join(os.environ.get("LOCALAPPDATA", ""), "Arduino15", "packages",
                                        "esp32", "tools", "esptool_py", "*", "esptool.exe")), reverse=True):
    _esp = _c
    break
if p.returncode == 0 and _esp:
    _tmp = r"C:\Users\hudie\AppData\Local\Temp\wrb_boot_hdr_s3p.bin"
    subprocess.run([_esp, "--chip", "esp32s3", "--port", port, "--baud", "921600",
                    "read_flash", "0x0", "0x4", _tmp], capture_output=True)
    try:
        with open(_tmp, "rb") as f:
            _b = f.read(4)
        _n = _b[3] >> 4
        _sz = FLASH_SIZE_NAME.get(_n, "?")
        print(">> bootloader 头", _b.hex(), "-> FlashSize =", _sz)
        if _n != 4:
            print(">> ★★ 警告: flash 里的 bootloader 不是 16MB 配置! 分区表需要 >4MB, 上电会死循环。")
            print(">>    多半是之前用 Arduino IDE 默认配置(FlashSize=4M)烧过 -> 再跑一次本脚本覆盖即可。")
        else:
            print(">> FlashSize 校验通过(16MB), 分区表可容纳。")
    except Exception as e:
        print(">> bootloader 头读取失败:", e)
