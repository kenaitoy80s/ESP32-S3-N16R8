#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成 t2s_tab.h —— 繁体字 -> 简体字 单字映射表(屏幕字库画不出繁体时的兜底)。

为什么需要它(2026-10-07):
  屏幕用的是 U8g2 自带字库 u8g2_font_unifont_t_gb2312, 它只覆盖 GB2312 = 简体 6763 字。
  而外部数据里的中文【不一定】是简体, 最典型的就是天气定位:
    ipwho.is 的 lang=zh-CN 实测返回的是【繁体】地名 ——
      San Francisco -> 舊金山 (U+820A U+91D1 U+5C71)
      San Jose      -> 聖荷西 (U+8056 ...)
      昆士兰        -> 昆士蘭州
  繁体字在 GB2312 字库里查不到 -> pickCnFont 返回 -1 -> 屏上画【空心方框】。
  现象就是用户报的"电台名里的'旧'正常, 天气里的'旧'不正常"——
  同一个意思, 一个是简体 U+65E7(字库有), 一个是繁体 U+820A(字库没有)。

为什么表这么小:
  只收录【繁体字在 GB2312 里没有、而简体写法在 GB2312 里有】的那些字。
  (繁体字本身就在 GB2312 里的, 比如 乾/著, 屏上本来就能画, 不必也不该改。)
  => 约 2500 项, 4B/项 ≈ 10KB, 放 flash(.rodata), 不占 RAM。

输入: tools/TSCharacters.txt —— OpenCC(https://github.com/ByVoid/OpenCC) 的繁简单字表,
      Apache-2.0。只取 1 繁 -> 1 简 的行(1 繁 -> N 简 有歧义, 跳过)。
      ★GB2312 覆盖范围以工程自己的 gb2312_tab.h 为准(它就是屏上字库的覆盖表),
        不从 Python 的 gb2312 编解码器推 —— 那个比 GB2312-80 宽, 会多算。

表结构: 按繁体码点升序的一维交错数组 [繁0, 简0, 繁1, 简1, ...], 供二分查找。
用法:   python tools/gen_t2s_table.py     (改完 TSCharacters.txt 或 gb2312_tab.h 后重跑)
"""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "TSCharacters.txt")
GB2312 = os.path.join(HERE, "..", "src", "data", "gb2312_tab.h")
OUT = os.path.join(HERE, "..", "src", "data", "t2s_tab.h")


def load_gb2312():
    """读 gb2312_tab.h 里所有非零码点 —— 即屏上字库真正画得出的字。"""
    txt = open(GB2312, encoding="utf-8").read()
    body = txt[txt.index("{"):txt.rindex("}")]
    return set(int(x, 16) for x in re.findall(r"0x[0-9A-Fa-f]+", body)) - {0}


def load_pairs():
    """TSCharacters.txt -> {繁体码点: 简体码点}; 只收 1:1, 1:N 单独计数。"""
    one2one, one2many = {}, 0
    for ln in open(SRC, encoding="utf-8"):
        ln = ln.strip()
        if not ln or ln.startswith("#"):
            continue
        k, _, v = ln.partition("\t")
        vs = v.split()
        if len(k) != 1 or not vs:
            continue
        # ★只收 BMP(U+FFFF 以内): 屏上逐字渲染器(nextCp)只解 1~3 字节 UTF-8, 连码点都取不到
        #   的就无从替换; 而且表中字段是 uint16, 超过 BMP 会触发 narrowing 编译错误。
        if ord(k) > 0xFFFF or ord(vs[0]) > 0xFFFF:
            continue
        if len(vs) == 1 and len(vs[0]) == 1:
            one2one[ord(k)] = ord(vs[0])
        else:
            one2many += 1
    return one2one, one2many


def build():
    gb = load_gb2312()
    one2one, one2many = load_pairs()
    items = sorted((t, s) for t, s in one2one.items()
                   if t not in gb and s in gb)          # 繁体字库没有 + 简体字库有
    miss_n = sum(1 for t, s in one2one.items() if t not in gb)
    return items, one2many, len(one2one), len(gb), miss_n


def emit(items, path):
    L = []
    L.append("// ======== 本文件由 tools/gen_t2s_table.py 自动生成, 请勿手改 ========")
    L.append("// 用途: 繁体字 -> 简体字 单字映射。字库是 GB2312(简体), 外部数据里的繁体字")
    L.append("//       (实测 ipwho.is lang=zh-CN 的地名: 舊金山/聖荷西/昆士蘭州)画出来是空方框,")
    L.append("//       渲染时先用本表把它换成简体写法(见 display_ui.cpp 的 t2sFix)。")
    L.append("// 结构: 按繁体码点升序的交错数组 [繁0, 简0, 繁1, 简1, ...], 供二分查找。")
    L.append("// 覆盖: %d 项; 只收\"繁体不在 GB2312 且简体在 GB2312\"的字, 约 %d B。"
             % (len(items), len(items) * 4))
    L.append("#pragma once")
    L.append("#include <stdint.h>")
    L.append("")
    L.append("#define T2S_N %d" % len(items))
    L.append("")
    L.append("static const uint16_t gT2S[T2S_N * 2] = {")
    row = []
    for t, s in items:
        row.append("0x%04X,0x%04X" % (t, s))
        if len(row) == 8:
            L.append("  " + ",".join(row) + ",")
            row = []
    if row:
        L.append("  " + ",".join(row) + ",")
    L.append("};")
    L.append("")
    data = "\n".join(L)
    open(path, "w", encoding="utf-8", newline="\n").write(data)
    return len(data)


def main():
    items, one2many, n_all, n_gb, miss_n = build()
    print("GB2312 字库覆盖: %d 字" % n_gb)
    print("TSCharacters 1:1 繁简对: %d  (另有 1:N 多选 %d 条, 有歧义 -> 跳过)" % (n_all, one2many))
    print("其中繁体不在 GB2312(屏上会画方框): %d" % miss_n)
    print("=> 实际收录(繁体画不出 且 简体画得出): %d 项, 编译进固件约 %d B(%.1f KB)"
          % (len(items), len(items) * 4, len(items) * 4 / 1024))
    size = emit(items, OUT)
    print("  C++ 文本 %d B, 输出 -> %s" % (size, os.path.normpath(OUT)))
    d = dict(items)
    print("  自检(实测踩到 / 常见繁体):")
    for ch in "舊聖蘭灣龍鳥國學電體漢點語說車馬門無風與為":
        t = ord(ch)
        note = "字库有(不用转)" if t in load_gb2312() else ("-> %s" % chr(d[t]) if t in d else "-> 表里没有")
        print("    %s U+%04X %s" % (ch, t, note))


if __name__ == "__main__":
    sys.exit(main())
