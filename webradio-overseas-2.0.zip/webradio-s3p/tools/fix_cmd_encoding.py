#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ============================================================================
#  Windows 批处理(.cmd)编码/换行 归一化 + 自检 —— 【webradio-s3p】
#
#  为什么需要它:
#    cmd.exe 读 .cmd 文件时, 是按"当前代码页"去算【下一行的字节位置】的。
#    如果文件存成 UTF-8(中文一个字 3 字节)而代码页是 936, 位置就会错位:
#    下一行从中间开始读 -> 行首(command/rem/echo)被吃掉 ->
#      "xxx 不是内部或外部命令, 也不是可运行的程序"
#      "系统找不到指定的路径。"
#      外加中文乱码(自动挑 -> 鑷姩鎸)
#    这个症状完全不像编码问题, 极难自行定位, 所以这里固化下来。
#
#  结论(本工程约定):
#    .cmd 一律存成 ANSI(cp936/GBK) + CRLF 换行, 并且不要写 chcp 65001。
#    (打开 UTF-8 代码页会让上述错位更容易发生, 而 Python 3.6+ 在真实控制台
#     下本来就走 WriteConsoleW, 中文输出与控制台代码页无关, 不需要 chcp。)
#
#  用法:
#    python tools\fix_cmd_encoding.py           # 就地修好所有 .cmd(自动备份 .bak_enc)
#    python tools\fix_cmd_encoding.py --check   # 只体检不改动; 有问题返回码 1
# ============================================================================

import os
import re
import sys
import glob
import shutil

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ENC = "cp936"          # 即 Windows 简体中文 ANSI / GBK
CHCP_BAD = re.compile(r"^chcp\s+65001\b", re.I)


def sniff(b):
    """返回 (文本, 原编码描述)。UTF-8 解不出来就按 GBK 解。"""
    if b[:3] == b"\xef\xbb\xbf":
        return b[3:].decode("utf-8"), "utf-8(BOM)"
    try:
        return b.decode("utf-8"), "utf-8"
    except UnicodeDecodeError:
        return b.decode(ENC), "gbk"


def strip_chcp(lines):
    """删掉真正的 `chcp 65001` 命令行了(注释里提到它的不删)。"""
    out, hit = [], 0
    for ln in lines:
        s = ln.strip().lower()
        if not s.startswith("rem") and not s.startswith("::") and CHCP_BAD.match(s):
            hit += 1
            continue
        out.append(ln)
    return out, hit


def process(path, check_only):
    raw = open(path, "rb").read()
    text, was = sniff(raw)
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    while lines and lines[-1] == "":
        lines.pop()
    lines, nchcp = strip_chcp(lines)

    new = ("\r\n".join(lines) + "\r\n").encode(ENC, errors="strict")
    problems = []
    if was.startswith("utf-8"):
        problems.append("编码 %s -> 应为 ANSI(cp936)" % was)
    if raw.count(b"\r\n") != raw.count(b"\n"):
        problems.append("行尾含 LF(非 CRLF)")
    if nchcp:
        problems.append("含 chcp 65001 命令行 x%d" % nchcp)

    name = os.path.basename(path)
    if not problems:
        print("  [OK ] %-16s 已是 ANSI(cp936) + CRLF" % name)
        return 0

    if check_only:
        print("  [!! ] %-16s %s" % (name, " | ".join(problems)))
        return 1

    shutil.copyfile(path, path + ".bak_enc")
    with open(path, "wb") as f:
        f.write(new)
    print("  [FIX] %-16s %s  (%d -> %d B, 原文件存为 %s.bak_enc)"
          % (name, " | ".join(problems), len(raw), len(new), name))
    return 1


def main():
    check_only = "--check" in sys.argv
    files = sorted(glob.glob(os.path.join(ROOT, "*.cmd")) +
                   glob.glob(os.path.join(ROOT, "**", "*.cmd"), recursive=True))
    files = sorted(set(os.path.abspath(p) for p in files))
    print("Windows 批处理编码自检" + ("(只读)" if check_only else "(归一化)"))
    print("  规则: ANSI(cp936) 编码 + CRLF 换行 + 不写 chcp 65001")
    print("  范围:", ROOT)
    print()
    bad = 0
    for p in files:
        if ".bak" in os.path.basename(p) or ".tmp" in p:
            continue
        bad += process(p, check_only)
    print()
    if bad == 0:
        print("结果: 全部正常, 双击即可用。")
    elif check_only:
        print("结果: %d 个文件有问题 -> 去掉 --check 再跑一次即可修好。" % bad)
        sys.exit(1)
    else:
        print("结果: 已修好 %d 个文件。现在双击 .cmd 应该正常了。" % bad)


if __name__ == "__main__":
    main()
