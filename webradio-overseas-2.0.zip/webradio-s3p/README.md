# 大猫电台 · webradio-s3p

ESP32-S3 N16R8 网络收音机固件 —— 多屏型支持（ST7789 320x240 / ST7789 240x240 方屏 / ILI9341 彩屏 + ST7567 / SSD1306 单色，
后台"显示设置"里五选一、换屏不用重烧）
+ 本地 SD 卡播放
+ 网页后台 + 网页在线升级（OTA）+ 红外遥控。
+ 网页后台"控制"页含【设备控制(等效遥控)】按钮组(独立资源 `ctrl.js`, v1.11 加)：10 个遥控动作
+ (上一台/下一台/播放暂停/音量±/关机开机/屏幕旋转/切换屏幕/音源切换/定时关机)与遥控器完全等价。
+ **卡通配色**(v1.12 加)：彩屏 bit=0 底色可选 8 种卡通浅色、各界面元素默认糖果配色，不再白字黑底；
+ "显示设置"卡内含【背景色(仅彩屏)】下拉，也可逐元素自定义颜色。
+ **显示对齐带 6686 版 + 修真 bug**(v1.14)：显示逻辑回到与带 6686 的 FULL / FM 主线 v1.12/v1.13 完全一致
+ ——无上传背景图时 bit=0 就是卡通纯色底（不再用 v1.13 那个花哨壁纸）；并修掉"后台改背景色怎么点都没反应"
+ 的真凶（`web_server.cpp` 的 `disp=` 用 `int seg[7]` 却读第 8 段 `seg[7]`，数组越界读栈垃圾 → 已扩成 `seg[8]`）。
+ 也修了后台改配色/显示设置后未作废当前帧、被"按内容指纹整帧跳过"挡住的问题(v1.13)。

> 本目录同时就是 **Arduino sketch 目录**（`webradio-s3p.ino` 与文件夹同名），
> 可直接用 Arduino IDE 打开，也可用根目录的三个 `.cmd` 一键编译 / 烧录。
>
> **位置**：本工程位于工作区 `02-网络电台-四屏位主线/`（2026-10-10 起全工作区按功能分为三层）。
> 本层是**唯一保留单色屏（ST7567/SSD1306）与双背光两路独立**的上游主线；
> 日常在役的主力分支在 `01-网络电台-通用IO/`，带 FM 的老系列在 `03-FM+网络-老系列/`。
> 总导航见工作区根目录 `README.md`。

---

## 目录结构

```
webradio-s3p/
├── webradio-s3p.ino      ← 主程序（Arduino 强制：与文件夹同名、必须留根）
├── build_opt.h           ← 编译期宏（起播预缓冲 AUDIO_MIN_BUFFER_BYTES）
├── partitions.csv        ← 分区表（nvs / otadata / ota_0 / spiffs / ota_1，支持网页 OTA）
│
├── compile.cmd           ← 【双击】编译
├── upload.cmd            ← 【双击】烧录（只写 app，保住 WiFi 与电台表）
├── flash_full.cmd        ← 【双击】整片线刷（= 恢复出厂，会清空数据）
│
├── src/                  ← 全部源码
│   ├── config.h          ← ★ 唯一配置点：引脚 / 屏幕默认值 / 版本号 / 各开关
│   ├── player_state.h    ← 全局播放状态
│   ├── core/             ← 业务核心：音频播放、SD 卡、电台存储、天气/时间、定时开机(闹钟)
│   ├── ui/               ← 人机交互：屏幕绘制、按键、红外学习
│   ├── net/              ← 网络服务：Web 后台、配网门户、网页资源(生成物)
│   └── data/             ← 字库与数据表（生成物）
│
├── docs/                 ← 说明书
│   ├── IO分配表.txt      ← 接线 / 引脚占用（画板与接线对照）
│   └── 功能表.txt        ← 使用功能说明（怎么用、能干什么）
│
├── tools/                ← 脚本与素材
│   ├── run_compile.py    ← compile.cmd 调用
│   ├── run_upload.py     ← upload.cmd 调用
│   ├── gen_page_gz.py    ← 网页源 → src/net/page_assets.h（超 4800B 水位即构建失败）
│   ├── patch_audio_lib.py ← ★给音频库重打 HLS 补丁（库升级后跑一次，见下）
│   ├── gen_gbk_rev_tab.py / gen_t2s_table.py   ← 字库生成
│   ├── make_full_bin.py  ← 生成整片线刷包 → firmware/
│   ├── fix_cmd_encoding.py ← ★.cmd 存成 ANSI+CRLF（双击报"不是内部或外部命令"就跑它）
│   ├── bg_test.py / psram_check.py             ← 联机自检小工具
│   └── web_page/         ← ★网页源文件（要改网页改这里）
│
├── firmware/             ← 发布产物（两个包：webradio-s3p-<版本>-web.bin 网页升级用 /
│                                              webradio-s3p-<版本>-full.bin 整片线刷用）
└── _archive/             ← 历史归档（已移除的 6686 文档、旧版包）
```

---

## 怎么用

| 场景 | 操作 |
|---|---|
| 改完代码要编译 | 双击 **`compile.cmd`**（看到 `EXIT 0` 才算成功） |
| 把固件烧进板子（**保住** WiFi 与电台表） | 双击 **`upload.cmd`**（可 `upload.cmd COM6` 指定串口） |
| 新板第一次装机 / 救砖（**会清空**数据） | 双击 **`flash_full.cmd`** |
| 日常升级（不用插线） | 网页后台 → 设置 → 固件升级，选 `webradio-s3p.ino.bin` |

> ⚠️ **烧录铁律**：分区表总量 6.94MB > 4MB，**只能用上面这些脚本烧**
> （它们 FQBN 写死 `FlashSize=16M` 且带烧前自检）。
> **绝不能点 Arduino IDE 图形界面的「上传」按钮** —— 它默认 4MB 配置，
> 烧下去会上电死循环，且改代码救不回，只能重烧 bootloader。

### ★★ 启动分区（2026-10-16 踩坑后固化，改打包脚本前必读）

本机分区表是**双 app**：`ota_0@0x10000` / `ota_1@0x3F0000`（为了支持网页 OTA）。
引导器启动**哪一块**由 `otadata`（`0xE000`，即整片镜像里的 `boot_app0.bin`）决定，**不是**由"app 写在哪"决定。

| 事实 | 后果 |
|---|---|
| Arduino 自带的 `boot_app0.bin` 里 `ota_seq=1` ⇒ **指向 `ota_1`** | 整片线刷后引导器优先选 `ota_1` |
| 原 `make_full_bin.py` 只把 app 写进 `0x10000`(=`ota_0`) | `ota_1` 里那份**旧固件**被执行，新固件没人跑 |
| 设备只要做过一次"网页 OTA"，旧固件就落在 `ota_1` | 之后**每次线刷都白刷**：现象是"改完刷完，屏幕/功能一点变化都没有" |
| `CONFIG_BOOTLOADER_APP_ROLLBACK_ENABLE=y` | 新镜像若以 `NEW` 状态启动且不自我确认，下次复位会被判失败并切回另一块分区 |

**实测取证**（2026-10-16）：`ota_0` 里是 v1.14、`ota_1` 里是 v1.13，而 `/api/state` 报 `ver=v1.13`
—— 设备一直在跑旧固件，所以 v1.12~v1.14 的显示改动全都"看起来无效"。

**修复（三件套，已在全部 8 个 S3 工程同步）**：

1. `tools/make_full_bin.py`：同一份 app **同时写进 `ota_0` 与 `ota_1`**
   ⇒ 引导器选哪块都是同一份新固件，彻底免疫（整片包 ~2.3MB → ~6.3MB，仍是一个文件一次烧录）。
2. `setup()` 开头**启动分区自检**：串口直接打印 `固件版本 / 运行分区 / otadata状态`。
   **"刷了没效果"时先看这一行。**
3. `setup()` 里 `esp_ota_mark_app_valid_cancel_rollback()`：启动成功即确认本分区
   （本机 rollback 是开的；否则以 `NEW` 状态启动的镜像下次复位会被自动切回旧分区）。

> 排查这类问题最直接的手段：`esptool read_flash` 读 `0xE000`(otadata) / `0x10000` / `0x3F0000` 三处，
> 与本地 `firmware/*.bin` 比对指纹 —— 一眼看出"设备到底在跑哪一份"。

---

## 在线电台搜索 radio-browser（v1.16 新增）

网页后台 →「网络电台」页顶部新增一张卡：

| 操作 | 说明 |
|---|---|
| 关键词搜索 | 输入电台名（jazz / 新闻 / cctv）→ 列出 radio-browser 里票数最高的 12 条 |
| 🔥 热门 | 全球 topvote 前 12 |
| 🇨🇳 中国电台 | 按 ISO 国家码 CN 精确筛选 12 条 |
| 试听 | 直接播该流（不入库），不满意继续试 |
| 加入 | 写入本机电台列表，分类记为「在线电台」，地址重复自动跳过 |

**改这块前必读：**
- HTTPS 拉取**在主循环**做（`WebServerSvc::loop()` 里的 `rbPoll()`），与 `weatherTick()` 同一套路；
  绝不能在 async_tcp 回调里拉 —— 那会把 Web/WS 卡住数秒，页面表现为"点了没反应"。
- 页面是**轮询**：`GET /api/rb/search` 只置请求 → 主循环拉取 → `GET /api/rb/result` 取快照；
  `POST /api/rb/play` 试听、`POST /api/rb/add` 加入（复用 `StationStore::add/hasUrl`）。
- 节点回退 de1 → all → nl1，免费接口无 Key；内存门槛 60KB（TLS 握手要连续堆）。
- 过滤策略照《D://ESP32//RadioBrowser_API_接入指南.md》：**不按 bitrate=0 / lastcheckok 过滤，不排除 HLS**。
- 前端 `tools/web_page/rb.js` 必须独立成资源（`app.js` 的 gzip 已贴 4800B 水位），改完跑
  `python tools/gen_page_gz.py` 重新生成 `src/net/page_assets.h`。
- 固件模块：`src/net/radio_browser.{h,cpp}`。

---

## 开发约定

- **唯一配置点**：`src/config.h`（引脚、屏幕默认类型、版本号 `FW_VERSION`、各功能开关）。
- **改网页**：改 `tools/web_page/` 里的源文件，然后跑
  `python tools/gen_page_gz.py` 重新生成 `src/net/page_assets.h` —— **禁手改生成物**。
  ★该脚本对"单个资源 gzip > 4800B"是**硬失败**（不是警告）：超过水位就得拆成独立
  `.js` 资源（照 `snd.js` / `ota.js` 的样子），否则音频抢网时资源要分多轮续传 →
  浏览器一直转圈 = 后台打不开。
- **第三方音频库补丁（会随库升级丢失，务必记住）**：`Arduino/libraries/ESP32-audioI2S-nopsram`
  里有一处 firmware-side 补丁（**Patch 11**：把 m3u8/HLS 队列吃空后硬编码的 1000ms 重抓
  改成可调的 `M3U8_REFRESH_MS` / `M3U8_STARVED_MS`，并让缓冲见底时提前重抓）。库一旦
  重装/升级，补丁就没了 → 跑一次 `python tools/patch_audio_lib.py` 复原（幂等、自动备份
  `.bak_m3u8`、锚点唯一性断言，升级后库结构变了会明确报错而不是乱改）。
  ★改宏值后 **arduino-cli 不会重编库对象** → 手删 build 目录里的
  `libraries/ESP32-audioI2S-nopsram/Audio_nopsram.cpp.o` 再编译，否则改动不生效。
- **`.cmd` 必须存成 ANSI(cp936/GBK) + CRLF 换行，且不要写 `chcp 65001`**：
  cmd.exe 读批处理时按"当前代码页"算**下一行的字节位置**，文件若存成 UTF-8（中文一个字
  3 字节）就会错位 → 下一行**行首被吃掉**，报 `xxx 不是内部或外部命令` / `系统找不到指定的路径`
  + 中文乱码（`自动挑`→`鑷姩鎸`），看起来完全不像编码问题。
  ★用编辑器另存 / git 转过换行 / 加了 `chcp 65001` 都会触发；出问题跑一次
  `python tools/fix_cmd_encoding.py`（就地修好并留 `.bak_enc`），加 `--check` 只体检不改动。
- **`src/net/page_assets.h`、`src/data/*.h` 都是生成物**，分别由 `tools/gen_page_gz.py`
  与 `tools/gen_gbk_rev_tab.py` / `gen_t2s_table.py` 生成，可复现。
- **工程文件夹名带版本号也不影响编译**（2026-10-27 修）：Arduino 硬规则是**主 `.ino` 名必须等于
  文件夹名**，而本工程文件夹叫 `webradio-s3p-4screen-mainline-v1.16`、主文件是 `webradio-s3p.ino`，
  本来对不上 → `arduino-cli` 直接报 `main file missing from sketch`，一个字符都不编。
  现在 `tools/sketch_paths.py` 会在 `%TEMP%\wrb_s3p_sk\webradio-s3p` 建一个**目录联接(junction)**
  指回本工程，`run_compile.py` / `run_upload.py` 都用它当 sketch 路径 → 产物名仍是
  `webradio-s3p.ino.bin`（`make_full_bin.py` / `flash_full.cmd` 一行都不用改），源码仍只有一份。
  ★文件夹以后随便改名/换盘：脚本自己跟随；**唯一条款是别把主文件也改名**。
- **烧录用哪份 esptool 会自动探测**：esptool 5.x 只认 `write-flash`、4.x 只认 `write_flash`，
  本机两代都有（编译工具链里 5.x，`%LOCALAPPDATA%\Arduino15` 里 4.5.1）。`flash_full.cmd` 会看
  `--help` 里的写法自己挑子命令；整片包也改成按**修改时间最新**取（原来按文件名排序，v1.9 会压过 v1.16）。
- **工具链位置只有一处定义：`tools/toolchain_paths.py`**（2026-10-27 加，`run_compile.py` /
  `run_upload.py` 共用）。解析 `arduino-cli` / 数据目录 / 库目录 / 产物目录，优先级 =
  环境变量 > 迁移包内 `<工程>\..\tc\`（或 `toolchain\`）> `%TEMP%\tyio_data\arduino15` +
  `%TEMP%\tyio_libs` > 历史路径。⇒ 本机行为与以前完全一致；工程连迁移包拷到别的电脑，
  自动命中包内工具链，不用改任何路径。自查：`python tools/toolchain_paths.py`。
  ★`ARDUINO_DIRECTORIES_USER` 要的是**用户目录**（里面还有 `libraries\` 一层），
  直接指到 `libraries` 本身会报 `U8g2lib.h: No such file or directory`。
- **迁移包路径必须又短又纯英文（Windows MAX_PATH）**：GCC 找 C++ 标准库头文件时用的是
  **带 `..` 的未规范化路径**，实测 `包路径 + "tc\arduino15" + 175` 一旦超过 **259** 就报
  `bits/cpu_defines.h: No such file or directory` —— 文件明明在硬盘上，极容易误判成
  "工具链缺文件 / 库没装全"，白折腾。所以导出时包名取短（如 `wrb-s3p-v116-mig`）、
  工具链目录叫 `tc`、包路径（含末尾反斜杠）**≤ 71 字符**；`toolchain_paths.path_len_problem()`
  会在编译前把这条算出来并给出人话提示。
- 跨目录引用头文件用**相对路径**（如 `#include "../core/audio_player.h"`），与 YoRadio 一致。

---

## 迁移到另一台电脑（自带工具链的离线包）

整包拷走就能在那台机器上继续开发，**不用装 Arduino IDE、不用联网**。
导出口诀（v1.16 已按此产出一个，见 `wrb-s3p-v116-mig`）：

1. 目标目录名取**短**且**纯英文**，如 `D:\wrb\wrb-s3p-v<ver>-mig`（包路径含末尾反斜杠 ≤ 71 字符）。
2. 工程拷成 `<包>\webradio-s3p\`（**文件夹名必须等于主 .ino 名**，这样连 junction 都不需要）；
   排除 `tools\__pycache__`、`*.pyc`。
3. 工具链拷成：
   - `<包>\tc\arduino-cli.exe`
   - `<包>\tc\arduino15\`      ← 数据目录（`ARDUINO_DIRECTORIES_DATA`）；只留 `packages\`
     里的 esp32 核心 3.3.11 + `esp-x32` / `esp32s3-libs` / `esp32-libs` / `esptool_py` /
     `mklittlefs` / `mkspiffs`，去掉 `xtensa-esp-elf-gdb`(126MB) 与 `openocd-esp32`(9.6MB)
   - `<包>\tc\user\libraries\` ← 用户目录（`ARDUINO_DIRECTORIES_USER`）**下一层才是 libraries**
   - 索引 `library_index.json` + `package_index.json`（各带 `.sig`）要带上，
     否则 arduino-cli 每条命令都想联网下索引，离线机器上会卡住
4. 包根再放两个文件：`setup.cmd`（GBK+CRLF，自检：文件齐不齐 / 路径英文+长度 / Python / core list）
   和 `00-README-先读我.txt`（UTF-8-BOM+CRLF）。
5. 验证方式不能只看"能编"：要用**包内**工具链在**全新** build 目录完整编一次
   （`TEMP` 指到空目录，逼它全量重编），否则会命中旧 build 缓存而假通过。

---

## 文档

- 接线 / 引脚 → [`docs/IO分配表.txt`](docs/IO分配表.txt)
- 功能说明 → [`docs/功能表.txt`](docs/功能表.txt)
