#pragma once
#include <Arduino.h>
#include <time.h>     // struct tm / localtime_r (供本头末尾联网数据层的 timeLocal 用)
#include "config.h"   // 用到 VOLUME_DEFAULT

/*
 * 全局播放状态：Web/按键/显示/主循环都【读】它, 但只有【主循环】能【写】。
 * 由 audio_player.cpp 定义实体，其余文件用 extern 引用。
 *
 * ★为什么"只由主循环写"(方案B 2026-09-19 起成为硬约束):
 *   里面全是 Arduino String。String 赋值 = 释放旧缓冲 + 分配新缓冲, 若两个任务同时写/一写一读,
 *   就是 double-free / use-after-free -> 堆损坏重启。而音频库回调(audio_showstreamtitle)跑在
 *   【音频泵任务】里、WS/HTTP 回调跑在【异步任务】里 —— 它们都不得直接写 gState:
 *     · 库回调 -> 写无堆暂存缓冲 + 代次号, 由主循环 applyPendingTitle() 取走落地;
 *     · WS/HTTP -> 只投递命令或置标志(如 gStoreChanged), 由主循环修正。
 *   (gState.volume 是 int, 单次 32bit 写天然原子, 故允许 setVolume 从任意任务调用。)
 */

// 天气快照(由主循环每小时刷新一次写入; 只有 gState 能写, 显示层与 /api/state 只读)
// 全部字段都是【已取到才有意义】: wxValid=false(没取到/没配 Key)时显示层一律显示 "--"。
struct WeatherInfo {
  bool   valid      = false;   // 是否成功取到过
  String city       = "";      // 城市名(如 "杭州")
  String text       = "";      // 实时天气文字(如 "多云")
  int    tempC      = 0;       // 实时温度(℃)
  int    feelsC     = 0;       // 体感温度(℃)
  int    humidity   = 0;       // 相对湿度(%)
  String windDir    = "";      // 风向(如 "北风")
  String windScale  = "";      // 风力等级文字(如 "5级")
  int    tminC      = 0;       // 今日最低温(℃)
  int    tmaxC      = 0;       // 今日最高温(℃)
  int    tmin2C     = 0;       // 明天最低温(℃)
  int    tmax2C     = 0;       // 明天最高温(℃)
  uint32_t updMs    = 0;       // 最近一次成功刷新的时间(millis)
};

struct PlayerState {
  String stationName = "";     // 当前电台名(中文)
  String title = "";           // 流内曲名/节目标题
  String bitrate = "";         // 比特率, 形如 "128k"
  String codec   = "";         // 编码名(AAC / MP3 / FLAC / …), 屏幕第3行显示; 未识别时为空
  String url = "";             // 当前电台真实流地址(第2行 title 为空时回退显示)
  String status = "待机";      // 播放中 / 连接中 / 停止 / 配网 / 重连中 / 未连网 / 没电台 / 已连 / 播放完 / 读取失败
  bool   playing = false;
  int    volume = VOLUME_DEFAULT;
  int    index = 0;            // 当前电台下标
  bool   wifiConnected = false;
  bool   apMode = false;       // true=当前处于AP配网热点模式
  String apName = "";          // AP热点名称(配网时显示给用户)
  String ip = "";
  uint32_t lastDataMs = 0;     // 最近一次"音频"数据的时间(由主循环按"输入缓冲是否在长"推进; 不混用元数据)
  // "库还没开始出声"(换台后已连上, 但库尚未解码输出)。
  // ★由主循环用【锁存式】判据维护(见 audio_player.cpp 的 s_outStarted): 换台清零, 一旦观察到
  // "库在跑且码率已识别"就永久置 1, 本台内不再翻转。显示层据此把第2行显示成"缓冲中"/"等待出声"
  // 而不是"播放中", 免得用户以为死机了。
  // ★为什么不每圈现算: 屏上文字一旦会来回翻, show() 的"整帧跳过"指纹就每帧都变 -> 每帧都真刷屏
  // (软件 SPI 55~60ms) -> 主循环卡顿排出 I2S DMA -> 听感"一直卡卡卡"。所以它必须单调。
  bool     buffering   = false;
  // 曲名原始编码的判定结果(诊断用): "UTF-8" / "GB2312" / "Latin-1"。老中文台常发 GBK,
  // 判定错就会显示成一串乱码, 有了这个字段一眼就能看出判定对不对(串口发 D 或 F 打印)。
  String   titleEnc;
  uint32_t lastMetaMs = 0;     // 最近一次"元数据"数据的时间(独立 ICY 读取器, 仅供诊断)
  int    failCount = 0;        // 连续无音频数据计数(决定重连当前台还是跳下一台)
  bool   audioEverFlowed = false;  // 本次连接是否已真正出过声(用于区分"正在建连"与"播放中卡死")

  float   batteryV = 0;           // 电池电压(V); 主循环节流采样写入(供 /api/state 与 D 诊断)
  bool    charging  = false;      // 是否正在充电(充电 IC CHRG 脚=低); 主循环节流读取写入
  // ---- 天气(320x240 大屏) ----
  WeatherInfo wx;                  // 开机一次 + 每小时一次, 由主循环 weatherTick() 刷新
  bool    timeValid = false;       // 时钟是否已用网络校准(未校准时屏上时间只作参考)

  // ---- 睡眠定时器(2026-10-06 阶段①: 纯软件倒计时, 不进深睡) ----
  // ★仅主循环写(与其它 gState 字段同线程约束); 显示层与 /api/state 只读。
  //   sleepMin       = 用户设定值(分钟), 0=未设定/已取消。
  //   sleepRemainSec = 实时剩余秒数, >0 表示定时器运行中(屏显/Web 据此回显倒计时)。
  //   sleepJustFired = 定时器归零的那一圈由音频模块置位, 主循环据此关屏后清除(一次性标志)。
  int     sleepMin       = 0;
  int     sleepRemainSec = 0;
  bool    sleepJustFired = false;
  // ★"熄屏待机"态(2026-10-08 新增): 睡眠定时器到点后置 true, 表示"设备已停播+熄屏,
  //   但仍在通电待机"。它的唯一用途是让【电源键】在这一态下语义反转 —— 变成"开机"
  //   (亮屏 + 恢复播放), 而不是继续往下关一层。
  //   ★为什么必须单独立一个标志, 不能用别的判据代替:
  //     · 不能用 playing: 用户手动"暂停"也是 playing=false, 那时按电源键应该照旧关机;
  //     · 不能用屏黑(screenOff): 电源键双击"关屏"也会让屏黑, 但设备还在播, 那时按电源键
  //       应该照旧关机(而不是"开机")。
  //   清除时机 = 任意用户输入(按键/红外任意键) 或 重新设定睡眠定时器, 见 webradio-s3p.ino。
  bool    sleepStandby = false;
  // ★到点行为(2026-10-07 加, 区分两套定时器语义):
  //   false = 【睡眠定时器】(面板/后台设的): 到点只"停播 + 熄屏", 设备保持通电,
  //           任意按键经 noteActivity 就能重新点亮(等同旧行为, 不变);
  //           ★且此时置 sleepStandby=true, 电源键语义反转为"开机"(见该字段注释)。
  //   true  = 【定时关机】(红外 IR_TIMER 设的): 到点【真正关机】—— 停播 + 关无线 +
  //           屏灭 + 功放关 + 进深度休眠, 只剩电源键/红外开机键能唤醒。
  // 两者共用同一套倒计时字段(sleepMin/sleepRemainSec), 所以屏上/网页显示的是同一个"剩余时间";
  // 差别只在归零那一刻做什么。若两者都设过, 【后设的赢】(会覆盖 sleepToPowerOff)。
  bool    sleepToPowerOff = false;
  // ★到点真正关机的请求(一次性标志): 音频模块只置位, 由主循环消费并调用 enterDeepSleep()。
  //   ★为什么不让音频模块自己直接进深睡: 深睡会挂起 WiFi/音频泵等一堆任务并让本函数不返回,
  //   而它在 player.loop() 里、处于音频泵持锁的对立面 —— 直接调用极易死锁或状态不一致。
  //   沿用"音频模块置标志、主循环执行"的既有约定(同 gShutdownPending / sleepJustFired)。
  bool    sleepShutdownFired = false;

  // ---- 本地 SD 卡播放(2026-10-07 阶段②) ----
  // 音源标志: sdActive=true 表示当前在放 SD 卡里的文件(而不是网络电台)。
  // ★它决定了两件必须区分处理的事:
  //   1) 看门狗(updatePlaybackWatchdog)不能在 SD 播放时判"断流"并去重连/跳台 ——
  //      一首歌放完是【正常结束】, 会让 isRunning() 归零, 按电台逻辑处理就会莫名跳台。
  //   2) 屏幕第2行的"节目信息"对本地文件没有意义(由 ID3 曲名替代)。
  bool    sdActive = false;   // 当前音源 = SD 卡
  int     sdIndex  = -1;      // 正在播的 SD 文件序号(-1 = 无)
  String  sdName   = "";      // 正在播的 SD 文件名(显示用, 不含扩展名)
  // SD 播放循环方式(2026-10-07 新增): 0=顺序(放完停止) 1=循环全部 2=单曲循环 3=随机
  //   由 SD 列表内"左/右键双击"切换(左=反向一档 / 右=正向一档), 仅主循环写。
  int     sdLoop   = 1;
};

extern PlayerState gState;

// 功放使能脚的当前状态(由主循环 updateAmp() 维护)。定义在 webradio-s3p.ino。
// 供 /api/state 输出: 排查"屏显播放中却没声音"时, 一眼区分
//   ① 功放没开(数据没在流)  ② 功放已开(问题在 I2S/喇叭/接线)。
extern bool gAmpOn;
// 网络侧 TDA1387-A 的供电开关状态(定义在 webradio-s3p.ino, 由 setNetDacPower() 维护)。
// 供 /api/state 诊断"网络侧 DAC 是否通电 / 关机后是否真的断电"。
extern bool gNetDacOn;

/*
 * ---- 分阶段耗时探针(2026-09-18; 2026-09-19 方案B 后含义微调) ----
 * 断音的门槛是 I2S DMA 深度(32x512 帧 => 96000Hz 下 170ms / 44100Hz 下 372ms):
 * 任何一段单次超过它, DMA 必然排空 -> 听得见的"断断续续"。
 * ★方案B 后"被计时的对象"分成两类, 判读时别混:
 *   · PH_AUDIOLOOP 在【音频泵任务】里计时 —— 它才是喂流节奏的真实指标(超 DMA 深度必断音);
 *   · 其余 PH_* 仍测主循环各段耗时 —— 方案B 后它们已不直接推迟喂流, 只影响 UI/交互流畅度。
 * 由 webradio-s3p.ino 的 loop() 写入(泵那段由 audio_player.cpp 的 pumpBody 写),
 * printDiag() 打印并清零。
 */
enum : uint8_t {
  PH_PLAYER = 0,   // player.loop(): 主循环侧(取换台命令 + 元数据推进 + 健康监测 + 静音恢复);
                   //   2026-09-19 起【不再含 audio.loop()】—— 喂流已移到音频泵任务(见 PH_AUDIOLOOP)
  PH_WEB,          // web.loop(): 修正 gState + 重建状态快照
  PH_STORE,        // store.loop(): ★Flash 落盘(三段式: 写 .tmp / 改名 / 删 .bak)
  PH_PORTAL,       // portal.loop(): captive DNS + 断网重连
  PH_IR,           // ir_poll(): 红外波形比对
  PH_BTN,          // 按键 + 功放 + 两道看门狗 + 堆检查 + 心跳 + 串口命令
  PH_DISPLAY,      // updateDisplay(): ★软件 SPI/I2C 整屏刷新(ST7567 或 SSD1306, 见 NVS "disp")
  PH_AUDIOLOOP,    // 音频泵任务里 audio.loop() 的单次耗时(方案B: 与主循环分开计时, 才看得出谁在拖)
  PH_COUNT
};
extern uint32_t g_phMaxUs[PH_COUNT];

/*
 * 崩溃面包屑(见 webradio-s3p.ino): 记录"复位前最后执行到的阶段"。
 * 存在 RTC 不掉电内存里, 软复位/看门狗复位后仍保留 —— 下次启动会把它打印成中文,
 * 从而即使在崩溃时来不及看串口, 也能知道死在"连流/写盘/自检"哪一步。
 */
void markStage(uint32_t s);
uint32_t    lastStage();                  // 读取当前/最后阶段号
const char* stageText(uint32_t s);        // 阶段号 -> 中文说明(Web 诊断页也用)

/* ============================================================================
 * 联网数据层 (2026-10-04 新增; 2026-10-06 由 net_feeds.h 并入本头, 减少文件数)
 * ---------------------------------------------------------------------------
 * 时间/农历/天气, 供显示层与 /api/state 读取。全部"开机取一次, 之后每小时一次"
 * (节流见 config.h 的 WEATHER_POLL_MS)。设计原则: 失败绝不影响主功能 —— 任何一步
 * 失败都只让屏上对应位置显示 "--", 音频/按键/Web 一概照常; 所有耗时操作都带超时,
 * 不把主循环拖死。
 * ========================================================================== */

// ---- 时间(网络授时) ----
void timeInit();                  // 设时区 + 起 NTP + 断电兜底成编译期时间; 幂等可重复调
bool timeSynced();                // 网络校时是否成功过(失败则屏上时间仅作参考)
void timeLocal(struct tm* out);   // 本地(北京时间)日历; 未校时也返回可用的兜底时间

// ---- 农历(公历 -> 干支年 + 生肖 + 月日, 1900-2100 有效) ----
struct LunarInfo {
  char ganZhiYear[8];     // 干支年, 如 "丙午"
  char zodiac[4];         // 生肖,   如 "马"
  char monthDay[20];      // 月+日,  如 "八月廿四" / "闰腊月廿九"(最长 15B, 留余量)
  char dayName[8];        // 日名,   如 "廿四"
  int  monthNum  = 0;     // 农历月 1..12(闰月也用本月号)
  int  dayNum    = 0;     // 农历日 1..30
  bool ok = false;        // 年份是否在 1900-2100 内(不在则 ok=false, 屏上不显示农历)
};
LunarInfo lunarFromSolar(int y, int m, int d);

// ---- 天气(默认免密钥: ipwho.is 定位 + open-meteo 取天气, 按公网 IP 自动定位本地) ----
void weatherInit();                            // 重建网络客户端与 SSL 会话(开机/断网重连后调)
bool weatherFetch(WeatherInfo& out);           // 取一次; 成功 true 并写满 out
void weatherTick();                            // ★主循环每圈调; 内部按小时节流, 顺带维护 gState.timeValid
void        weatherSetUrl(bool isGeo, const char* url);  // 运行时改地址(串口 X/Y, 存 NVS, 空串恢复默认)
const char* weatherGeoUrl();                   // 生效中的地理接口地址
const char* weatherFcUrl();                    // 生效中的天气接口地址

// 7 个中文星期名(显示层用), 索引 = timeLocal().tm_wday
extern const char* const WEEKDAY_CN[7];
