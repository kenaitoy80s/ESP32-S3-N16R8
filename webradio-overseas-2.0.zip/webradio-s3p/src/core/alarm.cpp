#include "alarm.h"
#include <Preferences.h>
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>
#include "../player_state.h"   // timeSynced() / timeLocal()

// ============================================================================
// 每日定时开机(闹钟) —— 设计说明见 alarm.h
// ============================================================================

static AlarmCfg          gCfg;              // 当前配置(受 gMtx 保护)
static SemaphoreHandle_t gMtx   = nullptr;  // 递归锁: Web 异步任务写 / 主循环读
static volatile bool     gDirty = false;    // 有未落盘的改动(任意上下文可置, 只在主循环清)
static int gLastOnDay  = -1;   // 今天"已开播"的日期键(去重: 同一分钟内只触发一次)
static int gLastOffDay = -1;   // 今天"已停播"的日期键

// "今天"的键 = 年*400 + 年内第几天。
// ★不能用 tm_yday 单独当键 —— 跨年时会与上一年的同一天撞车(12/31 触发过后, 次年 1/1 若
//   yday 恰好相同就会被误判为"今天已触发")。乘 400 是因为任意一年最多 366 天。
static int dayKey(const struct tm& t) { return (t.tm_year + 1900) * 400 + t.tm_yday; }

static void clampCfg(AlarmCfg& c) {
  if (c.onH  > 23) c.onH  = 7;
  if (c.onM  > 59) c.onM  = 0;
  if (c.offH > 23) c.offH = 8;
  if (c.offM > 59) c.offM = 0;
}

void alarmBegin() {
  if (!gMtx) gMtx = xSemaphoreCreateRecursiveMutex();
  Preferences p;
  // ★readOnly 必须传 false: 首次开机时命名空间还不存在, NVS_READONLY 打开会失败。
  //   (只读模式建立的命名空间同样会占用 NVS 空间, 但那是几十字节, 换来逻辑简单值得)
  if (!p.begin("alarm", false)) {
    Serial.println("[ALARM] NVS(alarm) 打开失败 -> 使用默认配置(关闭)");
    return;
  }
  AlarmCfg c;
  c.en    = p.getUChar("en",  0) != 0;
  c.onH   = p.getUChar("onh", 7);
  c.onM   = p.getUChar("onm", 0);
  c.offEn = p.getUChar("oen", 0) != 0;
  c.offH  = p.getUChar("ofh", 8);
  c.offM  = p.getUChar("ofm", 0);
  c.url   = p.getString("url",  "");
  c.name  = p.getString("name", "");
  p.end();
  clampCfg(c);
  xSemaphoreTakeRecursive(gMtx, portMAX_DELAY);
  gCfg = c;
  xSemaphoreGiveRecursive(gMtx);
  Serial.printf("[ALARM] 载入: %s | 开播 %02u:%02u -> %s | 停播 %s %02u:%02u\n",
                c.en ? "启用" : "关闭", (unsigned)c.onH, (unsigned)c.onM,
                c.url.length() ? c.url.c_str() : "(未指定电台)",
                c.offEn ? "启用" : "关闭", (unsigned)c.offH, (unsigned)c.offM);
}

AlarmCfg alarmGet() {
  AlarmCfg c;                                  // 默认构造 = 关闭, 未初始化时也不会误触发
  if (!gMtx) return c;
  xSemaphoreTakeRecursive(gMtx, portMAX_DELAY);
  c = gCfg;                                    // String 深拷贝(赋值运算符会分配新缓冲)
  xSemaphoreGiveRecursive(gMtx);
  return c;
}

bool alarmSave(const AlarmCfg& c) {
  if (!gMtx) return false;
  AlarmCfg n = c;
  clampCfg(n);
  xSemaphoreTakeRecursive(gMtx, portMAX_DELAY);
  gCfg   = n;
  gDirty = true;                               // 落盘交给主循环(alarmTick)
  xSemaphoreGiveRecursive(gMtx);
  return true;
}

// 实际写 NVS —— 只在主循环上下文被 alarmTick() 调用。
static void flushNvs() {
  AlarmCfg c;
  xSemaphoreTakeRecursive(gMtx, portMAX_DELAY);
  c = gCfg;
  gDirty = false;                              // 先清脏: 写盘期间再来的新改动会重新置脏
  xSemaphoreGiveRecursive(gMtx);

  Preferences p;
  if (!p.begin("alarm", false)) { Serial.println("[ALARM] 落盘失败: NVS 打不开"); return; }
  p.putUChar("en",  c.en    ? 1 : 0);
  p.putUChar("onh", c.onH);
  p.putUChar("onm", c.onM);
  p.putUChar("oen", c.offEn ? 1 : 0);
  p.putUChar("ofh", c.offH);
  p.putUChar("ofm", c.offM);
  p.putString("url",  c.url);
  p.putString("name", c.name);
  p.end();
  Serial.printf("[ALARM] 已保存: %s | 开播 %02u:%02u -> %s | 停播 %s %02u:%02u\n",
                c.en ? "启用" : "关闭", (unsigned)c.onH, (unsigned)c.onM,
                c.url.length() ? c.url.c_str() : "(未指定电台)",
                c.offEn ? "启用" : "关闭", (unsigned)c.offH, (unsigned)c.offM);
}

AlarmEvent alarmTick() {
  // ---- ① 落盘(主循环上下文; 标脏可能来自 Web 异步任务) ----
  if (gDirty) flushNvs();

  // ---- ② 判定节拍: 每秒看一次日历 ----
  // 用 millis 递增比较, 不假设自己被调用的频率(主循环可能因整屏刷新/落盘而忽快忽慢)。
  static uint32_t lastMs = 0;
  const uint32_t now = millis();
  if ((uint32_t)(now - lastMs) < 1000) return ALARM_NONE;
  lastMs = now;

  const AlarmCfg c = alarmGet();
  if (!c.en || c.url.length() == 0) return ALARM_NONE;
  // 钟不可信(从没校时, 还停在 1970) -> 不触发。宁可闹钟不响, 也不要半夜乱播。
  if (!timeSynced()) return ALARM_NONE;

  struct tm t;
  timeLocal(&t);
  const int today = dayKey(t);

  // 分钟级匹配 + 当日去重: 只要落在设定那一分钟内的任意一次判定都会命中,
  // 命中后当天不再重复(哪怕主循环在这一分钟里跑了几千圈)。
  if ((int)c.onH == t.tm_hour && (int)c.onM == t.tm_min && gLastOnDay != today) {
    gLastOnDay = today;
    Serial.printf("[ALARM] 到点开播 %02u:%02u -> %s\n",
                  (unsigned)c.onH, (unsigned)c.onM,
                  c.name.length() ? c.name.c_str() : c.url.c_str());
    return ALARM_START;
  }
  if (c.offEn && (int)c.offH == t.tm_hour && (int)c.offM == t.tm_min && gLastOffDay != today) {
    gLastOffDay = today;
    Serial.printf("[ALARM] 到点停播 %02u:%02u\n", (unsigned)c.offH, (unsigned)c.offM);
    return ALARM_STOP;
  }
  return ALARM_NONE;
}
