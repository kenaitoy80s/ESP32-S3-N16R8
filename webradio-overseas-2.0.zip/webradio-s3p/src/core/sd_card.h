#pragma once
#include <Arduino.h>
#include "../config.h"

/*
 * 本地 SD 卡(阶段②) —— SD_MMC 1-bit。
 *
 * ---- 为什么用 SD_MMC 而不是 SPI 的 SD ----
 *   1) 引脚: 本板 SPI 总线(SCK/MOSI)已被三块屏共用(见 config.h 的"公共总线"), 不能再挂 SD;
 *      而 SD_MMC 走独立的 SDMMC 外设 + GPIO Matrix, 与任何现有外设都不冲突, 只需 3 根空闲脚。
 *   2) 速度: 1-bit 理论 4MB/s, 对 128~320kbps 的音频绰绰有余(流式电台才需要带宽, 本地文件不需要)。
 *   3) 占用: 不占 DMA/不占中断, 与音频泵任务互不干扰。
 *
 * ---- 为什么不用库的 connecttoSD ----
 *   ESP32-audioI2S 的 connecttoSD() 内部写死了全局 `SD`(即 SPI SD 对象), 而本工程用的是
 *   SD_MMC, 两者不是同一个对象 -> 必须用库的通用接口 connecttoFS(SD_MMC, path)。
 *   (见 audio_player.cpp 的 execPlaySd)
 *
 * ---- 线程模型 ----
 *   ★本模块的所有函数【只允许主循环调用】(与 station_store / bgSave 同一约束):
 *     SD 卡驱动(sdmmc_host_*)不是线程安全的, 且目录扫描会做大量 FAT 查表, 放在 async_tcp
 *     任务里会与音频泵抢总线, 表现为"播放卡顿"。Web 后台只投递命令, 由主循环执行。
 */

/* 文件项: name 给屏幕/网页显示, path 给解码器实际打开 */
struct SdAudioFile {
  String name;   // 显示名(纯文件名, 不含目录与扩展名)
  String path;   // 路径, 形如 "/song.mp3" 或 "/album/song.mp3"
                // ★★【以 "/" 开头, 不含挂载点 "/sdcard"】—— core 3.x 的 VFS 语义:
                //   挂载后根目录就是 "/", open() 不拼挂载点前缀(详见 sd_card.cpp 的说明宏)。
                //   这个值可以直接喂给 audio.connecttoFS(SD_MMC, path)。
};

class SdCard {
public:
  // 挂载 SD 卡(1-bit)。返回 false = 未插卡/接线错/卡不支持(不格式化, 见头文件说明)。
  // 幂等: 已挂载时直接返回 true。
  bool begin();

  // 卸载(关机/切走时用)。幂等。
  void end();

  bool mounted() const { return mMounted; }

  // 扫描根目录, 收集可播放的音频文件(按名称自然序)。
  // 返回文件个数; 失败返回 -1。每次调用都会重建 mFiles。
  // 只扫根目录(平铺), 不递归子目录 —— 用户确认的方案就是"平铺列表顺序播放"。
  int scan();

  int count() const { return (int)mFiles.size(); }
  const SdAudioFile* file(int i) const {
    if (i < 0 || i >= (int)mFiles.size()) return nullptr;
    return &mFiles[i];
  }

  // ★给显示层用的一整块"显示名"数组: showList() 要的是 const String* + 数量,
  //   而 mFiles 里是 SdAudioFile 结构体(取 .name 要逐个解引用, 不能直接喂给 showList)。
  //   所以 scan() 时同步维护这份扁平数组 —— 与 mFiles 始终同序同长度。
  const String* names() const { return mNames.empty() ? nullptr : mNames.data(); }
  const String& pathAt(int i) const {
    static const String kEmpty;
    return (i >= 0 && i < (int)mFiles.size()) ? mFiles[i].path : kEmpty;
  }

  // 扩展名白名单判定(公开是为了让 Web 侧复用同一套规则)
  static bool isPlayableExt(const String& filename);

  // ---- 上次播放位置记忆(2026-10-07: 切到 SD 后接着上次那首播) ----
  // ★存【序号】而不是文件名: 文件名可能改/删, 序号会漂, 靠名字回退反而更不可靠;
  //   而扫出来的列表本身就是按名排序的, 序号本身是稳定的。
  // ★存在 NVS(命名空间 "sd", 键 "last"/"name"), 不写 LittleFS:
  //   这只是 1 个 int + 1 个短字符串, 用 NVS 最省事(不碰电台列表那个 JSON,
  //   避免把 SD 状态和电台列表的落盘时机绑在一起)。
  void loadLast();          // 开机读NVS(在 begin() 之后、scan() 之前调)
  void setLast(int idx) { mLastIndex = idx; }   // 记录当前序号(仅改内存; 落盘请另调 saveLast)
  void saveLast();          // 播放到某首时调用(内部去重: 同一首不重复写, 防刷 NVS)
  int  lastIndex() const { return mLastIndex; }
  // 按记忆恢复: 先按序号; 越界(换了卡/文件少了)则钳到有效范围; 卡里一首都没有返回 -1。
  int  resolveLast() const;

private:
  bool      mMounted = false;
  std::vector<SdAudioFile> mFiles;   // ★只在主循环写/读, 无需加锁(同 station_store 的取舍)
  std::vector<String>      mNames;   // 与 mFiles 同序的"显示名"扁平数组(供 display.showList)
  int       mLastIndex = -1;         // 上次播的序号(-1=未知)
  int       mSavedIndex = -2;// 已写入 NVS 的序号(-2=尚未写过;用于"变了才写"去重)
};

// 全局唯一实例(定义在 sd_card.cpp)。与 StationStore/DisplayUI 等同类一样是全局单例,
// 因为 SD 卡驱动本身是全局的(SD_MMC), 多实例没有意义。
extern SdCard gSd;