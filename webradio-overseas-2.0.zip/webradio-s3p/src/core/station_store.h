#pragma once
#include <Arduino.h>
#include <vector>
#include <ArduinoJson.h>
#include "../config.h"   // VOLUME_DEFAULT

/*
 * 电台列表 + 音量持久化 (LittleFS JSON)
 * 文件: /stations.json  -> { "lastIndex":0, "volume":12, "stations":[{"name","url"}] }
 *
 * 【2026-09-18 S3 版改 LittleFS】原来用 SPIFFS; 换掉的原因见 station_store.cpp 顶部注释
 * (SPIFFS 的 RAM 占用随分区线性增长, 配不了 16MB flash 的大分区; 且掉电一致性差)。
 * 分区仍是分区表里 label=spiffs 的那个, 只是驱动换成 LittleFS, 代码 API 完全一致。
 *
 * 持久化采用"延迟落盘 + 主循环写盘"(借鉴 yoradio 的延迟保存思路):
 *   所有增删改只更新内存并 markDirty(), 真正的文件写由 store.loop()
 *   在 Arduino 主循环中执行, 绝不在 WebSocket/LwIP 网络回调里直接写盘。
 *   原因: ESPAsyncWebServer 的 WS 回调跑在网络任务上下文, 在其中做文件
 *   I/O 在 ESP32 上不可靠, 会导致文件写半截损坏; 重启后 deserializeJson
 *   失败 -> list 为空 -> begin() 误触发 loadDefaults 复活默认台, 表现为
 *   "删了的台又出现"。
 *
 *   写盘先写 /stations.json.tmp 再 rename 覆盖, 即使写中断旧文件也不丢。
 *
 * 【并发保护 —— 修"后台操作死机"】
 * Web 的电台增删改/导入跑在 ESPAsyncWebServer 的异步任务上下文, 而主循环
 * (播放/显示/落盘) 同时在读同一份 list:
 *   - push_back/erase 会让 std::vector 重新分配 -> 主循环正在 name(i)/url(i)
 *     读到的 String 引用瞬间悬空 -> 堆损坏死机;
 *   - 异步任务的 saveNow() 与主循环的 loop()->flush() 可能同时写文件系统。
 * 因此所有公开方法统一持一把【递归锁】(递归是因为存在 saveNow()->flush()
 * 这类嵌套调用)。
 */
class StationStore {
public:
  bool begin();                 // 挂载 LittleFS, 加载或创建默认列表
  void loop();                  // 主循环调用: dirty 且超时则落盘(关键!)
  int  count();
  String name(int i);
  String url(int i);
  String group(int i);          // 分类(2026-10-06): 空/未分类 -> 返回 "未分类"
  int  getLast();
  void setLast(int i);

  int  getVolume();             // 读取已记忆音量
  void saveVolume(int v);       // 记忆音量(标记落盘)

  bool add(const String& name, const String& url, const String& group = "");
  bool update(int i, const String& name, const String& url, const String& group = "");
  bool remove(int i);
  bool replaceAll(const JsonArray& arr);   // 整体替换列表(Web端提交整份 playlist)
  void clearAll();                         // 清空列表(导入"替换"模式用)
  bool hasUrl(const String& u);            // 查重(导入去重用; 整段加锁遍历)
  // ★批量设置分类(2026-10-07; 后台电台列表"多选 + 统一设分类"用)。
  // ids = 要改的真实下标集合(来自列表勾选); newGroup = 目标分类(空串 = 归入"未分类")。
  // 返回【实际改动了几台】(已是该分类的不算, 便于如实回报)。
  // ★全程持锁: 调用方在 async_tcp 任务上下文, 与主循环的读取并发会触发 vector 重分配竞争。
  //   批量操作是"一次改多台", 用单条 update() 循环会反复加解锁, 这里一次性做完更稳。
  int  setGroupBatch(const std::vector<int>& ids, const String& newGroup);
  // 批量导入(CSV/TSV 文本, 2026-09-18 恢复):
  //   每行 "名称<分隔符>地址", 分隔符自动识别 Tab / 逗号 / 分号; 只写地址也可(自动命名);
  //   跳过空行与 # 注释行; url 必须含 "://" 或 "//" 否则整行忽略(滤掉表头/说明)。
  //   replace=true -> 先清空再导入; false -> 按 URL 去重后追加。
  //   返回实际写入(新增)的台数。可在异步任务调用(只改内存 + 置脏标, 不写盘)。
  int  importText(const String& text, bool replace);
  void resetToDefaults();       // 一键恢复出厂电台表(清掉残留/损坏配置 -> 内置国内台) + 立即落盘
  void markDirty();             // 标记需要落盘(不立即写)
  void requestSaveNow();        // [异步任务安全] 请求主循环立刻落盘(不等 600ms 延迟)
  bool saveNow();               // 立即落盘(仅限主循环上下文调用!)
  void buildStationsJson(String& out); // 仅导出电台列表(供 /api/stations 按需返回, 不进周期快照)

private:
  SemaphoreHandle_t mtx = nullptr;   // 递归锁: 保护 list / lastIndex / vol / LittleFS 写
  void lock();
  void unlock();

  // 分类名统一归一化: 空/纯空白 -> "未分类"(前端下拉与列表显示都按它分组)
  static String normGroup(const String& g);
  struct Station { String name; String url; String group; };
  std::vector<Station> list;
  int lastIndex = 0;
  int vol = VOLUME_DEFAULT;
  bool dirty = false;           // 有未落盘的改动
  bool forceFlush = false;      // 请求主循环下一圈立刻落盘(大动作如导入用)
  uint32_t lastDirtyMs = 0;     // 最近一次标记时间
  bool loaded = false;          // 是否已从 LittleFS 成功加载过配置文件

  void load();
  void loadDefaults();
  bool flush();                 // 实际写 LittleFS(写 tmp + rename)
};
