#include "station_store.h"
// 2026-09-18 S3 版: 由 SPIFFS 改为 LittleFS。
//   原因①: SPIFFS 的 RAM 占用随分区大小线性增长(约 4B / 256B 页), 12MB 分区要吃 ~190KB RAM;
//         LittleFS 的 RAM 占用与分区大小无关(固定 1~2KB + 少量缓存), 才配得上 16MB flash 的大分区。
//   原因②: LittleFS 自带掉电一致性(元数据双写), 配合下面的 .tmp/.bak 原子替换更稳。
//   挂载的仍然是分区表里 label=spiffs(SubType=spiffs) 的分区, 只是驱动换成 LittleFS。
#include <LittleFS.h>
#include <ArduinoJson.h>
#include "../config.h"
#include "../player_state.h"   // markStage(): 写盘前打面包屑, 便于定位"写盘途中重启"
#include "audio_player.h"  // icyToUtf8(): 统一编码转换(见下方 normText 注释)

// ---- 递归锁: 异步任务(Web增删改)与主循环(读取/落盘)互斥 ----
void StationStore::lock()   { if (mtx) xSemaphoreTakeRecursive(mtx, portMAX_DELAY); }
void StationStore::unlock() { if (mtx) xSemaphoreGiveRecursive(mtx); }

// 诊断: 原样打印配置文件开头若干字节。用于判断"设备文件系统里到底存了什么电台"——
// 之前的排障全靠猜(配置里到底是不是那 3 个 SomaFM), 这一行直接把答案打出来。
static void dumpConfigRaw(size_t maxBytes) {
  File f = LittleFS.open(STATION_FILE, "r");
  if (!f) { Serial.println("[Store] (无 " STATION_FILE " 文件)"); return; }
  String s;
  while (f.available() && s.length() < maxBytes) s += (char)f.read();
  f.close();
  Serial.println("[Store] 配置原文: " + s);
}

// ============ URL 清洗(2026-09-18 修"导入的电台全部无声") ============
// 【症状】手动添加的电台能正常播放, 用 CSV/TSV 文件导入的一律没声音。
// 【根因】用户的 playlist 是【三列 TSV】, 形如:
//       大猫怀旧音乐 <TAB> http://218.6.164.56:7999/01 <TAB> 0
//   而旧解析只按【第一个】分隔符切一刀, 于是地址字段把后面所有列都粘了进来:
//       url = "http://218.6.164.56:7999/01\t0"
//   .trim() 只去首尾空白, 中间的 \t 和 0 原样保留。库拿这个地址建连时,
//   请求行变成 "GET /01\t0 HTTP/1.1" -> 服务器不认 -> 建连/解码失败 ->
//   表现为"屏幕显示播放中却完全没有声音"(probeCodec 只看 Content-Type 所以查不出来)。
//
// 【为什么"遇到空白就截断"而不是"删掉所有空白"】
//   若只是剔除 \t, "…/01\t0" 会粘成 "…/010" —— 地址还是错的(而且错得更隐蔽)。
//   从左往右扫描、遇到第一个空白/控制字符立即停止, 才能真正砍掉尾巴上的 "\t0"。
//   这同时也修好了历史脏数据: load() 里对每条地址都跑一遍, 旧文件里的坏地址会被自动修正。
static String cleanUrl(const String& raw) {
  const int n = (int)raw.length();
  int i = 0;
  // 1) 跳过前导空白与 CSV 常见的包裹双引号
  while (i < n && ((uint8_t)raw[i] <= 0x20 || raw[i] == '"')) i++;
  // 2) 从左往右收集, 遇到空白/控制字符/双引号立即停止
  String out;
  out.reserve(n - i);
  for (; i < n; i++) {
    const char c = raw[i];
    if ((uint8_t)c <= 0x20) break;   // 空格 / Tab / CR / LF / 其他控制字符
    if (c == '"') break;             // 闭合引号(CVS 导出常见)
    out += c;
  }
  return out;
}

// 分类名归一化(2026-10-06 加分类功能): 空/纯空白 -> "未分类"。
// 作用: 旧 stations.json 里没有 group 字段, load() 读到的是空串; 前端下拉与列表
// 分组都按"非空字符串"处理, 统一成一个常量名才不会漏出空分类标题。
// ★统一编码入口(2026-10-07): 台名/分类在【入库前】一律转成 UTF-8。
//   为什么必须: 台名可能来自 GBK 存法的 stations.json, 或用户用 Excel 另存的 CSV(GBK)。
//   坏字节会让后台 JSON(声明 UTF-8)显示成"è¡å½å"这类乱码, 屏上 drawUTF8 遇到非法
//   UTF-8 会整字跳过 -> 画成空方框。之前只有曲名走了icyToUtf8, 台名这一路漏了。
//   为什么放"入库前"而不是每次读: 转一次、全路径受益(屏幕/后台/串口都拿到干净字符串),
//   也避免同一段坏字节被反复判别。
static inline String normText(const String& s) { return icyToUtf8(s.c_str()); }

String StationStore::normGroup(const String& g) {
  String t = g;
  t.trim();
  return t.length() ? t : String("未分类");
}

bool StationStore::begin() {
  mtx = xSemaphoreCreateRecursiveMutex();
  // ---- 挂载策略(2026-09-18 改) ----
  // 先"只挂载不格式化": 它快, 且绝不动已有数据。只有确认挂不上(全新分区, 或上次写入被
  // 断电/复位打断导致元数据损坏)时, 才显式格式化一次 —— 并把耗时打出来。
  // ★为什么不能直接 LittleFS.begin(true) 一把梭: 格式化要逐块擦除整个分区(1MB≈8s, 4MB≈30s),
  //   期间主循环完全阻塞, 屏幕会长时间停在"开机中"; 更糟的是若格式化因任何原因反复失败,
  //   就会变成"每次开机都在格式化"的死循环 —— 用户只能拔电。把"要不要格式化"变成显式决策,
  //   配合 config.h 的 BOOT_WDT_MS 启动兜底, 就不会再出现永久卡死。
  bool mounted = LittleFS.begin(false);
  if (!mounted) {
    Serial.println("[Store] 文件系统未挂载(全新分区 / 上次写入被打断) -> 格式化一次...");
    uint32_t t0 = millis();
    mounted = LittleFS.begin(true);
    Serial.printf("[Store] 格式化+挂载 %s, 用时 %lums\n",
                  mounted ? "成功" : "★失败", (unsigned long)(millis() - t0));
  }
  if (!mounted) {
    Serial.println("[Store] ★文件系统不可用: 电台/音量改动将【不会保存】");
    Serial.println("[Store]   可能原因: 分区表缺 label=spiffs 的分区 / flash 硬件异常");
    // 仍然载入内置电台, 让机器"能用"(只是不持久), 并在屏幕上提示, 避免变成一块砖
    loadDefaults();
    gState.status = "存储故障";
    return false;
  }
  Serial.printf("[Store] 文件系统挂载成功: 总 %u B / 已用 %u B\n",
                (unsigned)LittleFS.totalBytes(), (unsigned)LittleFS.usedBytes());
  dumpConfigRaw(300);            // 打印真实存盘内容(判定"电台为何不对"的第一手证据)
  load();
  if (!loaded) {                 // 仅当从未成功加载过配置(无文件)时才填默认
    Serial.println("[Store] 首次启动/配置缺失 -> 载入内置默认电台");
    loadDefaults();
    flush();                     // 写入默认配置
  }
  if (lastIndex >= (int)list.size()) lastIndex = 0;
  Serial.printf("[Store] 配置就绪: %u 台, 音量=%d, lastIndex=%d\n",
                (unsigned)list.size(), vol, lastIndex);
  for (int i = 0; i < (int)list.size() && i < 20; i++) {   // 逐条列出, 一眼看出播的是不是国外源
    Serial.printf("[Store]   #%d %s | %s\n", i, list[i].name.c_str(), list[i].url.c_str());
  }
  return true;
}

void StationStore::load() {
  lock();
  // 兜底①: 主文件缺失但存在 .bak(上次落盘过程中被断电/重启) -> 从备份恢复。
  const String bak = String(STATION_FILE) + ".bak";
  if (!LittleFS.exists(STATION_FILE) && LittleFS.exists(bak)) {
    Serial.println("[Store] 主配置缺失, 检测到 .bak 备份 -> 已恢复");
    LittleFS.rename(bak, STATION_FILE);
  }
  File f = LittleFS.open(STATION_FILE, "r");
  if (!f) { Serial.println("[Store] 无配置文件, 使用默认"); unlock(); return; }
  JsonDocument doc;
  DeserializationError err = deserializeJson(doc, f);
  f.close();
  if (err) { Serial.println("[Store] JSON 解析失败, 文件可能损坏(已保留旧文件)"); unlock(); return; }
  loaded = true;                 // 文件存在且可解析 = 已有配置, 不再复活默认台
  lastIndex = doc["lastIndex"] | 0;
  // ★音量量程 2026-09-22 由 0..21 改为 0..99。旧配置里没有 volRange 标记, 其 volume 是
  //   "库原始档位"(0..21), 必须按比例换算过去 —— 否则旧的 12 会被当成 12/99 读, 音量骤降。
  //   换算只做一次(结果立刻落盘, 见下面 set dirty/forceFlush)。
  if (doc["volRange"].as<int>() == VOLUME_MAX) {
    vol = constrain((int)(doc["volume"] | VOLUME_DEFAULT), 0, VOLUME_MAX);
  } else {
    const int oldV = doc["volume"] | -1;             // -1 = 文件里根本没这个字段
    vol = (oldV < 0) ? VOLUME_DEFAULT
                     : constrain((oldV * VOLUME_MAX + VOLUME_LIB_MAX / 2) / VOLUME_LIB_MAX, 0, VOLUME_MAX);
    if (oldV >= 0) {
      Serial.printf("[Store] 音量量程升级: 旧 %d/21 -> %d/99\n", oldV, vol);
      dirty = true; forceFlush = true;               // 一次性迁移, 立刻落盘
    }
  }
  JsonArray arr = doc["stations"];
  bool urlCleaned = false;                 // 是否修正过脏地址(见 cleanUrl 注释)
  if (arr) {
    for (JsonObject o : arr) {
      Station s;
      s.name = normText(o["name"].as<String>());
      s.group = normGroup(normText(o["group"].as<String>()));   // 旧文件无 group -> "未分类"
      const String raw = o["url"].as<String>();
      s.url  = cleanUrl(raw);
      if (s.url != raw) {
        urlCleaned = true;
        Serial.printf("[Store] ★修正脏地址: \"%s\" -> \"%s\"\n", raw.c_str(), s.url.c_str());
      }
      list.push_back(s);
    }
  }
  // 历史脏数据(旧版导入把后面几列粘进了地址, 如 ".../01\t0")修好后立刻落盘,
  // 否则下次开机又要重修一遍; 也保证 Web 页面/串口看到的就是可播的真实地址。
  if (urlCleaned) { dirty = true; forceFlush = true; }
  // 兜底②: 清理残留(空地址 / 国外源 somafm.com)。
  // 注意: .m3u8(HLS) 不再清理 —— 2.0.6 库已支持 HLS 播放列表(走库内流程, 见 audio_player.cpp)。
  size_t before = list.size();
  for (auto it = list.begin(); it != list.end(); ) {
    if (it->url.length() == 0 ||
        it->url.indexOf("somafm.com") >= 0) it = list.erase(it);
    else ++it;
  }
  if (list.size() != before) {
    Serial.printf("[Store] 清理不可用残留电台: %u -> %u 台(空地址/SomaFM国外源)\n",
                  (unsigned)before, (unsigned)list.size());
    dirty = true; forceFlush = true;             // 清理结果立刻落盘
  }
  // 清理后一台不剩(整份配置都是残留) -> 载入内置国内台
  if (list.empty()) {
    Serial.println("[Store] 清理后无可用电台 -> 载入内置国内台");
    loadDefaults();                              // 递归锁, 可重入
    dirty = true; forceFlush = true;
  }
  unlock();
}

// 一键恢复出厂电台表(串口发 R 触发): 清掉残留/损坏配置, 重建内置国内台并立即落盘。
// 排障用 —— 不必再依赖 Web 后台重新导入 CSV。
void StationStore::resetToDefaults() {
  Serial.println("[Store] 手动恢复出厂电台表...");
  lock();
  list.clear();
  unlock();
  loadDefaults();
  lastIndex = 0;
  lock(); dirty = true; forceFlush = true; unlock();
  bool ok = saveNow();          // 立即落盘(主循环上下文调用)
  Serial.printf("[Store] 恢复完成: %d 台, 落盘%s\n",
                count(), ok ? "成功" : "失败");
}

// 内置默认电台(仅在 LittleFS 无配置 / 配置损坏时使用)。前 5 个是最稳的 MP3 直连台,
// 排在前面 -> 开机续播优先落在它们上。末尾额外保留一个已验证可播的 HLS(m3u8) 台
// (CNR中国之声) —— 2.0.6 库自带 HLS 流程, 无 PSRAM 下也能出声。
void StationStore::loadDefaults() {
  lock();
  list.clear();
  // 2026-09-16: 精简版默认表。只保留实测为 audio/mpeg(MP3) 的直连流(AAC 台可自行添加)。
  // 大猫系列: /01 /02 /04 /05 为 MP3; /03 为 AAC(已移除)。
  // AsiaFM 仅 /myradio 是 MP3(其余为 aacp, 已移除)。
  list.push_back({"大猫怀旧音乐",     "http://183.220.53.251:7999/01", "大猫系列"});
  list.push_back({"大猫榜单音乐",     "http://183.220.53.251:7999/02", "大猫系列"});
  list.push_back({"大猫随便听",       "http://183.220.53.251:7999/04", "大猫系列"});
  list.push_back({"大猫点歌台",       "http://218.6.164.56:7999/05",  "大猫系列"});
  list.push_back({"AsiaFM(MP3)",      "http://asiafm.hk:8000/myradio", "音乐台"});
  list.push_back({"CNR中国之声HLS",   "http://ngcdn002.cnr.cn/live/zgzs/index.m3u8", "新闻台"});  // HLS(m3u8) 已验证可播
  unlock();
}

// 实际写盘: 先写临时文件再 rename 覆盖, 防止网络回调/断电造成半截文件
bool StationStore::flush() {
  // 锁内只快照要落盘的数据, 立即释放锁再做慢速 LittleFS 写(写盘会禁用 flash cache 短暂冻核)。
  lock();
  int li = lastIndex;
  int v  = vol;
  std::vector<String> names, urls, groups;      // 拷出, 避免持锁期间 list 被异步任务改动
  names.reserve(list.size());
  urls.reserve(list.size());
  groups.reserve(list.size());
  for (auto& s : list) { names.push_back(s.name); urls.push_back(s.url); groups.push_back(s.group); }
  unlock();

  JsonDocument doc;
  doc["lastIndex"] = li;
  doc["volume"]    = v;
  doc["volRange"]  = VOLUME_MAX;   // 量程标记: 读到它才按 0..99 直读(见 load)
  JsonArray arr = doc.createNestedArray("stations");
  for (size_t i = 0; i < names.size(); i++) {
    JsonObject o = arr.createNestedObject();
    o["name"]  = names[i];
    o["url"]   = urls[i];
    o["group"] = groups[i];              // 分类(旧文件无此字段时 load 会回落 "未分类")
  }
  // ---- 原子替换: 主文件 / .tmp(新内容) / .bak(旧内容保底), 任何一步失败都能从 .bak 回滚 ----
  const String tmp = String(STATION_FILE) + ".tmp";
  const String bak = String(STATION_FILE) + ".bak";

  File f = LittleFS.open(tmp, "w");
  if (!f) {
    Serial.printf("[Store] 写盘失败! 无法创建 %s (文件系统空间不足? 已用%u/%uB)\n",
                  tmp.c_str(), (unsigned)LittleFS.usedBytes(), (unsigned)LittleFS.totalBytes());
    return false;
  }
  const size_t written = serializeJson(doc, f);
  // ★必须先 close() 再校验大小: ESP32 的 LittleFS File 走 VFS 全缓冲(stdio buffer),
  //   serializeJson 仅把字节写进内存缓冲(返回 written=447), 此时磁盘上仍是 0 字节;
  //   若在这里直接 f.size()(内部 stat() 只认"已提交到磁盘"的大小)会得到 0 ->
  //   误判"落盘异常"丢弃一次完全正常的写, 且因失败不清除 forceFlush, 主循环每圈都重试
  //   (open/remove 反复刷 flash 冻核) -> 音频卡顿。正确做法: 先 close() 把缓冲刷进
  //   flash, 再重开只读取真实落盘大小。
  f.close();
  const size_t onDisk = ([&]() -> size_t {
    File r = LittleFS.open(tmp, "r");
    if (!r) return 0;
    size_t s = r.size();
    r.close();
    return s;
  })();
  // ★短写校验: 真正判据是"磁盘实际字节数 == serializeJson 报告写入数"。分区写满 / flash
  //   异常时 fwrite 会提前返回部分字节或写 0, 关文件后仍会是半截 / 0, 此时宁可放弃
  //   (原配置未动), 也不能用半截文件覆盖好文件(否则开机 deserializeJson 失败 ->
  //   误判配置缺失 -> 复活默认台 = 用户报过的"删掉的台又出现")。
  if (written == 0 || onDisk != written) {
    LittleFS.remove(tmp);
    Serial.printf("[Store] 落盘字节数异常(写入%u / 实际%u), 已放弃本次落盘(原配置未动; 剩余空间 %uB)\n",
                  (unsigned)written, (unsigned)onDisk,
                  (unsigned)(LittleFS.totalBytes() - LittleFS.usedBytes()));
    // ★失败也要解除 forceFlush, 否则会每圈主循环重试(forceFlush 不受 600ms 节流),
    //   反复 open/remove 刷 flash 冻核 -> 卡顿。dirty 保留(改动不丢), 退化为 600ms 节流重试。
    lock(); forceFlush = false; unlock();
    return false;
  }

  // 旧主文件 -> .bak
  if (LittleFS.exists(bak)) LittleFS.remove(bak);
  bool hadOld = LittleFS.exists(STATION_FILE);
  if (hadOld && !LittleFS.rename(STATION_FILE, bak)) {
    LittleFS.remove(tmp);              // 保底都失败: 宁可不落盘, 也不能丢整个列表
    Serial.println("[Store] 备份旧配置失败, 已放弃本次落盘(旧配置完好)");
    return false;
  }
  // 新内容 -> 主文件
  if (!LittleFS.rename(tmp, STATION_FILE)) {
    if (hadOld) LittleFS.rename(bak, STATION_FILE);   // 回滚, 恢复旧配置
    LittleFS.remove(tmp);
    Serial.println("[Store] rename 失败, 已回滚到旧配置(列表未丢)");
    return false;
  }
  LittleFS.remove(bak);                              // 新配置已就位, 备份可删
  lock(); dirty = false; forceFlush = false; unlock();   // 成功才清脏标
  Serial.printf("[Store] 已写盘 %s 共%u台 (%u B)\n",
                STATION_FILE, (unsigned)names.size(), (unsigned)written);
  return true;
}

// 仅导出电台列表(供 /api/stations 按需返回), 不进周期状态快照。
// 关键: 大列表若每 1.2s/3s 反复序列化进 /api/state, 会在无 PSRAM 板上持续
// 产生大块 heap 分配 -> 碎片累积 -> 音频解码 malloc 失败 -> 播放卡顿。
void StationStore::buildStationsJson(String& out) {
  lock();
  JsonDocument doc;
  JsonArray arr = doc.createNestedArray("stations");
  for (auto& s : list) {
    JsonObject o = arr.createNestedObject();
    o["name"]  = s.name;
    o["url"]   = s.url;
    o["group"] = s.group;
  }
  out = "";
  serializeJson(doc, out);
  unlock();
}

void StationStore::markDirty() {
  lock();
  dirty = true;
  lastDirtyMs = millis();
  unlock();
}

void StationStore::loop() {
  // 落盘时机: forceFlush(导入等大动作要求立刻落盘) 或 dirty 且距最近改动 > 600ms
  // (避开播放/网络忙时频繁写盘, 用户删除/编辑后通常停留数秒, 足够落盘)。
  // ★本函数只在主循环被调用 —— LittleFS 写盘绝不能放在 WebSocket/async_tcp 异步任务
  //   上下文, 那里写盘不可靠(见头文件说明), 这是"导入的电台重启后丢失"的根因之一。
  lock();
  bool need = dirty && (forceFlush || (millis() - lastDirtyMs > 600));
  unlock();
  if (need) { markStage(21); flush(); markStage(6); }
}

// [异步任务安全] 只置标志, 真正的落盘由主循环 loop() 立刻执行。
// 供 Web 异步回调(导入/批量操作)使用 —— 那里绝不能直接调 saveNow()。
void StationStore::requestSaveNow() {
  lock();
  dirty = true;
  forceFlush = true;
  lastDirtyMs = millis();
  unlock();
}

// 立即落盘。★仅限主循环上下文调用(会直接做 LittleFS I/O, 异步任务里调不可靠)。
bool StationStore::saveNow() { markStage(21); bool r = flush(); markStage(6); return r; }

// ---- 以下访问器/修改器统一加锁: 主循环与 Web 异步任务共用同一份 list ----
int  StationStore::count() { lock(); int n = (int)list.size(); unlock(); return n; }

String StationStore::name(int i) {
  lock();
  String s = (i >= 0 && i < (int)list.size()) ? list[i].name : String("");
  unlock();
  return s;   // 先拷出来再解锁: 不能返回 list 内部引用(解锁后可能失效)
}
String StationStore::url(int i) {
  lock();
  String s = (i >= 0 && i < (int)list.size()) ? list[i].url  : String("");
  unlock();
  return s;
}
String StationStore::group(int i) {
  lock();
  String s = (i >= 0 && i < (int)list.size()) ? list[i].group : String("未分类");
  unlock();
  return s;
}
int  StationStore::getLast()  { lock(); int v = lastIndex; unlock(); return v; }
void StationStore::setLast(int i){ lock(); lastIndex = i; dirty = true; lastDirtyMs = millis(); unlock(); }
// (原 firstPlainIndex()「第一个非 HLS 台」已删除: 那是"开机自动续播跳过 HLS"时代的产物,
//  该逻辑已于 2026-09-19 取消(用户要求续播真正的上次电台, 含 HLS), 此后再无调用者。)
int  StationStore::getVolume(){ lock(); int v = vol; unlock(); return v; }
void StationStore::saveVolume(int v){ lock(); vol = constrain(v, 0, VOLUME_MAX); dirty = true; lastDirtyMs = millis(); unlock(); }

bool StationStore::add(const String& name, const String& url, const String& group) {
  const String u = cleanUrl(url);            // 后台手填/粘贴也可能带上空白, 统一清洗
  if (name.isEmpty() || u.isEmpty()) return false;
  lock();
  list.push_back({normText(name), u, normGroup(normText(group))});     // 可能触发 vector 重新分配 -> 必须与读端互斥
  dirty = true; lastDirtyMs = millis();
  unlock();
  return true;
}

bool StationStore::update(int i, const String& name, const String& url, const String& group) {
  lock();
  if (i < 0 || i >= (int)list.size()) { unlock(); return false; }
  if (!name.isEmpty()) list[i].name = normText(name);
  if (!url.isEmpty())  list[i].url  = cleanUrl(url);   // 同上: 统一清洗
  // 分类: 空串表示"不改动"(旧版页面/导入不带 group 时保持原分类)
  if (group.length()) list[i].group = normGroup(normText(group));
  dirty = true; lastDirtyMs = millis();
  unlock();
  return true;
}

// 批量设置分类(2026-10-07): 后台列表多选后统一改分类。
// 一次加解锁做完, 而不是循环调 update() —— 后者每次都加解锁, 中间会让主循环插进来读到
// "改了一半"的中间态(例如 3 台里改了 2 台时, 列表刷新出来就是不一致的分类)。
int StationStore::setGroupBatch(const std::vector<int>& ids, const String& newGroup) {
  lock();
  const String g = normGroup(normText(newGroup));      // 空 -> "未分类"(与单台编辑同一套归一规则)
  int changed = 0;
  for (size_t k = 0; k < ids.size(); k++) {
    const int i = ids[k];
    if (i < 0 || i >= (int)list.size()) continue;    // 越界静默跳过(勾选后列表可能已变)
    if (list[i].group == g) continue;                // 已经是目标分类, 不必重写(省 flash)
    list[i].group = g;
    changed++;
  }
  if (changed) { dirty = true; lastDirtyMs = millis(); }
  unlock();
  return changed;
}

bool StationStore::remove(int i) {
  lock();
  if (i < 0 || i >= (int)list.size()) { unlock(); return false; }
  list.erase(list.begin() + i);
  if (lastIndex >= (int)list.size()) lastIndex = 0;
  dirty = true; lastDirtyMs = millis();
  unlock();
  return true;
}

bool StationStore::replaceAll(const JsonArray& arr) {
  lock();
  list.clear();
  for (JsonObject o : arr) {
    list.push_back({ normText(o["name"].as<String>()), cleanUrl(o["url"].as<String>()),
                     normGroup(normText(o["group"].as<String>())) });
  }
  if (lastIndex >= (int)list.size()) lastIndex = 0;
  dirty = true; lastDirtyMs = millis();
  unlock();
  return true;
}

void StationStore::clearAll() {
  lock();
  list.clear();
  lastIndex = 0;
  dirty = true; lastDirtyMs = millis();
  unlock();
}

// 按地址查重(导入去重用): 整段加锁, 避免遍历期间 list 被异步任务改动
bool StationStore::hasUrl(const String& u) {
  lock();
  bool found = false;
  for (auto& s : list) if (s.url == u) { found = true; break; }
  unlock();
  return found;
}

// ============ 批量导入(CSV/TSV 文本) —— 2026-09-18 恢复 ============
// 设计要点:
//   · 解析只动内存(整段持锁), 不碰文件系统 —— 本函数可在 Web 异步任务里安全调用;
//     真正落盘由主循环 store.loop() 完成(异步任务写盘是"导入后重启丢失"的老根因)。
//   · 分隔符自动识别(Tab / 逗号 / 分号), 兼容从 Excel 复制、CSV 导出、TSV 三种来源。
//   · 只有一列且看着像地址的行也能导入(自动命名), 方便直接粘贴一串 URL。
//   · 容量上限保护: 超过 MAX_IMPORT_STATIONS 台的多余行丢弃(防止一份巨大文本把堆吃光)。
int StationStore::importText(const String& text, bool replace) {
  static const int MAX_IMPORT_STATIONS = 300;   // 上限(本工程实际用几十台)
  lock();
  if (replace) { list.clear(); lastIndex = 0; }

  int added = 0;
  int pos   = 0;
  bool firstLine = true;
  const int len = (int)text.length();
  while (pos <= len) {
    int nl = text.indexOf('\n', pos);
    String line = (nl < 0) ? text.substring(pos) : text.substring(pos, nl);
    pos = (nl < 0) ? len + 1 : nl + 1;
    line.replace("\r", "");
    if (firstLine) { line.replace("\xEF\xBB\xBF", ""); firstLine = false; }  // 去 UTF-8 BOM(Excel CSV 常见)
    line.trim();
    if (line.length() == 0) continue;                 // 空行
    if (line[0] == '#') continue;                     // 注释
    if ((int)list.size() >= MAX_IMPORT_STATIONS) break;

    // ---- 切分成字段: Tab / 逗号 / 分号 都算分隔符 ----
    // ★★ 这里绝不能"只按第一个分隔符切一刀"——那正是"导入的电台全部无声"的根因(err bug):
    //   用户的 playlist 是三列 TSV:  大猫怀旧音乐 <TAB> http://218.6.164.56:7999/01 <TAB> 0
    //   旧写法得到 url = "http://218.6.164.56:7999/01\t0" (后面几列全粘在地址尾巴上),
    //   库拿它建连 -> 请求行成了 "GET /01\t0 HTTP/1.1" -> 服务器不认 -> 完全没声音。
    //   新写法: 先切字段, 再"挑"出地址字段与名称字段, 与列数/列顺序都无关。
    String f[8];
    int nf = 0;
    {
      int st = 0;
      const int ln = (int)line.length();
      for (int i = 0; i <= ln && nf < 8; i++) {
        const char c = (i < ln) ? line[i] : '\0';
        if (c == '\t' || c == ',' || c == ';' || c == '\0') {
          if (i > st) f[nf++] = line.substring(st, i);
          st = i + 1;
        }
      }
    }

    // 地址 = 第一个含 "://" 的字段(因此地址在第几列都能认出来);
    //        都没有时退回"形如 host:port"的字段(兼容省略协议的写法)。
    String url;
    int urlIdx = -1;
    for (int i = 0; i < nf; i++) {
      if (f[i].indexOf("://") >= 0) { urlIdx = i; url = cleanUrl(f[i]); break; }
    }
    if (urlIdx < 0) {
      for (int i = 0; i < nf; i++) {
        const String c = cleanUrl(f[i]);
        const int colon = c.indexOf(':');
        if (c.indexOf('.') > 0 && colon > 0 && colon < (int)c.length() - 1) { urlIdx = i; url = c; break; }
      }
    }
    if (url.length() == 0) continue;                    // 本行没有地址 -> 表头/说明行, 跳过
    // 协议段必须是纯字母(http/https/rtsp/rtmp/icy...), 挡掉"地址必须带 http://"这类说明文字
    {
      const int pp = url.indexOf("://");
      if (pp <= 0 || pp > 8) continue;
      bool alpha = true;
      for (int k = 0; k < pp; k++) if (!isAlpha((unsigned char)url[k])) { alpha = false; break; }
      if (!alpha) continue;
    }

    // 名称 = 第一个"既不是地址、也不是纯数字"的字段。
    // 纯数字列(用户表里的 0/1 标记列)必须跳过, 否则电台名会变成 "0"。
    // 分类(可选, 2026-10-06) = 名称之后【下一个】非地址非纯数字字段, 即
    //   "名称,地址,分类" / "名称<TAB>地址<TAB>分类" 都能带进来; 两列时留空 -> "未分类"。
    String name, group;
    bool nameGot = false;
    for (int i = 0; i < nf; i++) {
      if (i == urlIdx) continue;
      String c = f[i]; c.trim();
      if (c.length() == 0) continue;
      bool allDigit = true;
      for (size_t k = 0; k < c.length(); k++)
        if (!isDigit((unsigned char)c[k])) { allDigit = false; break; }
      if (allDigit) continue;
      if (!nameGot) { name = c; nameGot = true; }        // 第一个是名称
      else          { group = c; break; }                 // 第二个是分类
    }

    // 同一个地址只留一条(替换模式下 list 已清空, 仍防文本内部重复)
    bool dup = false;
    for (auto& s : list) if (s.url == url) { dup = true; break; }
    if (dup) continue;
    if (name.length() == 0) name = "电台" + String((int)list.size() + 1);

    // ★2026-10-07 入库前转编码: 这是【GBK 台名进入设备的主入口】—— 用户用 Excel 另存为
    //   CSV 时默认是 GBK, 之前原样入库, 导致后台乱码("è¡å½å")+ 屏上画空方框。
    //   先转再判断"是否纯数字/是否地址"是不行的(转换只影响字形不改结构), 但放在
    //   push_back 前最省事: 之后所有读路径(屏幕/后台/串口)拿到的都是干净 UTF-8。
    String nm  = normText(name);
    String grp = normText(group);
    list.push_back({nm, url, normGroup(grp)});
    added++;
  }
  if (added > 0) { dirty = true; lastDirtyMs = millis(); }
  unlock();
  return added;
}
