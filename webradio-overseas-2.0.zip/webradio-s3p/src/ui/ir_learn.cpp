#include "ir_learn.h"
#include "../config.h"
#include <Preferences.h>

#if IR_ENABLED
#include "driver/rmt_rx.h"
#include "driver/gpio.h"   // gpio_pullup_en: 给接收脚加上拉, 防止模块无内部上拉时浮空收不到

// ---------------- 内部状态 ----------------
static const char* kActionNames[IR_COUNT] = {"prev", "next", "toggle", "volup", "voldown", "power", "rotate", "screen", "sd", "timer"};

// 各动作的"重复触发冷却": 音量键要连续(按遥控重复帧≈110ms 步进), 切换类单击一次即止。
// ★rotate 也走"单击即止"的长冷却: 旋转会整体重建 U8g2 + 重新读入 150KB 背景图(几十 ms),
//   按住不放若按 110ms 的重复帧连发, 会连转好几档且反复读 flash —— 用 1500ms 冷却是防呆。
// ★rotate / screen 也走"单击即止"的长冷却: 两者都会整体重建 U8g2(旋转还要重读 150KB
//   背景图, 切屏要重新 init 一整块屏), 按住不放若按 110ms 重复帧连发会连切好几档且反复
//   读 flash —— 用 1500ms 冷却是防呆。
static uint32_t ir_cooldown_for(IRAction a) {
  if (a == IR_VOLUP || a == IR_VOLDOWN) return IR_VOL_REPEAT_MS;
  // ★IR_TIMER 用中等冷却(350ms)而不是 1500ms: 它要循环切档, 冷却太长会让人觉得"按不动";
  //   350ms 恰好让"想连按 3 次到 3 小时"不至于误触, 又不至于等。
  if (a == IR_TIMER) return IR_TRIGGER_COOLDOWN_MS;
  // ★IR_SD 也走"单击即止"的长冷却(2026-10-07): 切到 SD 音源要挂载卡 + 扫描目录
  //   (几百毫秒的 FAT 遍历), 按住不放若按 110ms 重复帧连发, 会反复挂载/扫描,
  //   表现为"卡被反复扫描、列表反复重进" —— 1500ms 冷却是防呆。
  if (a == IR_TOGGLE || a == IR_POWER || a == IR_ROTATE || a == IR_SCREEN || a == IR_SD)
    return IR_TOGGLE_COOLDOWN_MS;
  return IR_TRIGGER_COOLDOWN_MS;   // prev / next
}

static IRActionCb  gActionCb = nullptr;
static IRHoldCb    gHoldCb   = nullptr;   // "长按"(重复帧)回调
static IRRepeatCb  gRepeatCb = nullptr;   // "该动作是否允许重复帧连续"询问回调
static IRActivityCb gActivityCb = nullptr; // ★2026-10-08: "收到任何像样的红外帧"(不看匹配)
static IRNotifyCb  gNotifyCb = nullptr;

static rmt_channel_handle_t gRxChan = nullptr;
static rmt_symbol_word_t    gSymbols[128];       // RMT 硬件接收缓冲(128 符号 = 256 边沿, 够 NEC 66 符号不截断)
static uint16_t gDurations[IR_MAX_EDGES];        // 收到的边沿时长序列(us)
static int      gFrameLen = 0;
static volatile bool gFrameReady = false;

static bool      gLearning  = false;
static IRAction  gLearnAct  = IR_COUNT;
static uint32_t  gLearnStart = 0;

static bool     gHasCode[IR_COUNT]   = {false};
static uint16_t gCodes[IR_COUNT][IR_MAX_EDGES];
static int      gCodeLen[IR_COUNT]   = {0};
static uint32_t gLastTrigger[IR_COUNT] = {0};
static IRAction  gLastMatchedAction = IR_COUNT;  // 最近一次成功匹配的动作(供 NEC 重复帧复用)
static uint32_t gLastMatchedMs = 0;             // 最近一次成功匹配的时刻(供 NEC 重复帧窗口判定)

// ★网页后台"控制按钮"(2026-10-16 新增): 待主循环消费的动作。
//   绝不在 WebSocket(async_tcp)任务里直接跑 gActionCb(IR_POWER→深睡/IR_SCREEN→重建显示/
//   改写 gState 会与主循环 show() 竞争), 只把动作号【投递】过来, 由 ir_poll() 在主循环这条线上执行,
//   与遥控命中完全等价。
static volatile IRAction gWebAction = IR_COUNT;   // IR_COUNT = 无待执行动作

// ---- IR_TOGGLE(播放/停止)的"单击待定"状态(2026-09-21 加, 09-22 改为"多帧确认") ----
// 为区分"单击播放/停止"与"长按播放键出电台列表": 命中完整 toggle 码后先挂起不派发,
// 观察 IR_TOGGLE_HOLD_MS 内是否累计出现 IR_TOGGLE_HOLD_REPEATS 个短重复帧(见 ir_poll 注释)。
// ★只认 1 个重复帧是不够的: NEC 重复帧间隔 ~110ms 而人单击就会按住 100~250ms, 单击必然带 1 个
//   重复帧 -> 会被误判成长按(表现为"列表里按确定却把列表收起了")。故要求连续 2 个。
static bool     gTogglePending   = false;   // 有 pending 的 toggle 单击等待派发
static uint32_t gTogglePendingMs = 0;       // 挂起时刻
static uint8_t  gToggleRepeatCnt = 0;       // 挂起期间已收到的重复帧个数(够 IR_TOGGLE_HOLD_REPEATS 判长按)

static Preferences gPrefs;

// 前向声明(本文件内定义顺序靠后, 但 ir_init/ir_poll 里提前调用)
static int  ir_learned_count();
static void ir_notify_learning();
static bool ir_arm_rx();   // (重新)启动一次 RMT 接收; 返回是否成功

// 大于此值的边沿视为"按键间的静默间隙", 学码 / 比对时从首尾裁掉(不计入码本身)
static const uint16_t GAP_US = 11000;

// NEC 重复帧: 按住遥控时首帧是完整码(已学), 之后每 ~110ms 发一个"短重复帧"(约 4 边沿:
// 9000/2250/560/560), 与所存完整码(66 边沿)长度差太大不会命中 matchSeq。据此可识别"人还按着":
//   · 音量键  -> 当作"按住连续调节"重发该动作(连续步进);
//   · 播放键  -> ★累计到 IR_TOGGLE_HOLD_REPEATS 个才当"长按" -> 派发 IRHoldCb(进入/退出电台列表),
//                同时取消待定的单击。只收到 1 个不算(那多半是单击时顺带发的, 见 ir_poll 注释);
//   · 业务声明可连续的动作(列表模式的 prev/next) -> 由 IRRepeatCb 返回 true 后重发;
//   · 其余(切换/关机类)保持单击一次即止(不重发)。
static const int      NEC_REPEAT_MAX_EDGES = 10;     // 短帧判定上限(完整码 66 边沿, 远超此值)
static const uint32_t NEC_REPEAT_WINDOW_MS = 500;    // 距上次命中多久内算"还在按着"(>遥控重复间隔即可)

// ---------------- 工具 ----------------
// 把原始边沿序列做"首尾去长间隙"规范化, 返回有效边数。遥控码本身内部不会超过 GAP_US。
static int canonicalize(const uint16_t* src, int n, uint16_t* dst) {
  int s = 0, e = n - 1;
  while (s <= e && src[s] > GAP_US) s++;
  while (e >= s && src[e] > GAP_US) e--;
  int m = 0;
  for (int i = s; i <= e && m < IR_MAX_EDGES; i++) dst[m++] = src[i];
  return m;
}

// 容差比对: 长度差 <=2, 且逐边沿时长差在 ±30%(至少 ±150us) 内即判同码。
static bool matchSeq(const uint16_t* a, int na, const uint16_t* b, int nb) {
  if (abs(na - nb) > 2) return false;
  int n = (na < nb) ? na : nb;
  for (int i = 0; i < n; i++) {
    int d = (int)a[i] - (int)b[i];
    if (d < 0) d = -d;
    uint16_t tol = (a[i] > b[i]) ? a[i] : b[i];
    tol = (uint16_t)(tol * 30 / 100);
    if (tol < 150) tol = 150;
    if ((uint16_t)d > tol) return false;
  }
  return true;
}

// ---------------- NVS 持久化 ----------------
static void loadAll() {
  for (int a = 0; a < IR_COUNT; a++) {
    String k = "ir" + String(a);
    uint8_t buf[IR_MAX_EDGES * 2 + 2];
    size_t len = gPrefs.getBytes(k.c_str(), buf, sizeof(buf));
    if (len >= 2) {
      int m = 0;
      for (size_t i = 0; i + 1 < len; i += 2) {
        uint16_t v = (uint16_t)buf[i] | ((uint16_t)buf[i + 1] << 8);
        if (v == 0xFFFF) break;                 // 0xFFFF = 终止符
        if (m < IR_MAX_EDGES) gCodes[a][m++] = v;
      }
      if (m > 0) { gCodeLen[a] = m; gHasCode[a] = true; }
    }
  }
}

static void storeCode(int a, const uint16_t* seq, int n) {
  uint8_t buf[IR_MAX_EDGES * 2 + 2];
  int bi = 0;
  for (int i = 0; i < n && bi + 1 < (int)sizeof(buf) - 1; i++) {
    uint16_t v = seq[i];
    buf[bi++] = v & 0xFF;
    buf[bi++] = (v >> 8) & 0xFF;
  }
  buf[bi++] = 0xFF; buf[bi++] = 0xFF;          // 终止符
  gPrefs.putBytes(("ir" + String(a)).c_str(), buf, bi);
  for (int i = 0; i < n; i++) gCodes[a][i] = seq[i];
  gCodeLen[a] = n;
  gHasCode[a] = true;
  // ★重复码告警(2026-09-22): 若本次学的码与另一个已学动作【几乎相同】, 那另一个动作就废了 ——
  //   ir_poll 的匹配是 a=0..IR_COUNT-1 顺序找, 命中即 break, 所以【序号小的先赢】。
  //   典型症状: "新学的那个键按了完全没反应"。直接在这里点出来, 省得靠猜。
  for (int b = 0; b < IR_COUNT; b++) {
    if (b == a || !gHasCode[b]) continue;
    if (matchSeq(seq, n, gCodes[b], gCodeLen[b])) {
      Serial.printf("[IR] !!! 告警: 动作 %s 与已学的 %s 是同一个键 -> 永远只会触发 %s (%s 失效)。请换一个遥控键重学 %s。\n",
                    ir_action_name((IRAction)a), ir_action_name((IRAction)b),
                    ir_action_name((IRAction)(b < a ? b : a)), ir_action_name((IRAction)(b < a ? a : b)),
                    ir_action_name((IRAction)(b < a ? a : b)));
    }
  }
}

// ---------------- RMT 接收 ----------------
// RMT 中断回调: 只把符号时长拷出 + 置帧就绪标志。不在这里重武装接收(不调用 rmt_receive),
// 重武装放到主循环 ir_poll() 里做 —— 这是 ESP-IDF 官方推荐写法, 避免 ISR 上下文里调用
// 非 IRAM 安全的 rmt_receive 导致的隐患, 且逻辑更清晰。
static bool IRAM_ATTR rx_done(rmt_channel_handle_t ch,
                              const rmt_rx_done_event_data_t* ed,
                              void* user_data) {
  int n = 0;
  int nsym = ed->num_symbols;
  for (int i = 0; i < nsym && n + 1 < IR_MAX_EDGES; i++) {
    gDurations[n++] = (uint16_t)ed->received_symbols[i].duration0;
    gDurations[n++] = (uint16_t)ed->received_symbols[i].duration1;
  }
  gFrameLen = n;
  gFrameReady = true;
  return false;
}

bool ir_is_ready() { return gRxChan != nullptr; }

void ir_init() {
  gPrefs.begin("irlearn", false);
  loadAll();

  // ★ 必须整体清零再赋值! 否则 intr_priority 等未赋值的字段是栈上的随机值,
  //    rmt_new_rx_channel 不校验它(通道建出来 gRxChan!=nullptr, ir.ready 显示"正常"),
  //    但随后 rmt_enable 用这个随机优先级去 esp_intr_alloc -> 失败且被忽略,
  //    => 通道建了却从没真正使能, RMT 收不到任何一帧(表现: 进学习模式按遥控毫无反应)。
  rmt_rx_channel_config_t cfg = {};
  cfg.gpio_num = (gpio_num_t)IR_RX_PIN;
  cfg.clk_src = RMT_CLK_SRC_DEFAULT;
  cfg.resolution_hz = 1000000;                // 1 MHz -> 1 tick = 1 us
  cfg.mem_block_symbols = 128;                // 足够容纳 NEC(66符号)等长帧, 避免截断
  cfg.intr_priority = 0;                      // 0 = 驱动自动分配低优先级(1/2/3), 必须显式置 0!
  cfg.flags.invert_in = false;
  cfg.flags.with_dma = false;
  cfg.flags.allow_pd = false;
  esp_err_t e = rmt_new_rx_channel(&cfg, &gRxChan);
  if (e != ESP_OK) {
    Serial.printf("[IR] RMT 建通道失败(%d), 红外功能不可用\n", e);
    return;
  }
  // VS1838B 多为开漏+内部上拉, 这里再给接收脚加一个 ESP32 内部上拉, 双保险:
  // 个别无内部上拉的裸模块浮空时会收不到, 加上拉即稳定。
  gpio_pullup_en((gpio_num_t)IR_RX_PIN);

  rmt_rx_event_callbacks_t cbs = {};
  cbs.on_recv_done = rx_done;
  e = rmt_rx_register_event_callbacks(gRxChan, &cbs, NULL);
  if (e != ESP_OK) {
    Serial.printf("[IR] RMT 注册回调失败(%d)\n", e);
    return;
  }
  e = rmt_enable(gRxChan);
  if (e != ESP_OK) {
    Serial.printf("[IR] RMT 使能失败(%d), 红外功能不可用\n", e);
    return;
  }
  if (!ir_arm_rx()) {
    Serial.println("[IR] RMT 启动接收失败, 红外功能不可用");
    return;
  }
  Serial.printf("[IR] 红外接收已启动 (GPIO%d, 已学习 %d/%d 个动作)\n",
                IR_RX_PIN, ir_learned_count(), IR_COUNT);
}

// (重新)启动一次 RMT 接收。返回是否成功。被 ir_init 和 ir_poll 调用。
static bool ir_arm_rx() {
  if (!gRxChan) return false;
  rmt_receive_config_t rc = {};               // 同样必须清零, 否则 rc.flags 随机位可能改掉接收行为
  rc.signal_range_min_ns = 125;
  rc.signal_range_max_ns = 20000000;         // 20ms: 容得下 NEC 9ms 引导码 + 各类长间隙
  esp_err_t e = rmt_receive(gRxChan, gSymbols, sizeof(gSymbols), &rc);
  if (e != ESP_OK) Serial.printf("[IR] rmt_receive 失败(%d)\n", e);
  return e == ESP_OK;
}

// ---------------- 学习 / 主循环处理 ----------------
bool ir_begin_learn(IRAction a) {
  if (a < 0 || a >= IR_COUNT) return false;
  // ★★2026-10-07 用户要求: 进入学习时【立即清除该动作原有的码】。
  //   语义 = "点一下就是重学": 先把旧的删掉, 于是
  //     · 在学习窗口内按了新键 -> 存新码(替换成功);
  //     · 什么都没按(超时)   -> 保持【已清除】状态, 不会退回旧码。
  //   这样"想忘掉某个功能"不必先点一次"清除"再去学, 一步到位。
  //   ★为什么必须在这里清而不是"存新码时覆盖": 旧码的清除要【立刻生效】(屏上状态与
  //   /api/state 马上变"—"), 否则用户会以为"清除"没反应; 而且若不清, 学习超时时旧码
  //   仍在, 就变成了"取消学习", 与他要的"没输入就清除"相反。
  //   ⚠ 代价: 学习中途放弃(比如误点)会丢掉旧码。这是"点一下=重学"这个语义的必然结果,
  //   由用户需求决定; 串口/后台在学习提示里已写明"按新键替换, 不按则清除"。
  ir_clear(a);
  gLearning = true;
  gLearnAct = a;
  gLearnStart = millis();
  gTogglePending   = false;   // ★丢弃待定的 toggle 单击: 学习期间不该有任何动作被触发
  gToggleRepeatCnt = 0;
  ir_notify_learning();
  Serial.printf("[IR] 开始重学 %s (原有码已清除; 按新键替换, %.0fs 内不按则保持清除)\n",
                ir_action_name(a), (float)IR_LEARN_MS / 1000.0f);
  return true;
}
void ir_cancel_learn() { gLearning = false; ir_notify_learning(); }

bool ir_is_learning()          { return gLearning; }
IRAction ir_learning_action()  { return gLearnAct; }
const char* ir_action_name(IRAction a) { return (a >= 0 && a < IR_COUNT) ? kActionNames[a] : "?"; }
bool ir_has_code(IRAction a)   { return (a >= 0 && a < IR_COUNT) ? gHasCode[a] : false; }
IRAction ir_name_to_action(const String& s) {
  for (int a = 0; a < IR_COUNT; a++) if (s == kActionNames[a]) return (IRAction)a;
  return IR_COUNT;
}

// ★网页后台"控制按钮": 复刻遥控一次命中 —— 但绝不在 WebSocket(async_tcp)任务里
//   直接跑动作派发(会与主循环 show()/screenStep/深睡 竞争), 而是【投递】到主循环,
//   由 ir_poll() 在唯一那条线上执行 gActionCb, 与遥控完全等价。
void ir_web_trigger(const String& name) {
  IRAction a = ir_name_to_action(name);
  if (a >= IR_COUNT) { Serial.printf("[IR] 网页 act 未知动作: %s\n", name.c_str()); return; }
  gWebAction = a;   // 主循环 ir_poll() 里消费(与遥控命中同一执行线)
}
const char* ir_last_action_name() {
  return (gLastMatchedAction < IR_COUNT) ? kActionNames[gLastMatchedAction] : "";
}

void ir_clear(IRAction a) {
  if (a < 0 || a >= IR_COUNT) return;
  gHasCode[a] = false; gCodeLen[a] = 0;
  gPrefs.remove(("ir" + String(a)).c_str());
}
void ir_clear_all() { for (int a = 0; a < IR_COUNT; a++) ir_clear((IRAction)a); }

// 触发某动作(统一走冷却 + 记录"最近命中", 供 NEC 重复帧复用)
// force=true 时跳过"动作冷却"直接触发。用途: 业务已通过 IRRepeatCb 明确声明"这个动作此刻要连续"
//   (电台列表模式按住 prev/next 连续上下) —— 此时动作冷却(prev/next 是 350ms)反而会吃掉重复帧,
//   让连续变慢。音量走的是自己的短冷却(IR_VOL_REPEAT_MS), 不需要 force。
static void ir_trigger(IRAction a, uint32_t now, bool force = false) {
  if (!force && now - gLastTrigger[a] <= ir_cooldown_for(a)) return;   // 冷却中: 防按住反复触发
  gLastTrigger[a] = now;
  gLastMatchedAction = a;
  gLastMatchedMs = now;
  Serial.printf("[IR] 匹配动作 %s -> 触发\n", ir_action_name(a));
  if (gActionCb) gActionCb(a);
}

static int ir_learned_count() {
  int c = 0; for (int a = 0; a < IR_COUNT; a++) if (gHasCode[a]) c++;
  return c;
}

void ir_poll() {
  // ★网页后台"控制按钮"投递的动作: 在主循环这一条线上消费, 与遥控命中等价
  //   (不在 WebSocket 任务里直接跑, 避免与 show()/screenStep/深睡 竞争, 见 gWebAction 注释)。
  if (gWebAction < IR_COUNT) {
    IRAction a = gWebAction; gWebAction = IR_COUNT;
    Serial.printf("[IR] 网页 act 触发动作 %s -> 执行\n", ir_action_name(a));
    if (gActionCb) gActionCb(a);
  }
  const uint32_t nowMs = millis();
  // 学习模式超时取消
  if (gLearning && nowMs - gLearnStart > IR_LEARN_MS) {
    gLearning = false;
    Serial.println("[IR] 学习超时(未收到码), 已取消");
    ir_notify_learning();
  }

  // ★IR_TOGGLE(播放/停止) 单击待定窗口到期: 这段时间内没等到"重复帧" -> 判为单击, 派发。
  //   必须放在最前面、且在 `if (!gFrameReady) return;` 之前 —— 它每圈都要检查,
  //   不能因为"这圈没收到红外帧"就跳过, 否则单击永远不会派发(按键像失灵)。
  if (gTogglePending && nowMs - gTogglePendingMs >= IR_TOGGLE_HOLD_MS) {
    gTogglePending = false;
    if (gToggleRepeatCnt >= IR_TOGGLE_HOLD_REPEATS) {
      // 理论上不会走到这里(凑够帧数时已当场判长按), 兜底防"既没单击也没长按"
      Serial.printf("[IR] 播放/停止键: 重复帧 %d 个 -> 补判长按\n", (int)gToggleRepeatCnt);
      gToggleRepeatCnt = 0;
      if (gHoldCb) gHoldCb(IR_TOGGLE);
    } else {
      Serial.printf("[IR] 播放/停止键: 重复帧仅 %d 个(<%d) -> 判为单击\n",
                    (int)gToggleRepeatCnt, IR_TOGGLE_HOLD_REPEATS);
      gToggleRepeatCnt = 0;
      ir_trigger(IR_TOGGLE, nowMs);
    }
  }

  if (!gFrameReady) return;   // 没收到帧: 通道仍在 ir_init 里启动的那次接收中, 无需处理
  gFrameReady = false;

  uint16_t seq[IR_MAX_EDGES];
  int n = canonicalize(gDurations, gFrameLen, seq);
  uint32_t now = millis();

  // ★2026-10-08: "有遥控活动"通知 —— 必须在学习分支与动作匹配【之前】, 且与它们【无关】。
  //   三件常被误当"设备没反应"的事都归这里兜住:
  //     ① 用户按的是【没学过】的遥控键(永远不会匹配成功) -> 屏黑着不亮, 像死机;
  //     ② 这次命中正好落在该动作的冷却窗口内(ir_trigger 会直接丢弃) -> 同样不亮;
  //     ③ 正在学习模式(等用户按遥控器) -> 用户按了键却连屏都不亮, 以为学习没生效。
  //   门槛取 IR_ACTIVITY_MIN_EDGES(4): 与下面学习模式判定"点到真实遥控码"的 `n >= 4` 同一口径,
  //   低于它的是空闲噪声/单根毛刺, 不该点亮。误亮代价仅是背光点亮(无操作 20s 后自动灭)。
  if (n >= IR_ACTIVITY_MIN_EDGES && gActivityCb) gActivityCb();

  if (gLearning) {
    // 学习模式: 打印每一帧(含空闲噪声), 让用户直接看到"RX 是否活着"
    Serial.printf("[IR] 收到 %d 边沿(us):", n);
    for (int i = 0; i < min(n, 14); i++) Serial.printf(" %d", seq[i]);
    Serial.println();
    if (n >= 4) {                       // 只在点到真实遥控码(>=4 边沿)时才定稿, 空闲噪声不打断学习
      gLearning = false;
      storeCode(gLearnAct, seq, n);
      Serial.printf("[IR] 已学习动作 %s (%d 边沿)\n", ir_action_name(gLearnAct), n);
    } else {
      Serial.println("[IR] 码过短被忽略, 继续等待(请再按遥控器)");
    }
    ir_notify_learning();
    ir_arm_rx();                        // 重新武装, 等待下一帧
    return;
  }

  // 普通模式: 仅处理有内容的帧(空闲噪声 n<2 直接丢弃, 避免刷屏)
  if (n >= 2) {
    bool matched = false;
    for (int a = 0; a < IR_COUNT; a++) {
      if (gHasCode[a] && matchSeq(seq, n, gCodes[a], gCodeLen[a])) {
        matched = true;
        if (a == IR_TOGGLE) {
          // ★播放/停止键【不立即触发】: 先挂起, 观察 IR_TOGGLE_HOLD_MS 内是否出现"重复帧"。
          //   窗口内没有 = 单击(播放/停止); 窗口内有 = 长按(进入/退出电台列表)。
          //   连按两下时前一次已在挂起中 -> 先把前一次当单击落地, 再挂起本次(两次点击都不丢)。
          if (gTogglePending) { gTogglePending = false; gToggleRepeatCnt = 0; ir_trigger(IR_TOGGLE, now); }
          gTogglePending   = true;
          gTogglePendingMs = now;
          gToggleRepeatCnt = 0;   // 新的一次按压: 重复帧计数从 0 开始
          // 记下"最近命中是 toggle", 供下面的短重复帧分支识别"人还按着播放键"
          gLastMatchedAction = IR_TOGGLE;
          gLastMatchedMs     = now;
        } else {
          // 其它动作照旧立即触发; 但若还有 pending 的 toggle, 先把它作为单击落地
          // (用户刚按了播放键又马上按别的键 -> 那一下播放/停止不该被吞掉)
          if (gTogglePending) { gTogglePending = false; gToggleRepeatCnt = 0; ir_trigger(IR_TOGGLE, now); }
          ir_trigger((IRAction)a, now);   // 命中完整码 -> 触发(含按动作冷却)
        }
        break;   // 一次只触发一个最优先命中的动作
      }
    }
    // ---- 短重复帧 = "人还按着不放"(完整码 66 边沿, 远超 NEC_REPEAT_MAX_EDGES) ----
    if (!matched && n >= 3 && n <= NEC_REPEAT_MAX_EDGES
        && (now - gLastMatchedMs <= NEC_REPEAT_WINDOW_MS)) {
      if (gLastMatchedAction == IR_TOGGLE) {
        // ★长按判定必须累计 IR_TOGGLE_HOLD_REPEATS 个重复帧(见 config.h 该宏的说明)。
        //   只收到 1 个 => 多半是"单击时按住的那一下"顺带发的, 不算长按 —— 保持 pending,
        //   继续等下一个重复帧(凑够) 或等窗口到期(判单击)。
        gToggleRepeatCnt++;
        if (gToggleRepeatCnt < IR_TOGGLE_HOLD_REPEATS) {
          gLastMatchedMs = now;   // 刷新"还在按着"的窗口, 让下一个重复帧仍能被识别
          Serial.printf("[IR] 播放/停止键: 重复帧 %d/%d (未凑够长按)\n",
                        (int)gToggleRepeatCnt, IR_TOGGLE_HOLD_REPEATS);
        } else {
          // ★凑够 -> 判长按: 派发 hold 事件(电台列表 进入/退出), 并取消待定的单击
          gTogglePending     = false;
          gToggleRepeatCnt   = 0;
          // ★置为无效: 只认这一次。否则按住期间每个重复帧都会再触发一次 -> 列表反复进出
          gLastMatchedAction = IR_COUNT;
          gLastMatchedMs     = now;
          Serial.println("[IR] 播放/停止键: 检测到重复帧 -> 判为长按");
          if (gHoldCb) gHoldCb(IR_TOGGLE);
        }
      } else if (gLastMatchedAction == IR_VOLUP || gLastMatchedAction == IR_VOLDOWN) {
        // 音量: 内置"按住连续步进", 走自己的短冷却(IR_VOL_REPEAT_MS)
        ir_trigger(gLastMatchedAction, now);
      } else if (gRepeatCb && gRepeatCb(gLastMatchedAction)) {
        // 业务声明"这个动作此刻要连续"(电台列表模式按住 prev/next 连续上下)
        // -> force=true 跳过动作冷却(prev/next 是 350ms, 会吃掉 ~110ms 的重复帧使连续变慢)
        ir_trigger(gLastMatchedAction, now, true);
      }
    }
  }
  ir_arm_rx();                          // 重新武装, 等待下一帧
}

// 深睡唤醒后"指定遥控键开机"确认: 仅当收到已学的 power 动作码才返回 true(阻塞等待最多 timeout_ms)。
// 硬件层 EXT1 唤醒无法区分红外码(只要 IR 脚被拉低就唤醒), 故由这里软件确认:
//   收到非 power 码 -> 返回 false -> 调用方回深睡(表现="该遥控键不开机");
//   没学 power 码   -> 返回 true (退化为"任意遥控可唤醒", 防止 brick);
//   超时未收到      -> 返回 false。
bool ir_confirm_power(uint32_t timeout_ms) {
  if (!gRxChan) return true;              // RMT 未就绪: 红外本就不可用, 不做限制(防 brick)
  if (!gHasCode[IR_POWER]) return true;   // 没学 power 码: 不做限制, 允许唤醒(防 brick)
  // 注意: 不在此重复调用 ir_arm_rx() —— ir_init() 末尾已武装接收, 此时再 rmt_receive 会返回
  // ESP_ERR_INVALID_STATE(接收进行中)并打印失败日志。这里直接复用那次已武装的接收即可。
  gFrameReady = false;
  uint32_t t0 = millis();
  while (millis() - t0 < timeout_ms) {
    if (gFrameReady) {
      gFrameReady = false;
      uint16_t seq[IR_MAX_EDGES];
      int n = canonicalize(gDurations, gFrameLen, seq);
      if (n >= 4 && matchSeq(seq, n, gCodes[IR_POWER], gCodeLen[IR_POWER])) {
        // 记下命中时刻: 抑制接下来 IR_TOGGLE_COOLDOWN_MS(~1.5s)内的重复帧再次触发 IR_POWER 关机,
        // 避免"按开机键(长按)立刻又被同一键关掉"。
        gLastTrigger[IR_POWER] = millis();
        ir_arm_rx();
        return true;                       // 命中 power 码: 允许开机
      }
      ir_arm_rx();                         // 非 power 码: 重新武装, 继续等(可能在连按/重复帧)
    }
    delay(5);
  }
  return false;                            // 超时未收到 power 码: 不开机
}

// ---------------- 回调 / 通知 ----------------
void ir_set_action_cb(IRActionCb cb) { gActionCb = cb; }
void ir_set_hold_cb(IRHoldCb cb)     { gHoldCb   = cb; }
void ir_set_repeat_cb(IRRepeatCb cb) { gRepeatCb = cb; }
void ir_set_activity_cb(IRActivityCb cb) { gActivityCb = cb; }
void ir_set_notify_cb(IRNotifyCb cb) { gNotifyCb = cb; }
void ir_notify(const String& json)  { if (gNotifyCb) gNotifyCb(json); }

// 广播"学习状态"变化(进入/退出学习、完成学习、超时)
static void ir_notify_learning() {
  String s = "{\"type\":\"ir\",\"learning\":" + String(gLearning ? "true" : "false");
  s += ",\"learningAction\":\"" + String(gLearning ? ir_action_name(gLearnAct) : "") + "\"";
  s += "}";
  ir_notify(s);
}

#else  // !IR_ENABLED —— 完全关闭时全部变空实现, 不占用 RMT / 代码体积
void ir_init() {}
bool ir_is_ready() { return false; }
void ir_poll() {}
bool ir_begin_learn(IRAction) { return false; }
void ir_cancel_learn() {}
bool ir_is_learning() { return false; }
IRAction ir_learning_action() { return IR_COUNT; }
const char* ir_action_name(IRAction) { return "?"; }
bool ir_has_code(IRAction) { return false; }
void ir_clear(IRAction) {}
void ir_clear_all() {}
IRAction ir_name_to_action(const String&) { return IR_COUNT; }
const char* ir_last_action_name() { return ""; }
void ir_web_trigger(const String&) {}
void ir_set_action_cb(IRActionCb) {}
void ir_set_hold_cb(IRHoldCb) {}
void ir_set_repeat_cb(IRRepeatCb) {}
void ir_set_activity_cb(IRActivityCb) {}
void ir_set_notify_cb(IRNotifyCb) {}
void ir_notify(const String&) {}
bool ir_confirm_power(uint32_t) { return true; }   // 红外关闭: 不做限制, 允许唤醒
#endif
