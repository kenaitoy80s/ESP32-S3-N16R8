#include "input_btn.h"
#include "../config.h"

void InputBtn::initBtn(Btn& b, int pin, uint32_t longMs, uint32_t repeatDelayMs, bool noDbl) {
  b.pin = pin;
  b.cur = false;
  b.rawLast = false;
  b.rawChgMs = millis();
  b.evActivity = false;
  b.evDown = false;
  b.downMs = 0;
  b.longMs = longMs;
  b.repeatDelayMs = repeatDelayMs;
  b.lpFired = false;
  b.repActive = false;
  b.repMs = 0;
  b.singleArmed = false;
  b.singleMs = 0;
  b.dblArmed = false;
  b.noDbl = noDbl;
  b.evSingle = b.evDouble = b.evLong = b.evRepeat = false;
  pinMode(pin, INPUT_PULLUP);
}

void InputBtn::begin() {
  // 上一台键(左): 播放界面=单击切台/双击音量-1/长按连续减; 列表界面=上移(含长按连续)
  initBtn(btns[0], BTN_LEFT,   0,                 BTN_REPEAT_DELAY_MS);
  // 中键: 单击播放/停止; 长按 BTN_LIST_HOLD_MS = 进入/退出电台列表(不做连续调节)
  //   ★noDbl=true: 中键没有双击语义, 单击【松开即派发】(不再空等 300ms 双击窗口)。
  //     否则列表里按"确定"要等 300ms, 用户等不到就继续按住 -> 触发 800ms 长按 -> 变成"收起列表",
  //     表现为"确定键按不出来"(见 input_btn.h 顶部 noDbl 段)。
  //   ★原"长按重置配网进 AP"已移除: 该功能只保留 Web 入口(POST /api/reset 与 WS reset),
  //     否则与"长按出电台列表"抢同一个手势。
  initBtn(btns[1], BTN_CENTER, BTN_LIST_HOLD_MS, 0, /*noDbl=*/true);
  // 下一台键(右): 播放界面=单击切台/双击音量+1/长按连续加; 列表界面=下移(含长按连续)
  initBtn(btns[2], BTN_RIGHT,  0,                 BTN_REPEAT_DELAY_MS);
}

void InputBtn::update() {
  const uint32_t now = millis();
  for (int i = 0; i < NBTN; i++) {
    Btn& b = btns[i];
    b.evActivity = false;                           // 每周期重新采样

    // ---- 第一步: 去抖。原始电平必须稳定 DEBOUNCE_MS 以上, 才认作一次真实的"按下/松开"。----
    // 关键: 抖动期间只重新计时, 绝不推进 cur, 因此 downMs 不会被抖动重置 ——
    //       这是"按住音量能连续调节"的前提(旧版没有这层, 抖动一次长按计时就归零)。
    const bool raw = (digitalRead(b.pin) == LOW);   // 取反: 按下=true
    if (raw != b.rawLast) {                         // 原始电平刚变化 -> 重新计去抖时间
      b.rawLast  = raw;
      b.rawChgMs = now;
    } else if (raw != b.cur && (now - b.rawChgMs) >= DEBOUNCE_MS) {
      // 稳定超过去抖窗 -> 这是一次真实的状态变化
      if (raw) {                       // ---- 刚按下 ----
        b.downMs     = now;
        b.lpFired    = false;
        b.repActive  = false;
        b.repMs      = 0;
        b.evActivity = true;           // 有动作 -> 唤醒背光
        b.evDown     = true;           // 按下沿事件(列表模式用来零延迟移动光标)
        if (b.singleArmed && (now - b.singleMs) <= BTN_DOUBLE_CLICK_MS) {
          b.dblArmed = true;           // 双击窗口内的第二击 -> 双击候选
          b.singleArmed = false;       // 撤销待定的单击
        }
      } else {                         // ---- 刚松开 ----
        b.evDown = false;              // 按下沿事件是"瞬时"事件: 到松开还没人消费就作废
                                       // (否则在普通界面按下左键、之后再进列表, 会在列表里凭空多移一格)
        const uint32_t held = now - b.downMs;
        if (b.dblArmed) {
          // 第二击按得不长(未触发长按/连续)才算双击; 否则视为一次长按操作
          if (!b.lpFired && !b.repActive && held >= DEBOUNCE_MS) b.evDouble = true;
          b.dblArmed = false;
        } else if (!b.lpFired && !b.repActive && held >= DEBOUNCE_MS) {
          if (b.noDbl) {
            // ★noDbl 键(中键): 没有双击语义 -> 松开【立即】派发单击, 不空等双击窗口。
            //   这也是"列表里按中键=确定"能跟手的前提(否则要等满 300ms, 用户等不到会继续按住
            //   直到 800ms 长按阈值 -> 变成"收起列表", 确定永远按不出来)。
            b.evSingle = true;
          } else {
            b.singleArmed = true;        // 待定: 等窗口内是否还有第二击
            b.singleMs = now;
          }
        }
        b.repActive = false;
        b.repMs = 0;
      }
      b.cur = raw;
    }

    // ---- 第二步: 持续按下判定(长按一次性 / 连续调节), 基于已去抖的 cur ----
    if (b.cur) {
      const uint32_t held = now - b.downMs;
      // (1) 一次性长按(中键 = 进入/退出电台列表)
      if (b.longMs && !b.lpFired && held >= b.longMs) {
        b.lpFired = true;
        b.evLong = true;
        b.singleArmed = false;
      }
      // (2) 连续调节(音量): 按住 BTN_REPEAT_DELAY_MS 先立即触发一次, 之后每 BTN_REPEAT_MS 一次
      if (b.repeatDelayMs) {
        if (!b.repActive && held >= b.repeatDelayMs) {
          b.repActive = true;
          b.repMs     = now;
          b.evRepeat  = true;
          b.singleArmed = false;       // 已转为连续调节, 取消松开时的单击
        } else if (b.repActive && (now - b.repMs) >= BTN_REPEAT_MS) {
          b.repMs    = now;
          b.evRepeat = true;
        }
      }
    }

    // 单击待定超时 -> 派发单击(之后若再来一击, 属于下一轮的新单击)
    if (b.singleArmed && (now - b.singleMs) > BTN_DOUBLE_CLICK_MS) {
      b.singleArmed = false;
      b.evSingle = true;
    }
  }
}

bool InputBtn::downPressed(int pin) {
  for (int i = 0; i < NBTN; i++) {
    if (btns[i].pin == pin && btns[i].evDown) { btns[i].evDown = false; return true; }
  }
  return false;
}

bool InputBtn::singlePressed(int pin) {
  for (int i = 0; i < NBTN; i++) {
    if (btns[i].pin == pin && btns[i].evSingle) { btns[i].evSingle = false; return true; }
  }
  return false;
}

bool InputBtn::doublePressed(int pin) {
  for (int i = 0; i < NBTN; i++) {
    if (btns[i].pin == pin && btns[i].evDouble) { btns[i].evDouble = false; return true; }
  }
  return false;
}

bool InputBtn::longPressed(int pin) {
  for (int i = 0; i < NBTN; i++) {
    if (btns[i].pin == pin && btns[i].evLong) { btns[i].evLong = false; return true; }
  }
  return false;
}

bool InputBtn::repeatPressed(int pin) {
  for (int i = 0; i < NBTN; i++) {
    if (btns[i].pin == pin && btns[i].evRepeat) { btns[i].evRepeat = false; return true; }
  }
  return false;
}

// 窥探: 本周期是否有键刚按下(不消费, 供"点亮背光"用)
bool InputBtn::anyActivity() {
  for (int i = 0; i < NBTN; i++) {
    if (btns[i].evActivity) return true;
  }
  return false;
}

// 清空单个键的全部事件标志(不动去抖/长按计时等状态机字段, 只清"待消费的事件")
void InputBtn::clearPin(Btn& b) {
  b.evActivity = b.evDown = false;
  b.evSingle = b.evDouble = b.evLong = b.evRepeat = false;
}

// 排空所有键的事件。★电台列表模式每圈收尾调用(见 input_btn.h 顶部说明):
//   列表里只用 downPressed/repeatPressed, 若不排空, 期间攒下的 single/double 会在
//   退出列表后的第一圈被一次性执行 —— 表现为"一退出就莫名切台/音量跳一格"。
//   注意: 已消费的事件本就为 false, 再清一次无副作用, 所以可以"先消费想要的, 再整体排空"。
void InputBtn::clearEvents() {
  for (int i = 0; i < NBTN; i++) clearPin(btns[i]);
}
