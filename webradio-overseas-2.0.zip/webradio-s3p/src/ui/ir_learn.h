#pragma once
#include <Arduino.h>

/*
 * 红外遥控学习模块(自包含, 不依赖外部红外库)
 * 用 ESP32 原生 RMT 外设接收 VS1838B 输出的已解调波形, 捕获"原始边沿时长序列",
 * 不解码具体协议 —— 因此能学任意遥控器(NEC/RC5/Sony/... 通吃)。
 * 学习: 进入学习模式后, 下一次收到的波形即存为该动作的码(NVS 持久化)。
 * 使用: 平时收到波形与已存各动作码做容差比对, 命中即触发对应动作。
 *
 * ---- 三类回调(2026-09-21 增补后) ----
 *   IRActionCb(动作)        : 单击/命中一次 —— 常规动作触发
 *   IRHoldCb(动作)          : 长按 —— 由"重复帧"判定(见下), 目前只对 IR_TOGGLE 派发
 *   IRRepeatCb(动作)        : 业务询问"这个动作是否允许用重复帧连续重发"(返回 true 则连续)
 *   IRActivityCb()          : ★2026-10-08 新增 —— "收到任何像样的红外帧"(不看码是否学会/是否命中)
 * 例: 电台列表模式下 prev/next 要能"按住连续上下", 就由 IRRepeatCb 返回 true 打开。
 *
 * ---- 为什么需要 IRActivityCb(而不是复用 IRActionCb 做亮屏) ----
 *   IRActionCb 只在【码匹配成功且未被冷却吞掉】时才回调。可"屏黑着时按遥控"这个场景里,
 *   用户按的很可能是没学过的键、或这次命中正好落在动作冷却窗口内 —— 那屏就永远不亮。
 *   而"按了遥控"这件事本身与"按的哪个键"无关: 意图就是"我要用设备"。故单独开一路回调,
 *   只要收到边沿数 >= IR_ACTIVITY_MIN_EDGES 的帧就通知一次(学习模式下也通知)。
 *   调用方(webradio-s3p.ino)在这里只做一件事: 点亮背光。
 */
enum IRAction {
  IR_PREV    = 0,
  IR_NEXT    = 1,
  IR_TOGGLE  = 2,
  IR_VOLUP   = 3,
  IR_VOLDOWN = 4,
  IR_POWER   = 5,   // 开关机: ★语义取决于此刻设备状态(2026-10-08 起)——
                    //   · 熄屏待机中(睡眠定时器到点, 见 gState.sleepStandby) -> 【开机】亮屏+恢复播放;
                    //   · 其它情况 -> 【关机】进深度休眠(停播+关无线+屏灭+功放关)。
                    //   硬件层不区分状态, 判断在 webradio-s3p.ino 的 IR_POWER 分支里做。
  IR_ROTATE      = 6,  // 屏幕旋转: 每按一次顺时针转 90° (0->90->180->270->0), 仅彩屏(ST7789/ILI9341)有效
  IR_SCREEN      = 7,  // 切换屏幕: ST7567 -> SSD1306 -> ST7789 -> ILI9341 -> ST7567 循环
  // ★新增(2026-10-07, 阶段② SD 卡): 音源切换。
  //   语义 = "网络电台 <-> 本地 SD 卡" 两个音源来回切(不是循环多个音源):
  //     · 当前在网络电台 -> 切到 SD 卡(挂载 + 扫描 + 打开文件列表, 光标落在正在播的那首)
  //     · 当前在 SD 卡   -> 退出 SD 音源, 回到进 SD 前的那台网络电台
  //   为什么不给 SD 单独再开一个"打开文件列表"动作: 面板上中键长按已被电台列表占用,
  //   红外若再占一个键, 用户要学 9 个键才能用全功能; 而"切音源"这个动作在
  //   两个音源下都有意义、且是最常用的切换, 一个键顶两个用途, 更划算。
  //   (想直接浏览而不切音源: 面板中键双击 / 串口 G / 后台 SD 页)
  IR_SD          = 8,  // 音源切换: 网络电台 <-> 本地 SD 卡
  // ★新增(2026-10-07, 定时关机): 单键循环切换定时关机档位。
  //   每按一次在 【关闭 → 1h → 2h → … → 12h → 关闭】 之间循环, 一颗键管全部档位。
  //   到点【真正关机】(停播 + 关无线 + 进深度休眠), 与面板/后台的"睡眠定时器"
  //   (到点只停播+熄屏, 设备仍通电) 是两套语义, 见 player_state.h 的 sleepToPowerOff。
  IR_TIMER   = 9,  // 定时关机: 单键循环 关闭/1h/…/12h
  IR_COUNT   = 10
};

typedef void (*IRActionCb)(IRAction a);     // 命中某动作时回调(主循环上下文调用)
typedef void (*IRHoldCb)(IRAction a);       // 长按(重复帧)回调(主循环上下文调用)
typedef bool (*IRRepeatCb)(IRAction a);     // 该动作是否允许"重复帧连续重发"(主循环上下文调用)
typedef void (*IRActivityCb)();             // "收到任何像样的红外帧"回调(不看码是否命中; 主循环上下文)
typedef void (*IRNotifyCb)(const String& json); // 状态变化通知(用于 WebSocket 广播)

void     ir_init();                          // setup() 里调用: 初始化 RMT + 从 NVS 载入已存码
bool     ir_is_ready();                       // RMT 接收是否初始化成功(诊断/状态显示用)
// 深睡唤醒后"指定键开机"确认: 仅当收到已学的 power 动作码才返回 true(阻塞等待最多 timeout_ms)。
// 硬件 EXT1 唤醒只看 IR 脚是否拉低(任何遥控码都会唤醒)无法区分具体键, 故由这里软件确认;
// 没学 power 码时返回 true(退化为"任意遥控可唤醒", 防 brick); 超时/非 power 码返回 false。
bool     ir_confirm_power(uint32_t timeout_ms);
void     ir_poll();                          // loop() 里调用: 处理收到的帧 / 比对 / 触发
bool     ir_begin_learn(IRAction a);         // 进入某动作的学习模式(下次收到即存)
void     ir_cancel_learn();
bool     ir_is_learning();
IRAction ir_learning_action();
const char* ir_action_name(IRAction a);
bool     ir_has_code(IRAction a);
void     ir_clear(IRAction a);
void     ir_clear_all();
IRAction ir_name_to_action(const String& s); // "prev"/"next"/... -> 枚举(用于 WebSocket)
// ★网页后台"控制按钮"专用通道(2026-10-16 新增):
//   复刻遥控一次命中动作的行为 —— 走 gActionCb(与遥控 .ino 注册的统一派发等价),
//   使网页按钮与遥控器完全等价。网页 ctrl.js 经 wsSend("act=xxx") 触发。
//   ★注意: 本函数只【投递】动作, 真正执行在 ir_poll()(主循环那条线), 见 ir_learn.cpp。
void     ir_web_trigger(const String& name); // "prev"/"screen"/... -> 触发对应 IR 动作
// 最近一次【真正命中并触发】的动作名(""=还没有过)。
// 诊断用途: "按了某个键设备没反应"时, 先看它到底被认成了哪个动作 —— 常见根因是
// 两个动作学成了同一个键(匹配时【序号小的先赢】, 靠后的那个就永远触发不了)。
const char* ir_last_action_name();
void     ir_set_action_cb(IRActionCb cb);    // 设动作触发回调(由 webradio-s3p.ino 注入 player 控制)
void     ir_set_hold_cb(IRHoldCb cb);        // 设"长按"回调(重复帧判定; 目前只派发 IR_TOGGLE)
void     ir_set_repeat_cb(IRRepeatCb cb);    // 设"是否允许重复帧连续"询问回调(列表模式下 prev/next 要连续)
// ★设"有遥控活动"回调: 只要收到边沿数 >= IR_ACTIVITY_MIN_EDGES 的帧就回调一次,
//   【不做码匹配】—— 用于"屏熄灭后按任意遥控键都亮屏"(学没学过的键都算)。
void     ir_set_activity_cb(IRActivityCb cb);
void     ir_set_notify_cb(IRNotifyCb cb);    // 设状态广播回调(由 web_server 注入 WS 广播)
void     ir_notify(const String& json);      // 主动广播一条状态 JSON
