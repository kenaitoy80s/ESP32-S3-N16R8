#pragma once
#include <Arduino.h>

/*
 * 实体按键扫描 (INPUT_PULLUP, 低电平=按下)。S3 版: 3 键——
 *   上一台(LEFT) / 中(CENTER) / 下一台(RIGHT)
 * 音量已并入切台键(双击 ±1 / 长按连续), 故不再有独立音量键。
 *
 * 五类事件(均一次性消费, 返回 true 后即被清除):
 *   downPressed()    按下沿 —— 去抖确认按下的【当圈】即派发(零延迟, 不等双击窗口)
 *                    ★电台列表模式专供: 上下选择要"按下去马上动", 等 BTN_DOUBLE_CLICK_MS
 *                      的单击会明显顿一下。列表模式另有长按连续(repeatPressed)接管后续。
 *   singlePressed()  单击 —— 松开后等双击窗口(BTN_DOUBLE_CLICK_MS)内无第二击才派发
 *                    ★例外(noDbl 键, 见下): 松开【立即】派发, 不空等窗口
 *   doublePressed()  双击 —— 双击窗口内的第二击, 在其松开时派发(音量 ±1 用)
 *   longPressed()    长按 —— 按住达该键阈值(中键 = BTN_LIST_HOLD_MS)派发一次
 *   repeatPressed()  连续 —— 按住达 BTN_REPEAT_DELAY_MS 起, 每 BTN_REPEAT_MS 一次(音量/列表上下用)
 *   anyActivity()    窥探 —— 本周期有任意键"刚按下"(不消费), 用于点亮背光
 *   clearEvents()    排空 —— 把所有键的所有待消费事件清掉(电台列表模式每圈收尾调用)
 *
 * 互斥保证:
 *   - 按键一旦进入"连续调节"态, 松开时不再补发单击(否则会多调一格);
 *   - 双击的第二击若按得过久(已触发长按/连续), 则不再派发双击。
 *
 * ★clearEvents() 的必要性: 事件是"置位后等被消费"的语义, 没人读就一直留着。
 *   列表模式下左/右键走的是 downPressed + repeatPressed, 若不同时把 single/double 排空,
 *   退出列表后的第一圈就会把列表期间攒下的"单击/双击"一次性执行掉 —— 表现为
 *   "一退出列表就莫名其妙切了台 / 音量跳了一格"。
 *
 * ★noDbl 键(2026-09-22 加, 中键使用): "这个键没有双击语义" -> 松开即派发单击, 不空等
 *   BTN_DOUBLE_CLICK_MS。原本中键单击(播放/停止, 列表里则是【确定】)也要等满 300ms 双击窗口,
 *   实测后果很坏: 按下去 300ms 内毫无反应 -> 用户以为没生效 -> 继续按住 -> 一旦按满中键长按
 *   阈值(BTN_LIST_HOLD_MS=800ms), longPressed 抢先触发"收起列表", 于是"确定"永远按不出来。
 *   中键在任何界面都只用到 单击 + 长按(无双击), 所以这 300ms 等待纯属白等 —— 去掉后
 *   短按立刻生效(松开即确定), 长按仍归 longPressed 管, 两者靠"松手时刻 vs 800ms"天然分开。
 *
 * ★去抖(2026-09-18 加): 电平必须【稳定 DEBOUNCE_MS 以上】才被认作一次状态变化。
 *   早先版本对任意电平抖动都当成"按下/松开"边沿处理 -> 机械抖动会不断重置 downMs,
 *   使长按永远到不了 BTN_REPEAT_DELAY_MS -> 表现成"按住音量只跳一格"(连续调节失效)。
 * 需在 loop() 中频繁调用 update()。
 */
class InputBtn {
public:
  void begin();
  void update();
  bool downPressed(int pin);     // 按下沿(零延迟, 不等双击窗口)
  bool singlePressed(int pin);   // 单击
  bool doublePressed(int pin);   // 双击
  bool longPressed(int pin);     // 长按(一次性)
  bool repeatPressed(int pin);   // 长按期间周期性触发(连续调节)
  bool anyActivity();            // 本周期是否有键刚按下(窥探, 不消费)
  void clearEvents();            // 排空所有键的全部待消费事件(列表模式每圈收尾用)

private:
  struct Btn {
    int      pin;
    bool     cur;            // 去抖后的稳定电平(true=按下) —— 所有事件判定的唯一依据
    bool     rawLast;        // 上次原始采样(用于去抖)
    uint32_t rawChgMs;       // 原始采样最近一次变化的时刻(去抖计时)
    bool     evActivity;     // 本周期刚按下(背光唤醒用)
    bool     evDown;         // 本周期刚按下(按下沿事件, 可被消费)
    uint32_t downMs;         // 按下时刻
    uint32_t longMs;         // 本键长按阈值(0=不支持一次性长按)
    uint32_t repeatDelayMs;  // 本键连续调节起始阈值(0=不支持连续)
    bool     lpFired;        // 长按是否已触发
    bool     repActive;      // 是否已进入连续调节
    uint32_t repMs;          // 连续调节节拍起点
    bool     singleArmed;    // 单击待定(等双击窗口内是否还有第二击)
    uint32_t singleMs;       // 单击待定起点
    bool     dblArmed;       // 第二次按下已成双击候选(等其松开确认)
    bool     noDbl;          // ★true=该键无双击语义 -> 松开即派发单击(不等 BTN_DOUBLE_CLICK_MS)
    bool     evSingle, evDouble, evLong, evRepeat;
  };
  static const int NBTN = 3;   // S3: 上一台 / 中 / 下一台
  Btn btns[NBTN];
  void initBtn(Btn& b, int pin, uint32_t longMs, uint32_t repeatDelayMs, bool noDbl = false);
  void clearPin(Btn& b);       // 清空单个键的全部事件标志
};
