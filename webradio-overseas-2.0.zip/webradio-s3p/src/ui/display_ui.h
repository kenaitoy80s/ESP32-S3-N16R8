#pragma once
#include <U8g2lib.h>
#include "../config.h"
#include "../player_state.h"

// ============================================================================
// 元素配色(2026-10-10 由 DMradio-tyio / webradio-tyio-st7789 移植而来)
// ----------------------------------------------------------------------------
// 一个像素只能有一个前景色, 而界面仍走 U8g2 的 1bpp 帧缓冲 —— 所以"颜色"是【按屏幕行】决定的:
// 绘制代码每帧把"哪些行属于哪个元素"登记进分区表, 推屏回调 DRAW_TILE 把 bit=1 的像素换成
// 该行所属元素的颜色。⇒ 字体 / 中文 / 跑马灯 / 旋转一行都不用改, 单色屏项目也能平移。
// ★★改这个枚举的顺序 = 改后台下拉的顺序, 必须同步 tools/web_page/color.js 的 EL[] ★★
//   (NVS 按下标存, 所以【只能往后加, 不能重排/删中间项】, 否则老用户已选的颜色会错位。)
// ============================================================================
enum {
  ELEM_TOPBAR = 0,   // 顶栏: 日期 / 农历 / 睡眠倒计时徽标 / 分隔线
  ELEM_CLOCK,        // 大时钟(大屏左侧)
  ELEM_WEATHER,      // 天气卡片 + 湿度风向行
  ELEM_STATION,      // 电台名(大屏: 与节目信息合并成一条跑马灯)
  ELEM_TITLE,        // 节目信息 / 曲名(小屏四行布局的第 2 行, 同样是跑马灯)
  ELEM_STATUS,       // 播放状态(图标/状态框) + 格式码率
  ELEM_WIFI,         // WiFi 信号(右)
  ELEM_VOLBAR,       // 音量滑条 + 音量%
  ELEM_IP,           // 本机 IP
  ELEM_BATT,         // 电量% / 睡眠剩余 / 充电闪电
  ELEM_LIST,         // 电台列表界面(快速选台)
  ELEM_FRAME,        // 卡片边框 / 进度条 / 其它装饰线
  ELEM__COUNT
};
enum { ELEM_COUNT = ELEM__COUNT };
enum { ELEM_PALETTE_N = 14 };      // 常规色板项数(与 tools/web_page/color.js 必须一一对应)

/*
 * 显示驱动: ST7567(硬件 SPI) / SSD1306(硬件 I2C) / ST7789 / ILI9341(SPI 彩色 TFT 320x240) 四选一,
 *   U8g2 全缓冲。彩屏(ST7789 / ILI9341)本机 U8g2 库无对应驱动, 走"自定义 U8g2 设备 + 硬件 SPI":
 *   中文 GB2312 逐字渲染 / 4 行布局 / 整帧跳过 100% 复用, DRAW_TILE 回调把 1bpp 帧缓冲转 RGB565 推屏。
 *   ★ST7789 与 ILI9341 共用同一组引脚(LCD2_*), 差别只有三处: 上电初始化序列 / MADCTL 默认值 / 是否反显,
 *     全部收敛在 display_ui.cpp 的 gTftIli 分支里, 其余(窗口/推屏/旋转/主题/背景图)完全共用。
 * 屏幕类型/对比度/180°旋转在 Web 后台"显示设置"调节并持久化(NVS "disp"):
 *   WS 下发 -> 存 NVS + 置 pending, 由主循环 tick() 统一重建/应用到 u8g2
 *   (u8g2 非线程安全, 不能在 WS 异步任务上下文直接碰)。
 * 中文: 逐字渲染(display_ui.cpp pickCnFont)用完整 GB2312 字体, 缺字画方框占位。
 * 布局: 1行电台名(跑马灯) / 2行节目信息(跑马灯) / 3行播放图标+码率+音量 / 4行IP(按屏分辨率自适应)。
 * 另有【电台列表】界面(showList): 长按中键/长按红外播放键进入的快速选台, 行数/行高按屏分辨率自适应。
 */
class DisplayUI {
public:
  DisplayUI();
  void begin();
  // 主界面(station=电台名; status 仅保留参数兼容, 状态改用图标; bitrate/volume/playing 见第3行)
  void show(const String& station, const String& status,
            int volume, int volMax, bool playing, const String& bitrate);
  // 电台列表界面(快速选台): names=整份电台名数组(不复制, 由调用方持有), n=总数,
  //   cursor=光标所在序号, current=当前正在播放的序号(-1=无)。
  //   内部按屏分辨率算可见行数与滚动窗口(滚动位置 mListTop 是本对象持有的视图状态);
  //   选中行反白, 正在播放的台序号前加 '*'; 超宽台名按屏宽截断(不做跑马灯)。
  // groups/sel(2026-10-06): 分类【标签栏】。groups=全部分类名数组(可为 nullptr),
  //   ng=分类个数, sel=当前选中分类下标。标签横向排列, 选中的反白高亮, 放不下时自动
  //   横向滚动保证选中标签完整可见(滚动位置是本对象持有的视图状态 mTabTop)。
  void showList(const String* names, int n, int cursor, int current,
                const String* groups = nullptr, int ng = 0, int sel = 0);
  // 启动/提示信息
  void showMessage(const String& line1, const String& line2 = "");
  // 声明"当前屏上内容未知"(主界面<->列表界面切换时调用), 强制下一帧重画
  void invalidate() { mFrameValid = false; }

  // ---- 显示设置(后台下发, NVS 持久化) ----
  int  screenType()  const { return mType; }       // SCREEN_ST7567 / SCREEN_SSD1306 / SCREEN_ST7789 / SCREEN_ST7789_SQ / SCREEN_ILI9341
  int  contrastVal() const { return mContrast; }   // 0~255
  int  rotation()    const { return mRotation; }    // 0 / 90 / 180 / 270
  int  blTimeoutVal() const { return mBLTimeout; }   // 背光熄灭超时 ms; 0=常亮不熄灭
  int  brightVal()   const { return mBright; }       // 背光亮度 0~100 %(PWM 占空比)
  void setScreenType(int t);     // 切屏型: 存 NVS + 置 pending, 主循环 tick() 重建 u8g2
  void setContrastVal(int v);    // 存 NVS + 主循环 tick() 里立即生效(仅 ST7567/SSD1306 有效)
  void setRotation(int deg);     // 存 NVS + 主循环 tick() 里立即生效(deg∈{0,90,180,270})
  // 顺时针转 90° 循环(0->90->180->270->0)。供红外遥控"屏幕旋转"键 / 按键复用。
  // ★仅彩屏(ST7789/ILI9341)有效: 其它屏(SSD1306/ST7567)旋转会让 128x64 的排版失去意义, 直接忽略并打印提示。
  // ★代价: 会整体重建 U8g2 并重新读入该方向的 150KB 背景图(几十 ms), 故别做高频调用。
  void rotateStep();
  // 屏幕类型循环切换(红外"切换屏幕"键): ST7567 -> SSD1306 -> ST7789 -> ILI9341 -> ST7567 ...
  // 屏接法见《IO分配表.txt》(同板可焊多块, 靠 CS 互斥; ST7789 与 ILI9341 共用同一组脚, 同位置换屏)。
  // 没插的那块不会亮, 属正常。与 rotateStep 一样只置 mPendingType, 真正重建由主循环 tick() 完成。
  void screenStep();
  void setBLTimeout(int ms);     // 存 NVS + 立即生效(0=常亮; 仅 ST7567/ST7789 有背光)
  void setBrightVal(int pct);    // 背光亮度 0~100%: 存 NVS + 立即生效(仅 ST7567/ST7789)

  // ---- 元素颜色分区登记(每帧由绘制代码调用, 见本文件顶部"元素配色"注释) ----
  // 把 [y0,y1] 这些行整行归给元素 idx(推屏时 bit=1 用该元素的颜色)。
  void elemZone(int idx, int y0, int y1);
  // 同一行【左右两个元素】要不同颜色: x < sx 用 idxL, x >= sx 用 idxR。
  void elemZoneSplit(int idxL, int idxR, int sx, int y0, int y1);
  // ★登记"一行文字"的元素色区: 传【基线】yBase, 自动覆盖完整字形高度(base-14 .. base+2)。
  //   直接用 elemZone 手填行区间容易把边界切进字形里 -> 同一行字上半截/下半截两个颜色。
  void elemZoneText(int idx, int yBase);
  // ★装饰线框(卡片边框 / 进度条 / 分隔线)单独占 ELEM_FRAME 色, 不再被"所在行的元素色"污染。
  //   只钉【精确那一列 / 那一行区间】, 误伤不到同行的其它元素。
  //   ★r = 圆角半径(drawRFrame 的末参; drawFrame/drawHLine 传 0): 半径带内的圆弧像素不在
  //     上下两行 x0..x1 区间、也不在左右两列上 —— 依赖 r 额外把四个【角块】钉成框色,
  //     否则圆角处会露出一小截主题前景色(实测: 元素全设黑色后转角仍发白)。
  void elemFrameEdge(int x0, int y0, int x1, int y1, int r = 0);
  // 每帧开头清空分区表(未登记的行回落到旧版单一前景色 gSt7789Fg)
  void elemZoneReset();
  // 取/存"第 i 个元素"选中的色板下标(0 ~ ELEM_PALETTE_N-1)。存 NVS("ecol")并立即生效(下一帧)。
  int  elemColor(int i) const { return (i >= 0 && i < ELEM_COUNT) ? mElemPal[i] : 0; }
  void setElemColor(int i, int palIdx);
  // 批量下发(后台一次保存把 N 个元素一起改): v=色板下标数组, n=个数(<=ELEM_COUNT)
  void setElemColors(const int* v, int n);
  // ★背景色(2026-10-16 由 FULL/FM 主线移植): bit=0 且未上传背景图时的整屏底色。
  //   下标指向 kBgPalette[](0=淡蓝天空 … 7=纯白)。存 NVS("bg")并立即生效(下一帧强制重画)。
  int  bgColorIdx() const { return mBgIdx; }
  void setBgColor(int idx);
  // ★ST7789 横竖屏切换(串口 O): 存 NVS + 立即整体重建 u8g2(几何变了, 只换窗口不行)。
  //   仅主循环(串口命令处理)可调用 —— 会 delete/new U8G2 对象。
  void setST7789Portrait(bool portrait);

  // ---- 背光管理(仅 ST7567 有背光) ----
  // 任意按键唤醒(点亮+重置计时); tick() 每圈调用, 无操作超时自动熄灭
  void noteActivity();
  void tick();                   // 背光计时 + 应用后台下发的对比度/旋转(pending)

  // ---- 排查工具(串口触发) ----
  void toggleBacklight();        // 手动翻转背光(测极性/接线)
  void testPattern();            // 满屏测试图案(测接线/初始化)
  void powerOff();
  // 睡眠定时器到点: 关屏(清屏 + 灭背光)。★与 powerOff 不同: 不置 mPoweredOff,
  // 故任意按键经 noteActivity 仍可重新点亮(睡眠只是"熄屏待机", 不是彻底断电)。
  void screenOff();               // 关机: 清屏 + 关背光 + 置"已断电"标志(避免 tick 又把背光点亮)
  // ---- 字库覆盖自检(串口 F) ----
  // 统计字符串里"屏上字体画不出"的字(= 屏上会显示成空心方框的那些), 返回缺字个数,
  // 并把缺失码点追加到 missing(形如 "U+56E7 ")。用于回答"这个台名/曲名为什么有方框"。
  // 判定手法与绘制路径完全一致: U8g2 对字体里没有的码点返回 0 宽度 -> pickCnFont 返回 -1。
  int  fontCheck(const char* s, String& missing);
  void fontCheckBuiltin();       // 打印内置测试串(常用字/标点/全角/假名/生僻字)的覆盖情况
  // 打印"实际绘制帧数 / 整帧跳过帧数"(诊断, 由主循环诊断周期调用)。
  // 跳过率就是省下来的 CPU: 每跳一帧约省 55~60ms(逐字中文渲染 + 软件 SPI 整屏发送)。
  void printFrameStats();

private:
  void loadSettings();           // 从 NVS("disp") 读三项设置并做合法性钳制
  void saveSettings();           // 三项设置写回 NVS
  void recreateU8g2();           // 按当前类型/旋转/对比度整体重建 u8g2 对象(仅主循环调用)
  // 切屏型时把【旧屏】真正关掉再重建。★只 delete U8G2 对象是不够的: 删掉的只是驱动侧,
  //   面板侧会一直保持 GRAM 里的最后一帧 —— SSD1306 自发光又没有背光脚可关, 表现成
  //   "切到别的屏之后, 1306 还挂着切换前的信息"。仅 recreateU8g2() 内部调用。
  //   ★必须在 delete 之前、且在 hwspiRelease()/deslectOtherCs() 之前: 关屏命令要用旧屏
  //     自己的总线与片选, 顺序反了就发不出去。
  void blankActivePanel(int type);

  U8G2*    mDisp[2] = {nullptr, nullptr};  // 活动屏对象(最多 2 块: 主屏 + 副屏 SSD1306)
  int      mDispN   = 0;                  // 当前活动屏数量(1=单屏, 2=双屏并存)
  U8G2*    u8g2 = nullptr;       // 兼容别名 = mDisp[0](测量/旧调用用); 实际绘制遍历 mDisp[]
  int      mType     = SCREEN_DEFAULT;
  // ★当前【真正驱动着】的那块屏的型号(-1 = 还没建过)。为什么不直接用 mType:
  //   setScreenType() 会【立刻】改写 mType(否则连按切换键时 screenStep() 的 +1 会算错),
  //   于是 recreateU8g2() 里已经分不清"现在屏上这块是哪种"了 —— 切屏关旧屏必须靠本字段。
  int      mBuiltType = -1;
  int      mContrast = LCD_CONTRAST;
  int      mRotation = 0;                 // 旋转角度 0/90/180/270
  int      mBLTimeout = LCD_BL_TIMEOUT_MS;   // 背光熄灭超时 ms; 0=常亮(仅 ST7567/ST7789 有背光)
  int      mBright    = LCD_BL_BRIGHT_DEFAULT;  // 背光亮度 0~100%(LEDC PWM 占空比; 仅 ST7567/ST7789)
  int      mPendingContrast = -1;   // >=0 = 后台已下发, 待主循环应用
  int      mPendingRot      = -1;
  int      mPendingType     = -1;   // >=0 = 后台已下发新屏型, 待主循环重建 u8g2
  bool     mHasBL = false;          // 当前屏是否有背光脚(ST7567=有; SSD1306=无, 自发光)
  // ---- 跑马灯状态(2026-09-23 改为"按时间积分", 步长恒 1px, 与画面帧率解耦) ----
  // 旧做法"每帧固定 +3px + 独立 150ms 闸门"与 .ino 的 150ms 节流同周期, 相位漂移 ⇒ 忽快忽停。
  uint32_t marqueeT  = 0;     // 上次时间积分时刻(millis); 0 = 尚未积分(首帧不补偿)
  int      marqueeMs = 0;     // 毫秒余额(0 ~ MQ_MS_PER_PX-1), 攒够一格才走 1px
  // ★2026-09-23 7567 专用"周期性静止"(治"一直滚看着眼晕"): 每滚完一轮, 原地静止到此刻才继续。
  //   持续不断的滚动本身就是不适来源(网上无障碍/前庭指南的共识: 动效要可暂停; WCAG 2.2.2)。
  uint32_t mqDwellUntil = 0;  // 静止截止时刻(millis); 含义见 display_ui.cpp 的 MQ_DWELL_MS
  int      marqueeOff  = 0;   // 第1行(电台名)跑马灯偏移(像素, 0 ~ 周期-1)
  int      marqueeOff2 = 0;   // 第2行(电台信息)跑马灯偏移(像素)
  int      mListTop    = 0;   // 电台列表的滚动窗口首行序号(纯视图状态, showList 内自行钳制)
  int      mTabTop     = 0;   // 分类标签栏横向滚动偏移(像素): 标签放不下时保证选中标签完整可见
  bool     blOn = false;      // 背光当前是否点亮(亮 = 输出 mBright% 占空比, 灭 = 输出 0%)
  bool     mPoweredOff = false;   // 是否已关机(清屏+背光灭); 置位后 noteActivity/tick 不再点亮背光
  bool     mScreenOff  = false;   // 睡眠定时器熄屏态(与 mPoweredOff 区别: 可被 noteActivity 唤醒, 不置断电标志)
  int      blPin() const { return (mType == SCREEN_ST7789 || mType == SCREEN_ILI9341) ? LCD2_BL : LCD_BL; }  // 彩屏(ST7789/ILI9341)共用 LCD2_BL, 其余=LCD_BL
  bool     blActiveHigh() const { return (mType == SCREEN_ST7789 || mType == SCREEN_ILI9341) ? (LCD2_BL_ACTIVE_HIGH != 0) : (LCD_BL_ACTIVE_HIGH != 0); }
  void     blInit();          // 把两路背光脚挂到 LEDC(幂等)并把"当前屏"的背光按 mBright 点亮
  void     blApply();         // 按 blOn/mBright 立刻刷新当前屏背光 PWM 输出(极性按屏型适配)
  uint32_t blLastActive = 0;  // 上次用户操作时刻(millis)
  uint32_t mBootTestUntil = 0;  // 开机自检图案窗口的结束时刻(millis); 0 = 关闭(见 config.h 的 LCD_BOOT_TEST_MS)
  bool     mBootTestDrawn = false;  // 窗口内是否已画过(只画一次, 避免每圈重画整屏)
  // ---- 整帧跳过(2026-09-18, 见 display_ui.cpp show() 顶部注释) ----
  // 一帧实测 56~63ms(中文逐字测宽+绘制 + 软件 SPI 整屏发送); 内容没变时整帧跳过可省掉它。
  uint32_t mFrameHash  = 0;      // 上一帧内容指纹(FNV-1a)
  bool     mFrameValid = false;  // 指纹是否有效; 重建 u8g2 / 清屏 / 显示提示消息后置 false 强制重画
  bool     mMarqueeRun = false;  // 上一帧是否处于跑马灯状态(滚动中必须连续刷, 不可跳过)
  uint32_t mDrawCnt = 0;         // 实际绘制帧数(诊断)
  uint32_t mSkipCnt = 0;         // 整帧跳过次数(诊断)
  void drawPlayIcon(U8G2& g, int x, int y, bool playing);
  // 充电闪电图标(填充折线, 1bpp 屏上清晰): (x,yTop)=左上角, h=高度(像素)。充电时画在电量%左侧
  void drawLightning(U8G2& g, int x, int yTop, int h);

  int  mElemPal[ELEM_COUNT];       // 每个元素选中的色板下标
  int  mBgIdx = 0;                 // ★卡通背景色下标(kBgPalette[]; 0=淡蓝天空)
};

// ---- 彩屏面板方向(串口现场调试; 仅 ST7789 / ILI9341 屏有意义) ----
// 三个开关都会【立即生效并写 NVS】, 重启后仍然保持:
//   O = 切横屏 320x240 / 竖屏 240x320(整体重建, 因为几何变了)
//   K = 在当前方向内轮换 MADCTL(治"上下颠倒 / 镜像"; ST7789 / ILI9341 各一套候选值)
//   J = 翻转反显(治"整片发白像底片"; 两块屏各存一份)
void    st7789MadctlCycle();     // 轮换到下一个候选值并立即重画底色
uint8_t st7789MadctlGet();       // 取当前生效值(供诊断打印)
void    st7789ToggleInvert();    // 翻转反显(0x21 <-> 0x20): 治"整片发白像底片"
bool    st7789InvGet();          // 当前反显状态(当前芯片那一份)
// 设置反显并立即生效(0x21/0x20), 存 NVS。★自由函数(不是 DisplayUI 成员):
//   后台 WS 回调在 async_tcp 任务上下文, 而 DisplayUI 实例在 .ino 里, 成员函数需要对象指针;
//   反显只发一条 SPI 命令 + 写 NVS, 不碰 u8g2, 所以做成自由函数最省事、也最安全。
//   对非彩屏(ST7567/SSD1306)调用无效果(命令发给了不存在的屏型)。
void    st7789SetInvert(bool on);
void    st7789ThemeCycle();      // 轮换 ST7789 调色板主题(经典黑白/深蓝图片风/墨绿夜光)并立即铺新底色
const char* st7789ThemeName();   // 当前主题名(供诊断打印)
int     st7789ThemeGet();        // 当前主题索引
bool    st7789PortraitGet();     // 当前是否竖屏(240x320)

// ============================================================================
// 屏幕背景图(2026-10-06 新增; 由 Web 后台"屏幕背景"标签页上传, 存 LittleFS)
// ----------------------------------------------------------------------------
// ★这是【全彩色】背景(RGB565, 每像素 2 字节大端, 153600 B), 不是黑白 ——
//   ST7789 本身就是 65K 色面板; 之前"只有两个颜色"是因为 U8g2 的界面层走 1bpp 缓冲。
//   彩色化的落点在推屏回调 DRAW_TILE: bit=0 的像素不再查常量 gSt7789Bg, 而是查这张图。
//   → 界面(文字/卡片, 9600B 的 1bpp 模板)与底色(150KB 全彩)彼此独立, 互不干扰。
// 设计取舍: 缩放/裁剪/调色/转 RGB565 全在【浏览器】里做完, 设备端一个解码器都不引入;
//   图放 PSRAM(150KB) 而非 DRAM(那块更稀缺, 音频/AAC/Web 都在抢)。
// 仅 ST7789 大屏有效。★没上传背景图时, 推屏走的是原来那两行常量查表 —— 一字节都没变。
// ============================================================================
bool bgLoad();                                 // 按当前方向把 LittleFS 的图读进 PSRAM(开机/切方向后调)
bool bgActive();                               // 当前是否真有一张背景图在生效
bool bgHas(bool portrait);                     // 指定方向是否存有背景图(供 /api/state 回显)
// ★落盘/删除只允许【主循环】调用: LittleFS 写入会短暂禁用 flash cache 冻核,
//   放 Web 异步任务里做会拖累同核的其它任务(见 station_store.cpp 的同类注释)。
bool bgSave(const uint8_t* data, bool portrait);  // 落盘 + 若方向匹配则立即重载并重画
void bgClear(bool portrait);                    // 删除指定方向的背景图 + 若方向匹配则立即取消

// ---- 界面不透明度(2026-10-06) ----
// 0~100: 100 = 界面用纯色画、与背景零混合(默认, 也是 DRAW_TILE 里最省的那条路);
//        0 = 界面完全隐形; 中间 = 真正的 RGB565 线性混合(fg*a + bg*(1-a))。
// ★注意这是"界面"的不透明度, 不是背景图的浓度 —— 背景图明暗请用下面的 bgBrightGet/Set。
uint8_t bgUiAlphaGet();
// persist=true 会写 NVS, 所以【只能在主循环调用】(Web 侧通过 pending 标志转达, 见 web_server.cpp)。
void    bgUiAlphaSet(uint8_t a, bool persist);

// ---- 背景图亮度(2026-10-10, 由 DMradio-tyio 模板同步) ----
// 0~100, 只压暗【背景图本身】(不是屏幕背光, 也不是界面不透明度): 100=原图(默认),
// 0=全黑。用于"照片太亮、白字看不清"时把底图压暗提对比, 界面元素色不受影响。
// ★在 bgLoad() 加载时一次性把 150KB 像素按比例缩放; 设新值时若当前方向有图会【重新读一次】
//   并重算(不写 NVS 时只在内存生效, persist=true 才落盘)。
uint8_t bgBrightGet();
// persist=true 会写 NVS, 故【只能在主循环调用】(Web 侧走 pending 标志, 见 web_server.cpp)。
void    bgBrightSet(uint8_t b, bool persist);
