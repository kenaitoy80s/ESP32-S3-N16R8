#pragma once
#include <Arduino.h>

class StationStore;
class AudioPlayer;
class WiFiPortal;
class DisplayUI;

/*
 * Web 服务 + 配置页面 (ESPAsyncWebServer)
 * 单页同时提供: WiFi 配网 / 电台增删改 / 播放控制 / 显示设置(屏幕类型/对比度/旋转) / 状态轮询
 * AP 模式下 onNotFound 兜底, 配合 DNSServer 实现 captive portal
 *
 * 【线程安全约定 —— 修"后台操作死机"】
 * ESPAsyncWebServer 的 WS/HTTP 回调运行在 async_tcp【异步任务】上下文, 与 Arduino
 * 主循环并发。共享数据一律遵守:
 *   - gState 的 String 字段(stationName/title/status/bitrate/ip): 只在主循环写。
 *     异步任务若需影响它们, 只能置 gStoreChanged 标志, 由 loop() 在主循环修正。
 *     反例即崩溃源: 页面每 3s 轮询 /api/state, 异步任务读 gState.stationName 时
 *     主循环正在切台重写它 -> String 内部缓冲被释放中读取 -> 堆损坏重启。
 *   - /api/state 不再现场读 gState, 而是发送主循环预先构建好的【状态快照】。
 *   - 电台列表的读写统一走 StationStore 内部的递归锁。
 */
class WebServerSvc {
public:
  void begin(StationStore* s, AudioPlayer* p, WiFiPortal* w, DisplayUI* d);
  void loop();     // 主循环调用: 修正 gState + 定期重建状态快照
  // 主循环调用(紧跟 loop() 即可): 消费"Web 上传的屏幕背景图"。
  // ★为什么要单独一个函数、而不在 HTTP 回调里直接落盘: 上传的数据由 onBody 收在 PSRAM 里,
  //   而 LittleFS 写入会短暂冻结 flash cache —— 必须在主循环上下文做, 否则拖累同核任务。
  //   (与本工程"不在 Web 异步任务写 FS"的既有约定一致)
  void bgTick();

  // ---- 存活诊断(排查"后台打不开"的关键仪器) ----
  // 判读: 浏览器访问时若 httpReqCount() 在涨 => 请求已到达设备(问题在响应/浏览器侧);
  //       一直不涨 => 请求根本没到设备(WiFi/路由/错误IP/lwIP 层)。
  // wsClients() = 当前 WebSocket 连接数(页面打开后应为 1)。
  uint32_t httpReqCount();
  int      wsClients();
};
