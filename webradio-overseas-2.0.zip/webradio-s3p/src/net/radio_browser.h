/*
 * radio_browser.h - 在线电台搜索(radio-browser.info)  (2026-10-20 新增)
 *
 * 【为什么这样设计】
 *   本工程既有约定: HTTPS 拉取放在【主循环】里做(见 net_feeds.cpp 天气: 每小时 1~3s),
 *   音频泵是独立任务, 不受主循环阻塞影响。照这个套路:
 *     - Web 异步任务只"请求"(rbRequest), 立刻返回 -> 页面不卡
 *     - 主循环 rbPoll() 真正拉取(1~6s) -> 结果写快照
 *     - 页面轮询 /api/rb/result 取快照
 *   ★绝不能在 async_tcp 任务里直接拉 HTTPS: 那会把整个 Web/WS 卡住数秒, 页面表现为"点了没反应"。
 *
 * 【数据来源】https://www.radio-browser.info  (免 Key, 社区维护)
 *   参考 D:\ESP32\RadioBrowser_API_接入指南.md 的实测结论:
 *     - 不按 bitrate=0 过滤(中国台约 86% 标 0, 实际可播)
 *     - 不按 lastcheckok 过滤(检查服务器自身网络问题会误标)
 *     - 不排除 HLS 流
 *   最小过滤: 名称非空 + URL 以 http 开头。
 */
#pragma once
#include <Arduino.h>

enum RbState { RB_IDLE = 0, RB_RUNNING = 1, RB_DONE = 2, RB_ERR = 3 };

void rbBegin();                                            // 建互斥锁 + 初始快照(WebServerSvc::begin 调)
bool rbRequest(const String& mode, const String& q);       // 异步任务调: 只置请求, 立即返回
void rbPoll();                                             // 主循环调: 有请求就做 HTTPS 拉取
String rbSnapshotJson();                                   // 异步任务调: 取快照 JSON(持锁拷贝)
bool rbItem(int idx, String& name, String& url);           // 异步任务调: 取第 idx 条(持锁拷贝)
int  rbCount();                                            // 当前结果条数
const char* rbStateStr();                                  // "idle"/"running"/"done"/"err"
