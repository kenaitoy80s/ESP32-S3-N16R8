/*
 * radio_browser.cpp - 在线电台搜索(radio-browser.info) 实现  (2026-10-20 新增)
 *
 * 线程模型(与 web_server.h 顶部的约定一致):
 *   - 写: 只在主循环(rbPoll), 全程持 s_mtx
 *   - 读: 异步任务(rbSnapshotJson / rbItem), 同样持 s_mtx 拷贝一份再返回
 *   -> 异步任务绝不直接碰 String 数组, 避免与主循环重写时堆损坏。
 *
 * 接口(radio-browser 官方 REST, 免 Key):
 *   搜索  /json/stations/search?name=<q>&limit=12&hidebroken=true&order=votes&reverse=true
 *   热门  /json/stations/topvote/12
 *   中国  /json/stations/bycountrycodeexact/CN?limit=12&hidebroken=true&order=votes&reverse=true
 *   多节点回退: de1 -> all -> nl1 (all 是官方聚合入口, 会轮询到可用节点)
 */
#include "radio_browser.h"
#include "../config.h"

#include <WiFi.h>
#include <HTTPClient.h>
#include <NetworkClientSecure.h>
#include <ArduinoJson.h>
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>

#define RB_MAX      12     // 一次最多保留 12 条(页面一屏够用, 也省堆)
#define RB_CONN_MS  4000   // 单次连接超时
#define RB_TOTAL_MS 6000   // 单次总超时(含握手/收数据)

struct RbItem {
  String name;
  String url;
  String meta;      // "中国 · 128票" 这类副标题
};

static RbItem   s_items[RB_MAX];
static int      s_n     = 0;
static volatile int8_t s_state = RB_IDLE;
static String   s_err;
static String   s_reqMode;      // 挂起的请求(mode)
static String   s_reqQ;         // 挂起的请求(关键词)
static volatile bool s_pending = false;
static String   s_snap;         // 预构建快照(只读发送, 避免每次现场拼)
static SemaphoreHandle_t s_mtx = nullptr;

/* ---------------- 小工具 ---------------- */
static String urlEnc(const String& in) {
  String out;
  out.reserve(in.length() * 3 + 4);
  static const char* hex = "0123456789ABCDEF";
  for (size_t i = 0; i < in.length(); i++) {
    uint8_t c = (uint8_t)in[i];
    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
        (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~') {
      out += (char)c;
    } else {
      out += '%'; out += hex[c >> 4]; out += hex[c & 0x0F];
    }
  }
  return out;
}

/* JSON 字符串转义(电台名里会出现 " 和 \ , 不转义前端 JSON.parse 必炸) */
static String jesc(const String& in) {
  String o;
  o.reserve(in.length() + 8);
  for (size_t i = 0; i < in.length(); i++) {
    char c = in[i];
    switch (c) {
      case '"':  o += "\\\""; break;
      case '\\': o += "\\\\"; break;
      case '\n': o += "\\n";  break;
      case '\r': o += "\\r";  break;
      case '\t': o += "\\t";  break;
      default:
        if ((uint8_t)c < 0x20) o += ' ';
        else o += c;
    }
  }
  return o;
}

static const char* stateStr(int8_t s) {
  switch (s) {
    case RB_RUNNING: return "running";
    case RB_DONE:    return "done";
    case RB_ERR:     return "err";
    default:         return "idle";
  }
}

/* 重建快照(调用方必须持锁) */
static void rebuildSnapLocked() {
  String s;
  s.reserve(256 + s_n * 160);
  s += "{\"state\":\"";
  s += stateStr(s_state);
  s += "\",\"n\":";
  s += String(s_n);
  s += ",\"err\":\"";
  s += jesc(s_err);
  s += "\",\"items\":[";
  for (int i = 0; i < s_n; i++) {
    if (i) s += ',';
    s += "{\"n\":\"";
    s += jesc(s_items[i].name);
    s += "\",\"u\":\"";
    s += jesc(s_items[i].url);
    s += "\",\"m\":\"";
    s += jesc(s_items[i].meta);
    s += "\"}";
  }
  s += "]}";
  s_snap = s;
}

/* ---------------- 对外 ---------------- */
void rbBegin() {
  if (s_mtx) return;
  s_mtx = xSemaphoreCreateMutex();
  xSemaphoreTake(s_mtx, portMAX_DELAY);
  s_state = RB_IDLE;
  s_n = 0;
  s_err = "";
  rebuildSnapLocked();
  xSemaphoreGive(s_mtx);
  Serial.println("[RB ] 在线电台搜索就绪(radio-browser.info)");
}

bool rbRequest(const String& mode, const String& q) {
  if (!s_mtx) rbBegin();
  if (s_state == RB_RUNNING) {
    Serial.println("[RB ] 上一次搜索还没结束, 忽略本次请求");
    return false;
  }
  xSemaphoreTake(s_mtx, portMAX_DELAY);
  s_reqMode = mode;
  s_reqQ    = q;
  s_err     = "";
  s_state   = RB_RUNNING;
  s_pending = true;
  rebuildSnapLocked();
  xSemaphoreGive(s_mtx);
  Serial.printf("[RB ] 请求 mode=%s q=[%s]\n", mode.c_str(), q.c_str());
  return true;
}

int  rbCount() { return s_n; }
const char* rbStateStr() { return stateStr(s_state); }

String rbSnapshotJson() {
  if (!s_mtx) return String("{\"state\":\"idle\",\"n\":0,\"err\":\"\",\"items\":[]}");
  xSemaphoreTake(s_mtx, portMAX_DELAY);
  String out = s_snap;
  xSemaphoreGive(s_mtx);
  return out;
}

bool rbItem(int idx, String& name, String& url) {
  if (!s_mtx) return false;
  bool ok = false;
  xSemaphoreTake(s_mtx, portMAX_DELAY);
  if (idx >= 0 && idx < s_n) { name = s_items[idx].name; url = s_items[idx].url; ok = true; }
  xSemaphoreGive(s_mtx);
  return ok;
}

/* ---------------- 抓取(主循环) ---------------- */
/* 抓取一条并解析。结果写 tmp[] / n(由调用方在持锁状态下拷进 s_items) */
static int rbFetchOne(const String& host, const String& path, RbItem* tmp, int& nOut, String& err) {
  NetworkClientSecure cli;
  cli.setInsecure();              // 免证书校验: 省 40KB 证书链, 只读公开 JSON, 可接受
  cli.setTimeout(RB_TOTAL_MS / 1000);

  HTTPClient http;
  http.setConnectTimeout(RB_CONN_MS);
  http.setTimeout(RB_TOTAL_MS);
  String url = String("https://") + host + path;
  if (!http.begin(cli, url)) { err = "begin 失败"; return -1; }
  http.addHeader("User-Agent", "ESP32-webradio/" FW_VERSION);
  http.addHeader("Accept", "application/json");
  int code = http.GET();
  if (code != 200) {
    http.end();
    err = String("HTTP ") + String(code);
    return -2;
  }
  String payload = http.getString();
  http.end();
  if (payload.length() < 10) { err = "响应为空"; return -3; }

  /* 只解析需要的 5 个字段(Filter), 12 条完整对象约 30KB, 不滤会白吃 30~40KB 堆 */
  JsonDocument filter;
  filter[0]["name"]         = true;
  filter[0]["url_resolved"] = true;
  filter[0]["url"]          = true;
  filter[0]["country"]      = true;
  filter[0]["votes"]        = true;

  JsonDocument doc;
  DeserializationError de = deserializeJson(doc, payload, DeserializationOption::Filter(filter));
  if (de) { err = String("JSON ") + de.c_str(); return -4; }
  JsonArray arr = doc.as<JsonArray>();
  if (arr.isNull()) { err = "返回不是数组"; return -5; }

  int n = 0;
  for (JsonObject o : arr) {
    if (n >= RB_MAX) break;
    const char* nm = o["name"] | "";
    const char* ur = o["url_resolved"] | "";
    if (!ur || !*ur) ur = o["url"] | "";
    if (!*nm || !ur || strncmp(ur, "http", 4) != 0) continue;   // 最小过滤, 见头注释
    const char* cc = o["country"] | "";
    long votes = o["votes"] | 0;

    tmp[n].name = nm;
    tmp[n].url  = ur;
    char meta[48];
    if (cc && *cc) snprintf(meta, sizeof(meta), "%s · %ld 票", cc, votes);
    else           snprintf(meta, sizeof(meta), "%ld 票", votes);
    tmp[n].meta = meta;
    n++;
  }
  nOut = n;
  if (n == 0) { err = "没有匹配的电台"; return -6; }
  return 0;
}

void rbPoll() {
  if (!s_pending) return;
  s_pending = false;

  String mode, q;
  xSemaphoreTake(s_mtx, portMAX_DELAY);
  mode = s_reqMode;
  q    = s_reqQ;
  xSemaphoreGive(s_mtx);

  String err;
  RbItem tmp[RB_MAX];          // 先收在本地(栈上 12×3 个 String 头, 约 0.5KB), 最后一次性持锁落地
  int    tmpN = 0;

  /* 堆检查: TLS 握手需要连续堆, 播放中容易不够 -> 明确提示而不是崩 */
  if (WiFi.status() != WL_CONNECTED) {
    err = "设备未联网(当前可能是配网热点模式)";
  } else if (ESP.getFreeHeap() < 60000) {
    err = "内存不足, 请先暂停播放再搜索";
  } else {
    String path;
    if (mode == "top") {
      path = "/json/stations/topvote/12";
    } else if (mode == "cn") {
      path = "/json/stations/bycountrycodeexact/CN?limit=12&hidebroken=true&order=votes&reverse=true";
    } else {
      if (!q.length()) {
        err = "请输入关键词";
      } else {
        path = "/json/stations/search?name=" + urlEnc(q) +
               "&limit=12&hidebroken=true&order=votes&reverse=true";
      }
    }

    if (err.length() == 0) {
      static const char* hosts[] = {
        "de1.api.radio-browser.info",
        "all.api.radio-browser.info",
        "nl1.api.radio-browser.info",
      };
      uint32_t t0 = millis();
      int rc = -99;
      for (int i = 0; i < 3; i++) {
        rc = rbFetchOne(hosts[i], path, tmp, tmpN, err);
        if (rc == 0) break;
        Serial.printf("[RB ] %s 失败: %s\n", hosts[i], err.c_str());
      }
      Serial.printf("[RB ] 完成 rc=%d 共 %d 条, 耗时 %lums, 可用堆 %u\n",
                    rc, tmpN, (unsigned long)(millis() - t0), (unsigned)ESP.getFreeHeap());
    }
  }

  xSemaphoreTake(s_mtx, portMAX_DELAY);
  if (err.length() == 0) {
    s_n = tmpN;
    for (int i = 0; i < tmpN; i++) s_items[i] = tmp[i];
    s_state = RB_DONE;
    s_err   = "";
  } else {
    s_state = RB_ERR;
    s_err   = err;
    s_n     = 0;
  }
  rebuildSnapLocked();
  xSemaphoreGive(s_mtx);
}
