#include "wifi_portal.h"
#include <WiFi.h>
#include <Preferences.h>
#include <DNSServer.h>
#include "../config.h"
#include "../player_state.h"

static Preferences prefs;
static DNSServer dnsServer;
static const byte DNS_PORT = 53;
static IPAddress apLocalIP(192, 168, 4, 1);
static bool gNeedRestart = false;   // 延迟重启标志(避免在请求回调里直接 ESP.restart 不可靠)
static uint16_t gReconnFail = 0;    // 已连状态下断线的"连续重连失败次数"(连上即清零)

// ---- NVS 键名: "ssid0".."ssid2" / "pwd0".."pwd2" ----
void WiFiPortal::slotKey(char* out, size_t n, const char* base, int i) {
  snprintf(out, n, "%s%d", base, i);
}

String WiFiPortal::slotSsid(int i) {
  if (i < 0 || i >= WIFI_SLOT_COUNT) return String();
  char k[12]; slotKey(k, sizeof(k), "ssid", i);
  return prefs.getString(k, "");
}

// 写入/清空某个槽。ssid 传空 = 清掉该槽(对应的密码一并删)。
// ★不在这里 end()/重启: 后台可能一次改好几个槽, 由 saveAllAndRestart() 统一收尾。
//   也正因为不 end(), 之后的断线重连(会读 prefs)仍然可用。
bool WiFiPortal::setSlot(int i, const String& ssid, const String& pwd, bool keepPwd) {
  if (i < 0 || i >= WIFI_SLOT_COUNT) return false;
  char ks[12], kp[12];
  slotKey(ks, sizeof(ks), "ssid", i);
  slotKey(kp, sizeof(kp), "pwd", i);
  if (ssid.length() == 0) { prefs.remove(ks); prefs.remove(kp); return true; }
  prefs.putString(ks, ssid);
  if (!keepPwd) prefs.putString(kp, pwd);   // keepPwd: 后台密码框留空 = 保持原密码
  return true;
}
// delSlot() 在 wifi_portal.h 里已内联定义, 这里不再重复定义(否则 redefinition)。

// 旧版只存一组(键 ssid/pwd)。开机把它搬进 0 号槽, 老用户就不必重新配网。
// ★只在 0 号槽还是空的时候搬, 搬完无论成功与否都把旧键删掉 —— 否则每次开机都会拿旧值
//   把用户后来设置的 0 号槽覆盖回去。
void WiFiPortal::migrateLegacyCreds() {
  const String oldSsid = prefs.getString("ssid", "");
  if (oldSsid.length() == 0) return;
  if (slotSsid(0).length() == 0) {
    prefs.putString("ssid0", oldSsid);
    prefs.putString("pwd0",  prefs.getString("pwd", ""));
    Serial.println("[WiFi] 迁移旧版单组凭据 -> 0 号槽: " + oldSsid);
  }
  prefs.remove("ssid");
  prefs.remove("pwd");
}

bool WiFiPortal::waitConnect(uint32_t ms) {
  const uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < ms) delay(100);
  return WiFi.status() == WL_CONNECTED;
}

void WiFiPortal::markConnected() {
  gState.wifiConnected = true;
  gState.apMode = false;
  gState.ip = WiFi.localIP().toString();
  gState.status = "已连";
  Serial.printf("[WiFi] 已连接: %s (槽%d, 信号 %lddBm)\n",
                gState.ip.c_str(), curSlot_, (long)WiFi.RSSI());
  if (WiFi.RSSI() < -75) {
    Serial.println("[WiFi] 警告: 信号偏弱(< -75dBm), 卡顿可能源于覆盖而非代码!");
  }
}

// 依次尝试各已配置的槽。★顺序: 【上次成功的那个优先】—— 常态下第一次就中, 不用每次从 0 号开始扫。
// 全部失败返回 false(调用方决定是起 AP 还是继续等)。
bool WiFiPortal::connectAny(uint32_t perSlotMs) {
  int order[WIFI_SLOT_COUNT], n = 0;
  const int last = prefs.getInt("last", -1);
  if (last >= 0 && last < WIFI_SLOT_COUNT && slotSet(last)) order[n++] = last;
  for (int i = 0; i < WIFI_SLOT_COUNT; i++)
    if (i != last && slotSet(i)) order[n++] = i;
  if (n == 0) { curSlot_ = -1; return false; }

  for (int k = 0; k < n; k++) {
    const int i = order[k];
    char ks[12], kp[12];
    slotKey(ks, sizeof(ks), "ssid", i);
    slotKey(kp, sizeof(kp), "pwd", i);
    const String s = prefs.getString(ks, ""), p = prefs.getString(kp, "");
    Serial.printf("[WiFi] 尝试 %d/%d: %s\n", k + 1, n, s.c_str());
    WiFi.begin(s.c_str(), p.c_str());
    if (waitConnect(perSlotMs)) {
      curSlot_ = i;
      prefs.putInt("last", i);        // 记住这次成功的, 下次开机优先试它
      return true;
    }
    WiFi.disconnect(false);           // 断开这次失败的尝试, 把射频让给下一次
    delay(150);
  }
  curSlot_ = -1;
  return false;
}

String WiFiPortal::shortMac() {
  String m = WiFi.macAddress();
  m.replace(":", "");
  return m.substring(m.length() - 4);
}

void WiFiPortal::startAP() {
  apMode = true;
  apIPStr = apLocalIP.toString();
  String apName = String(AP_NAME_PREFIX) + "-" + shortMac();
  const char* pw = (AP_PASSWORD[0] == '\0') ? nullptr : AP_PASSWORD;
  // 用 AP_STA 共存模式: AP 提供配网热点, 同时留给"自愈重连"用 STA 后台连家网(见 loop())
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAPConfig(apLocalIP, apLocalIP, IPAddress(255, 255, 255, 0));
  WiFi.softAP(apName.c_str(), pw);
  dnsServer.setErrorReplyCode(DNSReplyCode::NoError);
  dnsServer.start(DNS_PORT, "*", apLocalIP);
  gState.wifiConnected = false;
  gState.apMode = true;
  gState.apName = apName;
  gState.ip = apIPStr;
  gState.status = "配网";
  Serial.println("[WiFi] AP 模式: " + apName);
}

void WiFiPortal::begin() {
  prefs.begin("wifi", false);
  migrateLegacyCreds();            // 旧单组键 -> 0 号槽

  // 关键(修断断续续): 关闭 WiFi 射频休眠。
  // ESP32 默认启用 modem sleep —— 射频会周期性关闭以省电, 期间路由器发来的
  // 音频包只能堆在 AP 侧等下个唤醒窗口, 表现就是"周期性卡顿/抽音"。
  // 本项目常插电, 功耗无所谓, 常开射频换来的是稳定吞吐。
  WiFi.setSleep(WIFI_SLEEP_ENABLED);
  // 拉满发射功率, 保证 TCP 的 ACK 能及时回给服务器(否则对方窗口收缩 -> 下行降速)
  WiFi.setTxPower(WIFI_TX_POWER);
  // MP3/AAC 是纯软件解码, 主频不足会解不动 -> 缓冲喂得进但来不及解, 同样断音
  setCpuFrequencyMhz(CPU_FREQ_MHZ);

  WiFi.mode(WIFI_STA);
  if (connectAny(WIFI_CONNECT_TIMEOUT_MS)) { markConnected(); return; }

  Serial.println("[WiFi] 所有已存网络都没连上, 进入 AP 配网");
  startAP();
}

void WiFiPortal::loop() {
  if (gNeedRestart) {          // 在主循环里执行重启, 比在 Web 回调里可靠
    delay(200);
    ESP.restart();
  }
  if (apMode) {
    dnsServer.processNextRequest();
    // 自愈: AP 模式下若 NVS 里还有凭据, 每 30s 用【依次尝试】再连一遍(串口会打印试了哪几组),
    // 连上就自动退出配网, 不必手动配。(凭据确实全丢了才需要手机连热点手动配)
    static uint32_t apRetryMs = 0;
    if (millis() - apRetryMs > 30000) {
      apRetryMs = millis();
      Serial.println("[WiFi] AP 自愈: 用已存凭据依次尝试重连...");
      if (connectAny(5000)) {
        dnsServer.stop();
        WiFi.softAPdisconnect(true);
        apMode = false;
        markConnected();
        Serial.println("[WiFi] AP 自愈重连成功: " + gState.ip);
      } else {
        WiFi.disconnect(false);   // 断开失败的 STA 尝试, 保留 AP 供配网
        Serial.println("[WiFi] AP 自愈重连失败, 继续配网模式");
      }
    }
  } else {
    if (WiFi.status() != WL_CONNECTED) {
      static uint32_t last = 0;
      gState.wifiConnected = false;
      if (millis() - last > 5000) {
        last = millis();
        if (++gReconnFail <= WIFI_RECONNECT_TRIES) {
          Serial.printf("[WiFi] 断线, 重连第 %u 次...\n", gReconnFail);
          WiFi.reconnect();
        } else {
          // 当前网络连续多次都连不回 —— 可能换地方了, 轮换去试其它已存网络
          gReconnFail = 0;
          Serial.println("[WiFi] 当前网络多次重连失败, 轮换到其它已存网络...");
          if (!connectAny(WIFI_CONNECT_TIMEOUT_MS)) {
            Serial.println("[WiFi] 轮换也失败, 继续重试当前网络");
            WiFi.reconnect();
          }
        }
      }
    } else {
      gReconnFail = 0;            // 连上就清零, 下次断线仍给足 WIFI_RECONNECT_TRIES 次机会
      gState.wifiConnected = true;
      gState.apMode = false;
      gState.ip = WiFi.localIP().toString();
    }
  }
}

// 兼容旧入口(AP 配网页 / 旧 WS 命令): 写 0 号槽 + 重启。
// 这里 end() 是安全的: 紧接着就重启, 之后不会再读 prefs。
void WiFiPortal::saveAndRestart(const String& ssid, const String& pwd) {
  prefs.putString("ssid0", ssid);
  prefs.putString("pwd0",  pwd);
  prefs.putInt("last", 0);       // 刚配的这台当然优先试
  prefs.end();
  gNeedRestart = true;           // 真正重启延后到 loop()
}

void WiFiPortal::resetConfig() {
  for (int i = 0; i < WIFI_SLOT_COUNT; i++) {
    char ks[12], kp[12];
    slotKey(ks, sizeof(ks), "ssid", i);
    slotKey(kp, sizeof(kp), "pwd", i);
    prefs.remove(ks);
    prefs.remove(kp);
  }
  prefs.remove("last");
  prefs.remove("ssid");          // 旧版单组键一并清掉
  prefs.remove("pwd");
  prefs.end();
  gNeedRestart = true;
}

// 后台改完若干槽后统一调用: 落盘收尾 + 重启(重启延后到 loop)。
void WiFiPortal::saveAllAndRestart() {
  prefs.end();
  gNeedRestart = true;
}

// 通用"请求重启"入口: 真正重启延后到 loop()(比在 Web 回调里直接 restart 可靠)
void WiFiPortal::requestRestart() {
  gNeedRestart = true;
}
