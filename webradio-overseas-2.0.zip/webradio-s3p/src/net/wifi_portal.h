#pragma once
#include <Arduino.h>

/*
 * WiFi 配网(2026-10-06 起支持【多组】凭据)
 * - NVS(Preferences) 存最多 WIFI_SLOT_COUNT 组 SSID/密码(键 ssid0.. / pwd0..), 外加 last(上次成功的槽)
 * - 启动: 先试 last 那组, 再依次试其余各槽; 全部失败 -> 启动 AP + captive portal(DNSServer)
 * - 已连状态下断线自动重连; 连续失败若干次则轮换到其它已存网络(换地方了也能自己找回来)
 * - 旧版单组键(ssid/pwd)开机自动迁移到 0 号槽, 老用户无需重配
 */
class WiFiPortal {
public:
  void begin();
  void loop();
  void saveAndRestart(const String& ssid, const String& pwd);  // 兼容旧入口(= 写 0 号槽 + 重启)
  void resetConfig();           // 清【全部】凭据并重启
  void requestRestart();        // 请求重启(在 loop() 里执行, 供后台设置类功能复用)
  bool isAP() { return apMode; }
  String apIP() { return apIPStr; }

  // ---- 多网络凭据(2026-10-06) ----
  String slotSsid(int i);                    // 该槽 SSID; 空串 = 未配置
  bool   slotSet(int i) { return slotSsid(i).length() > 0; }
  int    curSlot() { return curSlot_; }      // 当前生效的槽号; -1 = 未连/AP 配网中
  // 写某槽; ssid 传空 = 清掉该槽(对应密码一并删)。
  // ★keepPwd=true 时【只改 SSID、保留原密码】—— 后台出于安全不回显密码, 密码框留空即"不改"。
  bool   setSlot(int i, const String& ssid, const String& pwd, bool keepPwd = false);
  bool   delSlot(int i) { return setSlot(i, "", ""); }
  void   saveAllAndRestart();                // 后台改完统一走这个: 落盘收尾 + 重启(延后到 loop)

private:
  bool apMode = false;
  String apIPStr = "192.168.4.1";
  int    curSlot_ = -1;
  String shortMac();
  void startAP();
  static void slotKey(char* out, size_t n, const char* base, int i);  // "ssid0" / "pwd1" ...
  void migrateLegacyCreds();                 // 旧单组 ssid/pwd -> 0 号槽
  bool waitConnect(uint32_t ms);
  bool connectAny(uint32_t perSlotMs);       // 依次尝试各槽(last 优先), 成功返回 true
  void markConnected();                      // 连上后统一刷新 gState + 串口
};
